// src/modules/categories/categories.service.js
// =============================================================================
// Categories business logic layer.
//
// Two tiers of categories:
//
//   1. System categories (is_system = true, user_id = NULL)
//      Seeded at migration time. Visible to every user. Read-only via the API.
//      Cannot be edited, archived, or deleted — ever.
//
//   2. Custom categories (is_system = false, user_id = <uuid>)
//      Created by the user. Fully editable and deletable by their owner only.
//
// getAll() merges both tiers into a single sorted list, which is what the
// mobile app needs for the category picker — one unified dropdown with no
// distinction between system and custom from the UI perspective.
//
// Ownership guards:
//   - isSystemCategory() is checked on EVERY write operation.
//   - Custom category writes are additionally scoped to user_id to prevent
//     one user from editing another user's custom categories.
// =============================================================================

const { db }        = require("../../config/database");
const { AppError }  = require("../../middleware/errorHandler");
const logger        = require("../../utils/logger");

// ── Private helpers ───────────────────────────────────────────────────────────

/**
 * Looks up a category by ID and returns it (or null).
 * Does NOT scope to user_id intentionally — we need to retrieve system
 * categories (user_id = NULL) for read operations like getAll().
 *
 * @param {string} categoryId
 * @returns {object|null}
 */
async function findCategoryById(categoryId) {
  return db("categories").where({ id: categoryId }).first();
}

/**
 * Throws a 403 AppError if the category is a system category.
 * Called before any write operation (update / delete).
 *
 * @param {object} category - The category row fetched from DB
 * @param {string} operation - Human label for the error message ("edit", "delete")
 */
function assertNotSystemCategory(category, operation = "edit") {
  if (category.is_system) {
    throw new AppError(
      `System categories cannot be ${operation}d. ` +
      "Create a custom category instead.",
      403
    );
  }
}

/**
 * Verifies a category exists AND belongs to the given user.
 * Throws 404 if not found or not owned.
 *
 * @param {string} categoryId
 * @param {string} userId
 * @returns {object} The category row
 */
async function getOwnedCustomCategory(categoryId, userId) {
  const category = await db("categories")
    .where({ id: categoryId, user_id: userId })
    .first();

  if (!category) {
    throw new AppError("Category not found or access denied.", 404);
  }

  // Belt-and-suspenders: double-check is_system even though the query
  // already scopes to user_id (system categories have user_id = NULL)
  assertNotSystemCategory(category);
  return category;
}

// ── Service methods ───────────────────────────────────────────────────────────

/**
 * Returns the unified category list for the authenticated user:
 *   System defaults (is_system = true, user_id = NULL)
 *   + User's own custom categories (user_id = userId)
 *
 * Sorted by: sort_order ASC, then name ASC — giving a predictable, alphabetical
 * list with any pinned system categories appearing first.
 *
 * Optionally filtered by type ("expense", "income", "both").
 *
 * @param {string} userId
 * @param {object} filters - { type?: string }
 * @returns {object[]} Combined and sorted category list
 */
async function getAllCategories(userId, filters = {}) {
  const { type } = filters;

  const query = db("categories")
    // Include system categories (user_id IS NULL) AND user's own custom ones
    .where(function () {
      this.whereNull("user_id")           // System defaults
          .orWhere("user_id", userId);    // User's custom categories
    })
    .where({ is_archived: false })
    // Optionally filter by transaction type
    .modify((qb) => {
      if (type) {
        // "both" categories appear in all type filters
        qb.where(function () {
          this.where("type", type).orWhere("type", "both");
        });
      }
    })
    // Include parent category info for subcategory display
    .select(
      "categories.*",
      db.raw(
        `(SELECT name FROM categories p WHERE p.id = categories.parent_id) AS parent_name`
      )
    )
    .orderBy([
      { column: "sort_order", order: "asc" },
      { column: "name",       order: "asc" },
    ]);

  const categories = await query;

  // Tag each row so the UI can show a "Custom" badge if desired
  return categories.map((cat) => ({
    ...cat,
    is_custom: !cat.is_system,
  }));
}

/**
 * Returns a single category by ID.
 * Accessible if the category is a system category OR belongs to the user.
 *
 * @param {string} userId
 * @param {string} categoryId
 * @returns {object} Category row
 */
async function getCategoryById(userId, categoryId) {
  const category = await db("categories")
    .where({ id: categoryId })
    .where(function () {
      this.whereNull("user_id").orWhere("user_id", userId);
    })
    .first();

  if (!category) {
    throw new AppError("Category not found.", 404);
  }

  return { ...category, is_custom: !category.is_system };
}

/**
 * Creates a new custom category for the authenticated user.
 *
 * Prevents duplicate names within the user's own category list
 * (case-insensitive check) to avoid confusion in the category picker.
 *
 * @param {string} userId
 * @param {object} data - Validated body from createCategorySchema
 * @returns {object} Created category
 */
async function createCategory(userId, data) {
  const { name, icon, color, type, parent_id, sort_order } = data;

  // Duplicate name check (case-insensitive) within user's custom categories
  const duplicate = await db("categories")
    .where("user_id", userId)
    .whereRaw("LOWER(name) = LOWER(?)", [name.trim()])
    .first();

  if (duplicate) {
    throw new AppError(
      `You already have a custom category named "${name}". ` +
      "Choose a different name.",
      409
    );
  }

  // If parent_id provided, verify it's accessible to this user
  if (parent_id) {
    const parent = await db("categories")
      .where({ id: parent_id })
      .where(function () {
        this.whereNull("user_id").orWhere("user_id", userId);
      })
      .first();

    if (!parent) {
      throw new AppError("Parent category not found or access denied.", 404);
    }
  }

  const [category] = await db("categories")
    .insert({
      user_id:    userId,
      name:       name.trim(),
      icon,
      color,
      type,
      parent_id:  parent_id  || null,
      sort_order: sort_order ?? 0,
      is_system:  false,         // Always false — users cannot create system categories
      is_archived: false,
    })
    .returning("*");

  logger.info(`[categories] Created custom category "${category.name}" (${category.id}) for user ${userId}`);

  return { ...category, is_custom: true };
}

/**
 * Updates a custom category.
 * System categories are rejected with a 403 before any DB write.
 *
 * @param {string} userId
 * @param {string} categoryId
 * @param {object} updates - Validated partial body from updateCategorySchema
 * @returns {object} Updated category
 */
async function updateCategory(userId, categoryId, updates) {
  // Verifies ownership AND blocks system category writes
  await getOwnedCustomCategory(categoryId, userId);

  const patch = {};
  if (updates.name       !== undefined) patch.name       = updates.name.trim();
  if (updates.icon       !== undefined) patch.icon       = updates.icon;
  if (updates.color      !== undefined) patch.color      = updates.color;
  if (updates.type       !== undefined) patch.type       = updates.type;
  if (updates.parent_id  !== undefined) patch.parent_id  = updates.parent_id;
  if (updates.sort_order !== undefined) patch.sort_order = updates.sort_order;
  if (updates.is_archived !== undefined) patch.is_archived = updates.is_archived;

  if (Object.keys(patch).length === 0) {
    // Nothing to change — return the current state
    return getCategoryById(userId, categoryId);
  }

  patch.updated_at = new Date();

  const [updated] = await db("categories")
    .where({ id: categoryId })
    .update(patch)
    .returning("*");

  logger.info(`[categories] Updated category ${categoryId} for user ${userId}`);

  return { ...updated, is_custom: true };
}

/**
 * Deletes a custom category.
 * System categories are rejected with a 403.
 *
 * Safety check: if any transactions reference this category, we nullify
 * their category_id (set to NULL) rather than blocking the delete — this is
 * the "uncategorised" fallback, keeping the transaction history intact.
 *
 * @param {string} userId
 * @param {string} categoryId
 */
async function deleteCategory(userId, categoryId) {
  // Verifies ownership AND blocks system category deletes
  const category = await getOwnedCustomCategory(categoryId, userId);

  // Nullify category_id on all transactions using this category.
  // This runs as a plain update (no Knex transaction needed) because
  // nullifying category_id has no financial side-effects.
  const affectedCount = await db("transactions")
    .where({ category_id: categoryId, user_id: userId })
    .whereNull("deleted_at")
    .update({ category_id: null });

  if (affectedCount > 0) {
    logger.info(
      `[categories] Nullified category_id on ${affectedCount} transaction(s) ` +
      `after deleting category ${categoryId}`
    );
  }

  await db("categories").where({ id: categoryId }).delete();

  logger.info(`[categories] Deleted custom category "${category.name}" (${categoryId}) for user ${userId}`);
}

module.exports = {
  getAllCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory,
};
