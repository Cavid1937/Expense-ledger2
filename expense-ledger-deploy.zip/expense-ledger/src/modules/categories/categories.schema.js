// src/modules/categories/categories.schema.js
// =============================================================================
// Zod validation schemas for the Categories module.
//
// Important constraint:
//   System categories (is_system = true) cannot be created, edited, or deleted
//   via the API. This is enforced at the service layer, but the schemas here
//   deliberately do NOT expose is_system as a writable field — a user can't
//   even attempt to set it to true through the API.
// =============================================================================

const { z } = require("zod");

const CATEGORY_TYPES = ["expense", "income", "both"];

// ── Create Custom Category ────────────────────────────────────────────────────
const createCategorySchema = z.object({
  name: z
    .string({ required_error: "Category name is required" })
    .trim()
    .min(1,   "Category name cannot be empty")
    .max(100, "Category name must be under 100 characters"),

  // Emoji string or an icon key string for a custom icon library
  icon: z
    .string({ required_error: "Icon is required" })
    .trim()
    .min(1,  "Icon cannot be empty")
    .max(50, "Icon must be under 50 characters"),

  // Hex colour code — used for charts, badges, and category pills in the UI
  color: z
    .string({ required_error: "Color is required" })
    .trim()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Color must be a valid hex code (e.g. #FF6B6B)"),

  type: z
    .enum(CATEGORY_TYPES, {
      required_error:     "type is required",
      invalid_type_error: `type must be one of: ${CATEGORY_TYPES.join(", ")}`,
    })
    .default("expense"),

  // Optional parent category for subcategories (e.g. Food > Restaurants)
  parent_id: z
    .string()
    .uuid("parent_id must be a valid UUID")
    .optional()
    .nullable(),

  sort_order: z.number().int().min(0).default(0),
});

// ── Update Custom Category ────────────────────────────────────────────────────
// All fields optional — PATCH semantics.
// is_system is intentionally not a writable field.
const updateCategorySchema = z.object({
  name: z
    .string()
    .trim()
    .min(1,   "Category name cannot be empty")
    .max(100, "Category name must be under 100 characters")
    .optional(),

  icon: z
    .string()
    .trim()
    .min(1)
    .max(50)
    .optional(),

  color: z
    .string()
    .trim()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Color must be a valid hex code (e.g. #FF6B6B)")
    .optional(),

  type: z.enum(CATEGORY_TYPES).optional(),

  parent_id: z
    .string()
    .uuid()
    .optional()
    .nullable(),

  sort_order: z.number().int().min(0).optional(),
  is_archived: z.boolean().optional(),
});

module.exports = { createCategorySchema, updateCategorySchema };
