// src/modules/categories/categories.routes.js
// =============================================================================
// Categories module route definitions.
// All routes require a valid JWT. GET routes are available for both system
// and custom categories. Write routes only affect custom categories (enforced
// at the service layer, not the route layer).
// =============================================================================

const { Router }        = require("express");
const categoriesCtrl    = require("./categories.controller");
const { validate }      = require("../../middleware/validate");
const { authenticate }  = require("../../middleware/auth");
const {
  createCategorySchema,
  updateCategorySchema,
} = require("./categories.schema");

const router = Router();

// Apply authentication to every categories route
router.use(authenticate);

/**
 * GET /api/v1/categories
 * Returns system defaults + user's custom categories merged in one list.
 * Query: type=expense|income|both (optional filter)
 */
router.get("/", categoriesCtrl.list);

/**
 * GET /api/v1/categories/:id
 * Returns a single category (system or custom) accessible to the user.
 */
router.get("/:id", categoriesCtrl.getById);

/**
 * POST /api/v1/categories
 * Body: { name, icon, color, type?, parent_id?, sort_order? }
 * Creates a new custom category owned by the authenticated user.
 */
router.post(
  "/",
  validate(createCategorySchema),
  categoriesCtrl.create
);

/**
 * PATCH /api/v1/categories/:id
 * Body: any subset of category fields (all optional)
 * Returns 403 if attempting to edit a system category.
 */
router.patch(
  "/:id",
  validate(updateCategorySchema),
  categoriesCtrl.update
);

/**
 * DELETE /api/v1/categories/:id
 * Returns 403 if attempting to delete a system category.
 * Nullifies category_id on affected transactions (does not delete them).
 */
router.delete("/:id", categoriesCtrl.remove);

module.exports = router;
