// src/modules/categories/categories.controller.js
// =============================================================================
// Categories HTTP controller. One function per endpoint.
// =============================================================================

const categoriesService = require("./categories.service");

// ── GET /api/v1/categories ────────────────────────────────────────────────────
/**
 * Returns the unified category list: system defaults + user's custom categories.
 * Query param: type=expense|income|both (optional — filters by transaction type)
 * Response 200: { success, data: { categories } }
 */
async function list(req, res) {
  const { type } = req.query;

  // Validate optional type filter
  const VALID_TYPES = ["expense", "income", "both"];
  if (type && !VALID_TYPES.includes(type)) {
    return res.status(400).json({
      success: false,
      message: `type must be one of: ${VALID_TYPES.join(", ")}`,
    });
  }

  const categories = await categoriesService.getAllCategories(req.user.id, { type });

  return res.status(200).json({
    success: true,
    data:    { categories },
  });
}

// ── GET /api/v1/categories/:id ────────────────────────────────────────────────
/**
 * Returns a single category (system or custom) accessible to the user.
 * Response 200: { success, data: { category } }
 */
async function getById(req, res) {
  const category = await categoriesService.getCategoryById(
    req.user.id,
    req.params.id
  );

  return res.status(200).json({
    success: true,
    data:    { category },
  });
}

// ── POST /api/v1/categories ───────────────────────────────────────────────────
/**
 * Creates a new custom category for the authenticated user.
 * Response 201: { success, message, data: { category } }
 */
async function create(req, res) {
  const category = await categoriesService.createCategory(req.user.id, req.body);

  return res.status(201).json({
    success: true,
    message: "Category created successfully",
    data:    { category },
  });
}

// ── PATCH /api/v1/categories/:id ──────────────────────────────────────────────
/**
 * Updates a custom category. Returns 403 if it's a system category.
 * Response 200: { success, message, data: { category } }
 */
async function update(req, res) {
  const category = await categoriesService.updateCategory(
    req.user.id,
    req.params.id,
    req.body
  );

  return res.status(200).json({
    success: true,
    message: "Category updated successfully",
    data:    { category },
  });
}

// ── DELETE /api/v1/categories/:id ─────────────────────────────────────────────
/**
 * Deletes a custom category and nullifies its usage in transactions.
 * Returns 403 if it's a system category.
 * Response 200: { success, message }
 */
async function remove(req, res) {
  await categoriesService.deleteCategory(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    message: "Category deleted successfully. Affected transactions have been uncategorised.",
  });
}

module.exports = { list, getById, create, update, remove };
