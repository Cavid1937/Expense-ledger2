// src/modules/auth/auth.schema.js
// =============================================================================
// Zod validation schemas for all Auth module endpoints.
//
// These schemas act as the single source of truth for what shape the request
// body must be in. They are used by the validate() middleware BEFORE the
// request reaches the controller, so the controller can assume clean data.
// =============================================================================

const { z } = require("zod");

// ── Register ──────────────────────────────────────────────────────────────────
const registerSchema = z.object({
  email: z
    .string({ required_error: "Email is required" })
    .trim()
    .toLowerCase()                                  // Normalise before DB insert
    .email("Must be a valid email address")
    .max(255, "Email must be under 255 characters"),

  password: z
    .string({ required_error: "Password is required" })
    .min(8,  "Password must be at least 8 characters")
    .max(72, "Password must be under 72 characters") // bcrypt hard limit
    // Require at least one letter AND one number for basic strength
    .regex(/[a-zA-Z]/, "Password must contain at least one letter")
    .regex(/[0-9]/,    "Password must contain at least one number"),

  full_name: z
    .string()
    .trim()
    .max(100, "Name must be under 100 characters")
    .optional(),

  // Optional initial currency setting; defaults are set in the service layer
  currency_code: z
    .string()
    .trim()
    .toUpperCase()
    .length(3, "Currency code must be exactly 3 characters (e.g. USD)")
    .optional()
    .default("USD"),

  currency_symbol: z
    .string()
    .trim()
    .max(5, "Currency symbol must be under 5 characters")
    .optional()
    .default("$"),

  timezone: z
    .string()
    .trim()
    .max(100)
    .optional()
    .default("UTC"),
});

// ── Login ─────────────────────────────────────────────────────────────────────
const loginSchema = z.object({
  email: z
    .string({ required_error: "Email is required" })
    .trim()
    .toLowerCase()
    .email("Must be a valid email address"),

  password: z
    .string({ required_error: "Password is required" })
    .min(1, "Password is required"),
});

// ── Refresh Token ─────────────────────────────────────────────────────────────
const refreshTokenSchema = z.object({
  refresh_token: z
    .string({ required_error: "Refresh token is required" })
    .min(1, "Refresh token is required"),
});

// ── Forgot Password ───────────────────────────────────────────────────────────
const forgotPasswordSchema = z.object({
  email: z
    .string({ required_error: "Email is required" })
    .trim()
    .toLowerCase()
    .email("Must be a valid email address"),
});

// ── Reset Password ────────────────────────────────────────────────────────────
const resetPasswordSchema = z.object({
  token: z
    .string({ required_error: "Reset token is required" })
    .min(1),

  new_password: z
    .string({ required_error: "New password is required" })
    .min(8,  "Password must be at least 8 characters")
    .max(72)
    .regex(/[a-zA-Z]/, "Password must contain at least one letter")
    .regex(/[0-9]/,    "Password must contain at least one number"),
});

module.exports = {
  registerSchema,
  loginSchema,
  refreshTokenSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
};
