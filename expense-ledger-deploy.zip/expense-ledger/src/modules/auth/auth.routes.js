// src/modules/auth/auth.routes.js
// =============================================================================
// Auth module route definitions.
//
// This file only wires:
//   HTTP method + path → middleware chain → controller handler
//
// It imports nothing from the DB or business logic directly.
// All validation happens via the validate() middleware BEFORE the controller.
// All auth-gated routes require the authenticate middleware first.
// =============================================================================

const { Router } = require("express");
const authController = require("./auth.controller");
const { validate }   = require("../../middleware/validate");
const { authenticate } = require("../../middleware/auth");
const {
  registerSchema,
  loginSchema,
  refreshTokenSchema,
} = require("./auth.schema");

const router = Router();

// ── Public routes (no JWT required) ──────────────────────────────────────────

/**
 * POST /api/v1/auth/register
 * Body: { email, password, full_name?, currency_code?, currency_symbol?, timezone? }
 */
router.post(
  "/register",
  validate(registerSchema),         // 1. Validate & sanitise body
  authController.register           // 2. Handle business logic + response
);

/**
 * POST /api/v1/auth/login
 * Body: { email, password }
 */
router.post(
  "/login",
  validate(loginSchema),
  authController.login
);

/**
 * POST /api/v1/auth/refresh
 * Body: { refresh_token }
 * Issues a new access token when the current one expires.
 */
router.post(
  "/refresh",
  validate(refreshTokenSchema),
  authController.refresh
);

// ── Protected routes (JWT required) ──────────────────────────────────────────

/**
 * POST /api/v1/auth/logout
 * Headers: { Authorization: "Bearer <accessToken>" }
 * Invalidates the user's refresh token server-side.
 */
router.post(
  "/logout",
  authenticate,                     // 1. Verify JWT, attach req.user
  authController.logout             // 2. Clear refresh token
);

/**
 * GET /api/v1/auth/me
 * Headers: { Authorization: "Bearer <accessToken>" }
 * Returns the currently authenticated user's profile.
 */
router.get(
  "/me",
  authenticate,
  authController.me
);

module.exports = router;
