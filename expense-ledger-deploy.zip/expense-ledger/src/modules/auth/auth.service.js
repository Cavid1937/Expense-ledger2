// src/modules/auth/auth.service.js
// =============================================================================
// Auth business logic layer. This is the ONLY place that:
//   - Hashes passwords with bcrypt
//   - Issues and verifies JWTs
//   - Reads/writes users in the database
//
// Controllers call these functions and handle only HTTP concerns (req/res).
// This separation makes the logic independently unit-testable.
// =============================================================================

const bcrypt      = require("bcryptjs");
const jwt         = require("jsonwebtoken");
const crypto      = require("crypto");
const { db }      = require("../../config/database");
const { AppError } = require("../../middleware/errorHandler");
const logger      = require("../../utils/logger");

// ── Constants ─────────────────────────────────────────────────────────────────
const BCRYPT_SALT_ROUNDS = 12;  // High enough for security, not too slow for UX

// ── Token helpers ─────────────────────────────────────────────────────────────

/**
 * Signs a short-lived JWT access token.
 * Payload uses the IANA-registered "sub" (subject) claim = user UUID.
 *
 * @param   {string} userId - User UUID
 * @returns {string}  Signed JWT access token
 */
function signAccessToken(userId) {
  return jwt.sign(
    { sub: userId },
    process.env.JWT_ACCESS_SECRET,
    {
      expiresIn: process.env.JWT_ACCESS_EXPIRES || "15m",
      issuer:    "expense-ledger-api",
      audience:  "expense-ledger-app",
    }
  );
}

/**
 * Signs a long-lived JWT refresh token.
 * The raw token is returned to the client; only its hash is stored in the DB.
 *
 * @param   {string} userId - User UUID
 * @returns {string}  Signed JWT refresh token
 */
function signRefreshToken(userId) {
  return jwt.sign(
    { sub: userId },
    process.env.JWT_REFRESH_SECRET,
    {
      expiresIn: process.env.JWT_REFRESH_EXPIRES || "30d",
      issuer:    "expense-ledger-api",
      audience:  "expense-ledger-app",
    }
  );
}

/**
 * SHA-256 hashes a token for safe database storage.
 * We never store raw refresh tokens — only their hashes — so a DB leak
 * cannot be used to impersonate users directly.
 *
 * @param   {string} token
 * @returns {string} Hex-encoded SHA-256 hash
 */
function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

/**
 * Builds the standardised token response object sent to the client.
 * The client stores both tokens; uses the access token for API calls,
 * and the refresh token to get a new access token when it expires.
 *
 * @param   {string} userId
 * @returns {{ accessToken: string, refreshToken: string, expiresIn: number }}
 */
function buildTokenPair(userId) {
  const accessToken  = signAccessToken(userId);
  const refreshToken = signRefreshToken(userId);
  return { accessToken, refreshToken, expiresIn: 15 * 60 }; // 15 min in seconds
}

// ── Service methods ───────────────────────────────────────────────────────────

/**
 * Registers a new user.
 *
 * Steps:
 *  1. Check for duplicate email.
 *  2. Hash the password with bcrypt.
 *  3. Insert the user row into the "users" table.
 *  4. Issue a token pair.
 *  5. Store the hashed refresh token back on the user row.
 *  6. Return sanitised user data + tokens.
 *
 * @param   {object} data - Validated body from registerSchema
 * @returns {{ user: object, tokens: object }}
 */
async function register(data) {
  const { email, password, full_name, currency_code, currency_symbol, timezone } = data;

  // ── 1. Duplicate email check ───────────────────────────────────────────────
  // We do this before hashing to fail fast (hashing is intentionally slow).
  const existing = await db("users")
    .where({ email })
    .whereNull("deleted_at")
    .select("id")
    .first();

  if (existing) {
    // 409 Conflict — the resource (email) already exists
    throw new AppError("An account with that email address already exists.", 409);
  }

  // ── 2. Hash password ───────────────────────────────────────────────────────
  // bcrypt automatically generates and embeds a salt. The salt rounds (12)
  // mean ~300ms on modern hardware — slow enough to deter brute-force,
  // fast enough for a normal login.
  const password_hash = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);

  // ── 3. Insert user ─────────────────────────────────────────────────────────
  // Column names match 001_create_users.js migration EXACTLY.
  const [newUser] = await db("users")
    .insert({
      email,
      password_hash,
      full_name:       full_name || null,
      currency_code:   currency_code   || "USD",
      currency_symbol: currency_symbol || "$",
      timezone:        timezone        || "UTC",
      email_verified:  false,
      // created_at and updated_at are handled by Knex timestamps(true, true)
    })
    .returning([
      "id",
      "email",
      "full_name",
      "currency_code",
      "currency_symbol",
      "timezone",
      "email_verified",
      "created_at",
    ]);

  // ── 4 & 5. Issue tokens and store refresh token hash ──────────────────────
  const tokens = buildTokenPair(newUser.id);

  await db("users")
    .where({ id: newUser.id })
    .update({
      refresh_token_hash: hashToken(tokens.refreshToken),
      token_issued_at:    new Date(),
    });

  logger.info(`[auth.service] New user registered: ${newUser.email} (${newUser.id})`);

  // ── 6. Return safe user object (no password_hash) ─────────────────────────
  return { user: newUser, tokens };
}

/**
 * Logs in an existing user.
 *
 * Steps:
 *  1. Look up user by email.
 *  2. Compare password against stored hash with bcrypt.
 *  3. Issue a new token pair.
 *  4. Update stored refresh token hash.
 *  5. Return sanitised user data + tokens.
 *
 * Security note: We use the SAME error message for "user not found" and
 * "wrong password" to prevent user-enumeration attacks.
 *
 * @param   {object} data - Validated body from loginSchema
 * @returns {{ user: object, tokens: object }}
 */
async function login(data) {
  const { email, password } = data;

  // ── 1. Find user ───────────────────────────────────────────────────────────
  const user = await db("users")
    .where({ email })
    .whereNull("deleted_at")
    .select(
      "id",
      "email",
      "password_hash",   // Needed for bcrypt.compare — NOT returned to client
      "full_name",
      "currency_code",
      "currency_symbol",
      "timezone",
      "email_verified",
      "created_at"
    )
    .first();

  // ── 2. Validate password ───────────────────────────────────────────────────
  // bcrypt.compare does a constant-time comparison to prevent timing attacks.
  // We call it even if user is null (with a dummy hash) so response time
  // doesn't reveal whether the email exists.
  const dummyHash = "$2a$12$invalidhashfortimingprotectiononly00000000000000000000";
  const hashToCompare = user ? user.password_hash : dummyHash;
  const passwordMatch = await bcrypt.compare(password, hashToCompare);

  if (!user || !passwordMatch) {
    // 401 — same message for both cases (anti-enumeration)
    throw new AppError("Invalid email or password.", 401);
  }

  // ── 3 & 4. Issue tokens and update refresh hash ────────────────────────────
  const tokens = buildTokenPair(user.id);

  await db("users")
    .where({ id: user.id })
    .update({
      refresh_token_hash: hashToken(tokens.refreshToken),
      token_issued_at:    new Date(),
    });

  logger.info(`[auth.service] User logged in: ${user.email} (${user.id})`);

  // ── 5. Return user without sensitive fields ────────────────────────────────
  const { password_hash, ...safeUser } = user;
  return { user: safeUser, tokens };
}

/**
 * Issues a new access token using a valid refresh token.
 *
 * Steps:
 *  1. Verify the refresh token's JWT signature.
 *  2. Look up the user and compare the stored hash.
 *  3. Issue a fresh token pair (rotation — old refresh token is invalidated).
 *
 * @param   {string} refreshToken - Raw refresh token from the client
 * @returns {{ tokens: object }}
 */
async function refreshTokens(refreshToken) {
  // ── 1. Verify JWT signature ────────────────────────────────────────────────
  let decoded;
  try {
    decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
  } catch {
    throw new AppError("Invalid or expired refresh token.", 401);
  }

  // ── 2. Verify stored hash matches ──────────────────────────────────────────
  const user = await db("users")
    .where({ id: decoded.sub })
    .whereNull("deleted_at")
    .select("id", "email", "refresh_token_hash")
    .first();

  if (!user || user.refresh_token_hash !== hashToken(refreshToken)) {
    // Token reuse detected (or user deleted) — invalidate all sessions
    if (user) {
      await db("users").where({ id: user.id }).update({ refresh_token_hash: null });
    }
    throw new AppError("Refresh token is no longer valid. Please log in again.", 401);
  }

  // ── 3. Rotate tokens ───────────────────────────────────────────────────────
  const tokens = buildTokenPair(user.id);

  await db("users")
    .where({ id: user.id })
    .update({
      refresh_token_hash: hashToken(tokens.refreshToken),
      token_issued_at:    new Date(),
    });

  return { tokens };
}

/**
 * Logs out a user by clearing their stored refresh token hash.
 * This invalidates the refresh token server-side so it can't be reused.
 * The short-lived access token will expire naturally (max 15 minutes).
 *
 * @param {string} userId - UUID of the authenticated user (from req.user)
 */
async function logout(userId) {
  await db("users")
    .where({ id: userId })
    .update({ refresh_token_hash: null });

  logger.info(`[auth.service] User logged out: ${userId}`);
}

module.exports = { register, login, refreshTokens, logout };
