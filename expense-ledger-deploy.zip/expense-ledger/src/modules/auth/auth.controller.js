// src/modules/auth/auth.controller.js
// =============================================================================
// Auth HTTP controller. Each function handles exactly one endpoint.
//
// Responsibilities:
//   ✅ Read from req (body, params, user)
//   ✅ Call the appropriate service function
//   ✅ Send the HTTP response
//
// NOT responsible for:
//   ❌ Business logic (that lives in auth.service.js)
//   ❌ Database queries (that lives in auth.service.js)
//   ❌ Input validation (that lives in auth.schema.js + validate middleware)
//
// All controller functions are async. The "express-async-errors" package
// (required in app.js) ensures any thrown error is forwarded to the global
// errorHandler automatically — no need for try/catch in every handler.
// =============================================================================

const authService = require("./auth.service");

// ── POST /api/v1/auth/register ────────────────────────────────────────────────
/**
 * Registers a new user account.
 * Request body is pre-validated by the validate(registerSchema) middleware.
 *
 * Response 201: { success, message, data: { user, tokens } }
 */
async function register(req, res) {
  // req.body is already validated and sanitised by the validate() middleware
  const { user, tokens } = await authService.register(req.body);

  return res.status(201).json({
    success: true,
    message: "Account created successfully",
    data:    { user, tokens },
  });
}

// ── POST /api/v1/auth/login ───────────────────────────────────────────────────
/**
 * Authenticates an existing user and issues a token pair.
 *
 * Response 200: { success, message, data: { user, tokens } }
 */
async function login(req, res) {
  const { user, tokens } = await authService.login(req.body);

  return res.status(200).json({
    success: true,
    message: "Logged in successfully",
    data:    { user, tokens },
  });
}

// ── POST /api/v1/auth/refresh ─────────────────────────────────────────────────
/**
 * Issues a new access token (and rotates the refresh token) when the
 * current access token has expired.
 *
 * Response 200: { success, message, data: { tokens } }
 */
async function refresh(req, res) {
  const { refresh_token } = req.body;
  const { tokens } = await authService.refreshTokens(refresh_token);

  return res.status(200).json({
    success: true,
    message: "Tokens refreshed successfully",
    data:    { tokens },
  });
}

// ── POST /api/v1/auth/logout ──────────────────────────────────────────────────
/**
 * Logs out the authenticated user by invalidating their refresh token.
 * Requires the authenticate middleware (user must be logged in to log out).
 *
 * Response 200: { success, message }
 */
async function logout(req, res) {
  // req.user is attached by the authenticate middleware
  await authService.logout(req.user.id);

  return res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
}

// ── GET /api/v1/auth/me ───────────────────────────────────────────────────────
/**
 * Returns the currently authenticated user's profile.
 * req.user is populated by the authenticate middleware — no extra DB call needed.
 *
 * Response 200: { success, data: { user } }
 */
async function me(req, res) {
  return res.status(200).json({
    success: true,
    data:    { user: req.user },
  });
}

module.exports = { register, login, refresh, logout, me };
