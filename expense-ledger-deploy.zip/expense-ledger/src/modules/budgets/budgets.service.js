// src/modules/budgets/budgets.service.js
// =============================================================================
// Budgets business logic layer.
//
// Core concept:
//   A Budget row defines a spending LIMIT (limit_cents) for a given period.
//   It may be scoped to a specific category (category_id) or NULL (overall).
//
// The key function here is calculateBudgetProgress(), which:
//   1. Fetches one or all budgets for the user
//   2. For each budget, queries the transactions table for the total expense
//      amount within the budget's period (and category if applicable)
//   3. Returns the remaining amount, percentage used, and an "exceeded" flag
//
// This calculation intentionally happens in the service layer (not the DB) so
// the logic is easy to unit-test without mocking complex SQL aggregates.
// =============================================================================

const { db }        = require("../../config/database");
const { AppError }  = require("../../middleware/errorHandler");
const logger        = require("../../utils/logger");

// ── Private helpers ───────────────────────────────────────────────────────────

/**
 * Computes the total expense amount (in cents) for a given user, date range,
 * and optional category. This is the core aggregation that powers budget progress.
 *
 * NULL category_id = sum ALL expense categories (used for overall budgets).
 *
 * @param {string}      userId
 * @param {string}      periodStart - YYYY-MM-DD
 * @param {string}      periodEnd   - YYYY-MM-DD
 * @param {string|null} categoryId  - UUID or null for overall
 * @returns {number} Total spent in cents
 */
async function sumExpensesForPeriod(userId, periodStart, periodEnd, categoryId) {
  const query = db("transactions")
    .where("user_id", userId)
    .where("type",    "expense")           // Only expenses count against budgets
    .whereNull("deleted_at")
    .where("date", ">=", periodStart)
    .where("date", "<=", periodEnd)
    .sum("amount_cents as total")
    .first();

  // Scope to the category if one is specified
  if (categoryId) {
    query.where("category_id", categoryId);
  }

  const result = await query;
  // pg returns SUM as a string or null (when no rows match) — coerce to number
  return parseInt(result?.total || "0", 10);
}

/**
 * Attaches progress data to a budget object.
 * Returns the budget enriched with:
 *   - spent_cents:     how much has been spent in this period
 *   - remaining_cents: limit_cents - spent_cents (can be negative if over)
 *   - percent_used:    (spent / limit) * 100, capped at 100 for display
 *   - is_exceeded:     true if spent > limit
 *   - alert_triggered: true if percent_used >= alert_at_percent
 *
 * @param {object} budget - Budget row from the DB
 * @param {string} userId
 * @returns {object} Budget with progress fields attached
 */
async function enrichWithProgress(budget, userId) {
  const spentCents = await sumExpensesForPeriod(
    userId,
    budget.period_start,
    budget.period_end,
    budget.category_id  // null for overall budgets
  );

  const remainingCents = budget.limit_cents - spentCents;
  const percentUsed    = budget.limit_cents > 0
    ? Math.round((spentCents / budget.limit_cents) * 100)
    : 0;

  return {
    ...budget,
    spent_cents:     spentCents,
    remaining_cents: remainingCents,
    percent_used:    percentUsed,
    is_exceeded:     spentCents > budget.limit_cents,
    alert_triggered: percentUsed >= budget.alert_at_percent,
  };
}

// ── Public service methods ────────────────────────────────────────────────────

/**
 * Creates a new budget for the authenticated user.
 *
 * Enforces uniqueness: a user cannot have two budgets for the same
 * category + period_start combination (handled by DB unique constraint,
 * but we surface a clean error message here).
 *
 * @param {string} userId
 * @param {object} data - Validated body from createBudgetSchema
 * @returns {object} Created budget row with progress data
 */
async function createBudget(userId, data) {
  const {
    category_id, limit_cents, period, period_start,
    period_end, alert_at_percent, rollover,
  } = data;

  // Check for duplicate budget (same user + category + period_start)
  const existing = await db("budgets")
    .where({
      user_id:     userId,
      // Use IS NULL / = for the nullable category_id
      ...(category_id ? { category_id } : {}),
      period_start,
    })
    .modify((qb) => {
      if (!category_id) qb.whereNull("category_id");
    })
    .first();

  if (existing) {
    const label = category_id ? "this category" : "overall spending";
    throw new AppError(
      `A budget for ${label} starting ${period_start} already exists. ` +
      `Update the existing budget instead.`,
      409
    );
  }

  const [budget] = await db("budgets")
    .insert({
      user_id:          userId,
      category_id:      category_id || null,
      limit_cents,
      period,
      period_start,
      period_end,
      alert_at_percent: alert_at_percent ?? 80,
      rollover:         rollover ?? false,
      is_active:        true,
      alert_sent:       false,
    })
    .returning("*");

  logger.info(
    `[budgets] Created budget ${budget.id} for user ${userId} ` +
    `(limit: ${limit_cents} cents, category: ${category_id || "overall"})`
  );

  return enrichWithProgress(budget, userId);
}

/**
 * Returns all budgets for the user, each enriched with live progress data.
 * Optionally filters by month (any budget whose period overlaps the month)
 * or by category.
 *
 * @param {string} userId
 * @param {object} filters - Validated query params from listBudgetsSchema
 * @returns {object[]} Array of budgets with progress data
 */
async function listBudgets(userId, filters) {
  const { month, category_id, is_active } = filters;

  const query = db("budgets as b")
    .where("b.user_id", userId)
    .select("b.*", "c.name as category_name", "c.icon as category_icon", "c.color as category_color")
    .leftJoin("categories as c", "b.category_id", "c.id")
    .orderBy("b.period_start", "desc");

  if (month) {
    // Include any budget whose period overlaps the given month
    const monthStart = `${month}-01`;
    // Last day = first of next month minus 1 — we use a simple range check
    query
      .where("b.period_start", "<=", db.raw("(DATE_TRUNC('month', ?::date) + INTERVAL '1 month' - INTERVAL '1 day')::date", [monthStart]))
      .where("b.period_end",   ">=", monthStart);
  }

  if (category_id !== undefined) {
    if (category_id === null) {
      query.whereNull("b.category_id");
    } else {
      query.where("b.category_id", category_id);
    }
  }

  if (is_active !== undefined) {
    query.where("b.is_active", is_active);
  }

  const budgets = await query;

  // Enrich all budgets in parallel for performance
  return Promise.all(budgets.map((b) => enrichWithProgress(b, userId)));
}

/**
 * Returns a single budget by ID, enriched with live progress data.
 *
 * @param {string} userId
 * @param {string} budgetId
 * @returns {object} Budget with progress data
 */
async function getBudgetById(userId, budgetId) {
  const budget = await db("budgets as b")
    .where({ "b.id": budgetId, "b.user_id": userId })
    .select("b.*", "c.name as category_name", "c.icon as category_icon", "c.color as category_color")
    .leftJoin("categories as c", "b.category_id", "c.id")
    .first();

  if (!budget) {
    throw new AppError("Budget not found.", 404);
  }

  return enrichWithProgress(budget, userId);
}

/**
 * THE CORE FUNCTION: calculateBudgetProgress
 * ===========================================
 * Returns a detailed progress report for all active budgets in a given month.
 * This is the function called by the dashboard to render budget bars.
 *
 * For each active budget it returns:
 *  - All budget fields
 *  - spent_cents:     total expenses in the period matching the category
 *  - remaining_cents: how much is left (negative means over budget)
 *  - percent_used:    0–100 (percentage of limit consumed)
 *  - is_exceeded:     boolean flag for UI warning state
 *  - alert_triggered: boolean — true when percent_used >= alert_at_percent
 *
 * Mathematical logic:
 *   remaining_cents = limit_cents - SUM(amount_cents WHERE type='expense'
 *                                       AND date BETWEEN period_start AND period_end
 *                                       AND (category_id = budget.category_id OR budget is overall))
 *
 * @param {string} userId
 * @param {string} month - "YYYY-MM" — defaults to current month
 * @returns {object} { month, budgets: object[], total_budget_cents, total_spent_cents }
 */
async function calculateBudgetProgress(userId, month) {
  const targetMonth = month || new Date().toISOString().slice(0, 7);

  // Fetch all active budgets that cover this month
  const activeBudgets = await listBudgets(userId, {
    month:     targetMonth,
    is_active: true,
  });

  // Roll up totals for summary display
  const totalBudgetCents = activeBudgets.reduce((sum, b) => sum + b.limit_cents,  0);
  const totalSpentCents  = activeBudgets.reduce((sum, b) => sum + b.spent_cents,  0);
  const totalRemaining   = totalBudgetCents - totalSpentCents;

  // Separate overall budgets from category-specific budgets for UI grouping
  const overallBudgets   = activeBudgets.filter((b) => !b.category_id);
  const categoryBudgets  = activeBudgets.filter((b) =>  b.category_id);

  return {
    month:               targetMonth,
    overall_budgets:     overallBudgets,
    category_budgets:    categoryBudgets,
    total_budget_cents:  totalBudgetCents,
    total_spent_cents:   totalSpentCents,
    total_remaining_cents: totalRemaining,
    total_percent_used:  totalBudgetCents > 0
      ? Math.round((totalSpentCents / totalBudgetCents) * 100)
      : 0,
    budgets_exceeded:    activeBudgets.filter((b) => b.is_exceeded).length,
    alerts_triggered:    activeBudgets.filter((b) => b.alert_triggered && !b.alert_sent).length,
  };
}

/**
 * Updates a budget's settings (limit, period, alert threshold, etc.).
 *
 * @param {string} userId
 * @param {string} budgetId
 * @param {object} updates - Validated partial body from updateBudgetSchema
 * @returns {object} Updated budget with fresh progress data
 */
async function updateBudget(userId, budgetId, updates) {
  const budget = await db("budgets")
    .where({ id: budgetId, user_id: userId })
    .first();

  if (!budget) {
    throw new AppError("Budget not found.", 404);
  }

  const [updated] = await db("budgets")
    .where({ id: budgetId })
    .update({
      ...updates,
      // When limit or period changes, reset the alert_sent flag so the
      // notification fires again if the new limit is breached
      alert_sent: updates.limit_cents || updates.period_start || updates.period_end
        ? false
        : budget.alert_sent,
      updated_at: new Date(),
    })
    .returning("*");

  logger.info(`[budgets] Updated budget ${budgetId} for user ${userId}`);

  return enrichWithProgress(updated, userId);
}

/**
 * Hard-deletes a budget. Budgets have no balance side-effects
 * (they're observational), so no rollback logic is needed.
 *
 * @param {string} userId
 * @param {string} budgetId
 */
async function deleteBudget(userId, budgetId) {
  const deleted = await db("budgets")
    .where({ id: budgetId, user_id: userId })
    .delete();

  if (!deleted) {
    throw new AppError("Budget not found.", 404);
  }

  logger.info(`[budgets] Deleted budget ${budgetId} for user ${userId}`);
}

module.exports = {
  createBudget,
  listBudgets,
  getBudgetById,
  calculateBudgetProgress,
  updateBudget,
  deleteBudget,
};
