// src/modules/budgets/budgets.controller.js
// =============================================================================
// Budgets HTTP controller. One function per endpoint.
// Follows the same pattern as transactions.controller.js.
// =============================================================================

const budgetsService = require("./budgets.service");

// ── POST /api/v1/budgets ──────────────────────────────────────────────────────
/**
 * Creates a new budget for a category (or overall if no category_id).
 * Response 201: { success, message, data: { budget } }
 */
async function create(req, res) {
  const budget = await budgetsService.createBudget(req.user.id, req.body);

  return res.status(201).json({
    success: true,
    message: "Budget created successfully",
    data:    { budget },
  });
}

// ── GET /api/v1/budgets ───────────────────────────────────────────────────────
/**
 * Lists all budgets for the authenticated user, with live progress data.
 * Query params: month=YYYY-MM, category_id, is_active
 * Response 200: { success, data: { budgets } }
 */
async function list(req, res) {
  const budgets = await budgetsService.listBudgets(req.user.id, req.query);

  return res.status(200).json({
    success: true,
    data:    { budgets },
  });
}

// ── GET /api/v1/budgets/progress ──────────────────────────────────────────────
/**
 * Returns the full budget progress report for a given month.
 * This is the primary endpoint used by the dashboard.
 * Query param: month=YYYY-MM (defaults to current month)
 * Response 200: { success, data: { progress } }
 */
async function progress(req, res) {
  const month = req.query.month;

  // Basic format validation
  if (month && !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({
      success: false,
      message: "month query param must be in YYYY-MM format (e.g. 2025-01)",
    });
  }

  const progressData = await budgetsService.calculateBudgetProgress(
    req.user.id,
    month
  );

  return res.status(200).json({
    success: true,
    data:    { progress: progressData },
  });
}

// ── GET /api/v1/budgets/:id ───────────────────────────────────────────────────
/**
 * Returns a single budget with its live progress data.
 * Response 200: { success, data: { budget } }
 */
async function getById(req, res) {
  const budget = await budgetsService.getBudgetById(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    data:    { budget },
  });
}

// ── PATCH /api/v1/budgets/:id ─────────────────────────────────────────────────
/**
 * Updates a budget's settings. Returns the budget with updated progress data.
 * Response 200: { success, message, data: { budget } }
 */
async function update(req, res) {
  const budget = await budgetsService.updateBudget(
    req.user.id,
    req.params.id,
    req.body
  );

  return res.status(200).json({
    success: true,
    message: "Budget updated successfully",
    data:    { budget },
  });
}

// ── DELETE /api/v1/budgets/:id ────────────────────────────────────────────────
/**
 * Permanently deletes a budget (no balance side-effects).
 * Response 200: { success, message }
 */
async function remove(req, res) {
  await budgetsService.deleteBudget(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    message: "Budget deleted successfully",
  });
}

module.exports = { create, list, progress, getById, update, remove };
