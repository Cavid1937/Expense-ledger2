// src/modules/budgets/budgets.routes.js
// =============================================================================
// Budgets module route definitions.
//
// All routes are protected — JWT required on every request.
// "/progress" is registered before "/:id" to prevent Express from matching
// "progress" as a UUID parameter.
// =============================================================================

const { Router }       = require("express");
const budgetsCtrl      = require("./budgets.controller");
const { validate }     = require("../../middleware/validate");
const { authenticate } = require("../../middleware/auth");
const {
  createBudgetSchema,
  updateBudgetSchema,
  listBudgetsSchema,
} = require("./budgets.schema");

const router = Router();

// Every budget route requires authentication
router.use(authenticate);

// ── Aggregate / special routes (must come before /:id) ───────────────────────

/**
 * GET /api/v1/budgets/progress?month=YYYY-MM
 * Returns the full calculateBudgetProgress report for the dashboard.
 */
router.get("/progress", budgetsCtrl.progress);

// ── Collection routes ─────────────────────────────────────────────────────────

/**
 * POST /api/v1/budgets
 * Body: { limit_cents, period, period_start, period_end, category_id?, ... }
 */
router.post(
  "/",
  validate(createBudgetSchema),
  budgetsCtrl.create
);

/**
 * GET /api/v1/budgets
 * Query: month=YYYY-MM, category_id, is_active
 */
router.get(
  "/",
  (req, res, next) => {
    const result = listBudgetsSchema.safeParse(req.query);
    if (!result.success) return next(result.error);
    req.query = result.data;
    next();
  },
  budgetsCtrl.list
);

// ── Resource routes ───────────────────────────────────────────────────────────

/**
 * GET /api/v1/budgets/:id
 */
router.get("/:id", budgetsCtrl.getById);

/**
 * PATCH /api/v1/budgets/:id
 * Body: any subset of budget fields (all optional)
 */
router.patch(
  "/:id",
  validate(updateBudgetSchema),
  budgetsCtrl.update
);

/**
 * DELETE /api/v1/budgets/:id
 */
router.delete("/:id", budgetsCtrl.remove);

module.exports = router;
