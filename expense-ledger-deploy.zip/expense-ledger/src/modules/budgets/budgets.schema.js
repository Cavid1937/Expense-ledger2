// src/modules/budgets/budgets.schema.js
// =============================================================================
// Zod validation schemas for the Budgets module.
//
// Key rules:
//  - category_id is nullable → NULL means an "overall" budget (all categories)
//  - period_start must be before period_end
//  - limit_cents must be a positive integer (stored in cents, same as transactions)
//  - alert_at_percent must be 1–100
// =============================================================================

const { z } = require("zod");

// ── Create Budget ─────────────────────────────────────────────────────────────
const createBudgetSchema = z
  .object({
    // NULL = overall budget (not tied to a specific category)
    category_id: z
      .string()
      .uuid("category_id must be a valid UUID")
      .optional()
      .nullable(),

    // Budget cap stored in cents — same convention as transactions.amount_cents
    limit_cents: z
      .number({ required_error: "limit_cents is required" })
      .int("limit_cents must be an integer")
      .positive("limit_cents must be greater than zero"),

    period: z
      .enum(["weekly", "monthly", "yearly"], {
        required_error: "period is required",
        invalid_type_error: "period must be one of: weekly, monthly, yearly",
      })
      .default("monthly"),

    // ISO 8601 date strings — we validate the range relationship below
    period_start: z
      .string({ required_error: "period_start is required" })
      .regex(/^\d{4}-\d{2}-\d{2}$/, "period_start must be in YYYY-MM-DD format"),

    period_end: z
      .string({ required_error: "period_end is required" })
      .regex(/^\d{4}-\d{2}-\d{2}$/, "period_end must be in YYYY-MM-DD format"),

    // At what percentage of the budget to fire a push notification
    alert_at_percent: z
      .number()
      .int()
      .min(1,   "alert_at_percent must be at least 1")
      .max(100, "alert_at_percent must be at most 100")
      .default(80),

    // Whether unspent budget rolls over to the next period
    rollover: z.boolean().default(false),
  })
  .refine(
    (data) => new Date(data.period_start) <= new Date(data.period_end),
    {
      message: "period_start must be before or equal to period_end",
      path:    ["period_start"],
    }
  );

// ── Update Budget ─────────────────────────────────────────────────────────────
// All fields optional — only provided fields are updated (PATCH semantics).
const updateBudgetSchema = z
  .object({
    limit_cents:      z.number().int().positive().optional(),
    period:           z.enum(["weekly", "monthly", "yearly"]).optional(),
    period_start:     z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    period_end:       z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    alert_at_percent: z.number().int().min(1).max(100).optional(),
    rollover:         z.boolean().optional(),
    is_active:        z.boolean().optional(),
  })
  .refine(
    (data) => {
      if (data.period_start && data.period_end) {
        return new Date(data.period_start) <= new Date(data.period_end);
      }
      return true;
    },
    {
      message: "period_start must be before or equal to period_end",
      path:    ["period_start"],
    }
  );

// ── Query params for listing budgets ──────────────────────────────────────────
const listBudgetsSchema = z.object({
  // Filter by period containing a specific month
  month:       z.string().regex(/^\d{4}-\d{2}$/, "month must be in YYYY-MM format").optional(),
  category_id: z.string().uuid().optional(),
  is_active:   z.coerce.boolean().optional(),
});

module.exports = { createBudgetSchema, updateBudgetSchema, listBudgetsSchema };
