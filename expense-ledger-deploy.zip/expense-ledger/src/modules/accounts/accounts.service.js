// src/modules/accounts/accounts.service.js
// =============================================================================
// Accounts business logic layer.
//
// Decimal → Cents conversion:
//   All incoming balance values are standard decimals (e.g. 50.25).
//   We convert them to integer cents (5025) before any DB write using the
//   toCents() helper. This is the ONLY place the conversion happens — never
//   in the controller or schema — keeping the responsibility clearly owned.
//
//   Why Math.round? Floating-point arithmetic is imprecise:
//     50.25 * 100 → 5024.999999999999  ← floor() would give 5024 (wrong!)
//     50.25 * 100 → 5024.999999999999  ← Math.round() gives 5025 (correct)
//
// Ownership:
//   Every query is scoped to user_id = userId. A user can never read or
//   modify another user's accounts even if they know a valid UUID.
// =============================================================================

const { db }        = require("../../config/database");
const { AppError }  = require("../../middleware/errorHandler");
const logger        = require("../../utils/logger");

// ── Decimal → Cents conversion ─────────────────────────────────────────────────
/**
 * Converts a decimal currency amount to integer cents.
 * Handles floating-point imprecision via Math.round.
 *
 * Examples:
 *   toCents(50.25)    → 5025
 *   toCents(1000)     → 100000
 *   toCents(-250.99)  → -25099  (credit card debt / overdraft)
 *   toCents(0.1 + 0.2) → 30    (not 29 — Math.round saves us)
 *
 * @param {number} decimal
 * @returns {number} Integer cents
 */
function toCents(decimal) {
  return Math.round(decimal * 100);
}

/**
 * Converts integer cents back to a decimal for any response fields
 * where we want to return human-readable values alongside cents.
 *
 * @param {number} cents
 * @returns {number} Decimal amount rounded to 2 decimal places
 */
function toDecimal(cents) {
  return Math.round(cents) / 100;
}

/**
 * Appends a human-readable balance_decimal field to an account row.
 * The raw balance_cents is always included too so the frontend can
 * do its own math without re-converting.
 */
function formatAccount(account) {
  return {
    ...account,
    balance_decimal: toDecimal(account.balance_cents),
  };
}

// ── Service methods ────────────────────────────────────────────────────────────

/**
 * Creates a new account for the authenticated user.
 *
 * The initial_balance received from the API is a decimal (e.g. 1500.00).
 * We convert it to cents (150000) before inserting.
 *
 * @param {string} userId
 * @param {object} data - Validated body from createAccountSchema
 * @returns {object} Created account with balance_decimal appended
 */
async function createAccount(userId, data) {
  const {
    name, type, initial_balance,
    currency_code, color, icon,
    include_in_total, sort_order,
  } = data;

  // Convert decimal → cents. toCents(0) = 0 for default case.
  const balance_cents = toCents(initial_balance ?? 0);

  const [account] = await db("accounts")
    .insert({
      user_id:          userId,
      name:             name.trim(),
      type,
      balance_cents,
      currency_code:    currency_code || "USD",
      color:            color         || null,
      icon:             icon          || null,
      include_in_total: include_in_total ?? true,
      sort_order:       sort_order    ?? 0,
      is_archived:      false,
    })
    .returning("*");

  logger.info(
    `[accounts] Created account "${account.name}" ` +
    `(${account.id}) for user ${userId} — balance: ${balance_cents} cents`
  );

  return formatAccount(account);
}

/**
 * Returns all non-deleted accounts for the authenticated user,
 * ordered by sort_order then name for a predictable, frictionless list.
 *
 * Includes a computed total_balance_cents across all accounts that have
 * include_in_total = true — useful for the dashboard net worth widget.
 *
 * @param {string} userId
 * @param {object} filters - { include_archived: boolean }
 * @returns {{ accounts: object[], total_balance_cents: number, total_balance_decimal: number }}
 */
async function listAccounts(userId, filters = {}) {
  const { include_archived = false } = filters;

  const query = db("accounts")
    .where({ user_id: userId })
    .orderBy([{ column: "sort_order" }, { column: "name" }]);

  // By default, hide archived accounts to keep the UI clean
  if (!include_archived) {
    query.where({ is_archived: false });
  }

  const accounts = await query.select("*");

  // Compute the net worth total across accounts that should be included
  const total_balance_cents = accounts
    .filter((a) => a.include_in_total)
    .reduce((sum, a) => sum + a.balance_cents, 0);

  return {
    accounts: accounts.map(formatAccount),
    total_balance_cents,
    total_balance_decimal: toDecimal(total_balance_cents),
  };
}

/**
 * Returns a single account by ID, scoped to the authenticated user.
 *
 * @param {string} userId
 * @param {string} accountId
 * @returns {object} Account with balance_decimal
 */
async function getAccountById(userId, accountId) {
  const account = await db("accounts")
    .where({ id: accountId, user_id: userId })
    .first();

  if (!account) {
    throw new AppError("Account not found.", 404);
  }

  return formatAccount(account);
}

/**
 * Updates an account's metadata and/or manually adjusts its balance.
 *
 * The optional adjust_balance field allows users to reconcile their account
 * after checking their bank statement (e.g. "my app says $1,200 but my bank
 * says $1,185 — set it to $1,185"). This sets balance_cents directly to the
 * exact cents value, bypassing the transaction system for manual corrections.
 *
 * All other balance changes MUST go through the transactions module to keep
 * the ledger accurate.
 *
 * @param {string} userId
 * @param {string} accountId
 * @param {object} updates - Validated partial body from updateAccountSchema
 * @returns {object} Updated account with balance_decimal
 */
async function updateAccount(userId, accountId, updates) {
  // Confirm ownership
  const existing = await db("accounts")
    .where({ id: accountId, user_id: userId })
    .first();

  if (!existing) {
    throw new AppError("Account not found.", 404);
  }

  // Build the update payload, only including fields the caller provided
  const patch = {};

  if (updates.name             !== undefined) patch.name             = updates.name.trim();
  if (updates.type             !== undefined) patch.type             = updates.type;
  if (updates.color            !== undefined) patch.color            = updates.color;
  if (updates.icon             !== undefined) patch.icon             = updates.icon;
  if (updates.include_in_total !== undefined) patch.include_in_total = updates.include_in_total;
  if (updates.is_archived      !== undefined) patch.is_archived      = updates.is_archived;
  if (updates.sort_order       !== undefined) patch.sort_order       = updates.sort_order;

  // Manual balance adjustment: convert decimal → cents
  if (updates.adjust_balance !== undefined) {
    patch.balance_cents = toCents(updates.adjust_balance);
    logger.info(
      `[accounts] Manual balance adjustment on ${accountId}: ` +
      `${existing.balance_cents} → ${patch.balance_cents} cents`
    );
  }

  // No fields provided — nothing to update
  if (Object.keys(patch).length === 0) {
    return formatAccount(existing);
  }

  patch.updated_at = new Date();

  const [updated] = await db("accounts")
    .where({ id: accountId })
    .update(patch)
    .returning("*");

  logger.info(`[accounts] Updated account ${accountId} for user ${userId}`);

  return formatAccount(updated);
}

/**
 * Soft-deletes an account.
 *
 * Safety check: refuse to delete an account that still has un-deleted
 * transactions attached to it. The user must reassign or delete those
 * transactions first. This prevents orphaned ledger entries and misleading
 * balance history.
 *
 * @param {string} userId
 * @param {string} accountId
 */
async function deleteAccount(userId, accountId) {
  const account = await db("accounts")
    .where({ id: accountId, user_id: userId })
    .first();

  if (!account) {
    throw new AppError("Account not found.", 404);
  }

  // Count live transactions on this account
  const { count } = await db("transactions")
    .where({ account_id: accountId })
    .whereNull("deleted_at")
    .count("id as count")
    .first();

  if (parseInt(count, 10) > 0) {
    throw new AppError(
      `Cannot delete account "${account.name}" — it has ${count} transaction(s) attached. ` +
      "Delete or reassign those transactions first.",
      409
    );
  }

  await db("accounts")
    .where({ id: accountId })
    .update({ deleted_at: new Date() });

  logger.info(`[accounts] Soft-deleted account ${accountId} for user ${userId}`);
}

module.exports = {
  createAccount,
  listAccounts,
  getAccountById,
  updateAccount,
  deleteAccount,
  toCents,      // Exported for use in other modules (e.g. tests, seeds)
  toDecimal,
};
