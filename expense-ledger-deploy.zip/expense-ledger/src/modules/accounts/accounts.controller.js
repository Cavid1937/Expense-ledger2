// src/modules/accounts/accounts.controller.js
// =============================================================================
// Accounts HTTP controller. One function per endpoint.
// All routes are already guarded by the authenticate middleware in routes.js.
// =============================================================================

const accountsService = require("./accounts.service");

// ── POST /api/v1/accounts ─────────────────────────────────────────────────────
/**
 * Creates a new account with an optional initial balance (decimal input).
 * Response 201: { success, message, data: { account } }
 */
async function create(req, res) {
  const account = await accountsService.createAccount(req.user.id, req.body);

  return res.status(201).json({
    success: true,
    message: "Account created successfully",
    data:    { account },
  });
}

// ── GET /api/v1/accounts ──────────────────────────────────────────────────────
/**
 * Lists all accounts for the authenticated user.
 * Includes the net worth total across accounts marked include_in_total=true.
 * Query param: include_archived=true to see archived accounts.
 * Response 200: { success, data: { accounts, total_balance_cents, total_balance_decimal } }
 */
async function list(req, res) {
  const include_archived = req.query.include_archived === "true";

  const result = await accountsService.listAccounts(req.user.id, {
    include_archived,
  });

  return res.status(200).json({
    success: true,
    data:    result,
  });
}

// ── GET /api/v1/accounts/:id ──────────────────────────────────────────────────
/**
 * Returns a single account by UUID.
 * Response 200: { success, data: { account } }
 */
async function getById(req, res) {
  const account = await accountsService.getAccountById(
    req.user.id,
    req.params.id
  );

  return res.status(200).json({
    success: true,
    data:    { account },
  });
}

// ── PATCH /api/v1/accounts/:id ────────────────────────────────────────────────
/**
 * Updates an account's metadata. Optionally adjusts balance via adjust_balance
 * (decimal input) for manual reconciliation with a bank statement.
 * Response 200: { success, message, data: { account } }
 */
async function update(req, res) {
  const account = await accountsService.updateAccount(
    req.user.id,
    req.params.id,
    req.body
  );

  return res.status(200).json({
    success: true,
    message: "Account updated successfully",
    data:    { account },
  });
}

// ── DELETE /api/v1/accounts/:id ───────────────────────────────────────────────
/**
 * Soft-deletes an account. Fails with 409 if the account has live transactions.
 * Response 200: { success, message }
 */
async function remove(req, res) {
  await accountsService.deleteAccount(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    message: "Account deleted successfully",
  });
}

module.exports = { create, list, getById, update, remove };
