// src/modules/accounts/accounts.routes.js
// =============================================================================
// Accounts module route definitions.
// All routes require a valid JWT (authenticate middleware applied to the router).
// =============================================================================

const { Router }       = require("express");
const accountsCtrl     = require("./accounts.controller");
const { validate }     = require("../../middleware/validate");
const { authenticate } = require("../../middleware/auth");
const {
  createAccountSchema,
  updateAccountSchema,
} = require("./accounts.schema");

const router = Router();

// Apply authentication to every accounts route
router.use(authenticate);

/**
 * POST /api/v1/accounts
 * Body: { name, type, initial_balance?, currency_code?, color?, icon?, ... }
 */
router.post(
  "/",
  validate(createAccountSchema),
  accountsCtrl.create
);

/**
 * GET /api/v1/accounts
 * Query: include_archived=true (optional, default false)
 */
router.get("/", accountsCtrl.list);

/**
 * GET /api/v1/accounts/:id
 */
router.get("/:id", accountsCtrl.getById);

/**
 * PATCH /api/v1/accounts/:id
 * Body: any subset of updatable account fields (all optional)
 *       adjust_balance (decimal) for manual balance correction
 */
router.patch(
  "/:id",
  validate(updateAccountSchema),
  accountsCtrl.update
);

/**
 * DELETE /api/v1/accounts/:id
 * Soft-deletes the account if it has no live transactions.
 */
router.delete("/:id", accountsCtrl.remove);

module.exports = router;
