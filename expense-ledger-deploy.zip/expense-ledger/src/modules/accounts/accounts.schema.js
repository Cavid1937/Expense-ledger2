// src/modules/accounts/accounts.schema.js
// =============================================================================
// Zod validation schemas for the Accounts module.
//
// Key design decision — decimal vs. cents:
//   The API accepts human-friendly decimal amounts (e.g. 50.25) for balance
//   fields, because that's what a personal user types. The service layer is
//   responsible for converting these to integer cents before hitting the DB.
//
//   We use z.number() with a max of 2 decimal places enforced by a .refine()
//   check, and document the expected format clearly in error messages.
// =============================================================================

const { z } = require("zod");

// ── Shared helpers ────────────────────────────────────────────────────────────

/**
 * Validates a decimal currency amount (e.g. 50.25, 1000, -250.00).
 * Negative values are allowed here because credit cards and loans can have
 * negative balances from the user's perspective (money owed).
 * The service layer handles the sign convention when storing.
 */
const decimalAmountField = z
  .number({ invalid_type_error: "Amount must be a number" })
  .multipleOf(0.01, "Amount can have at most 2 decimal places")
  .max(999_999_999.99, "Amount exceeds the maximum allowed value");

const ACCOUNT_TYPES = ["cash", "checking", "savings", "credit_card", "investment", "loan", "other"];

// ── Create Account ────────────────────────────────────────────────────────────
const createAccountSchema = z.object({
  name: z
    .string({ required_error: "Account name is required" })
    .trim()
    .min(1,   "Account name cannot be empty")
    .max(100, "Account name must be under 100 characters"),

  type: z
    .enum(ACCOUNT_TYPES, {
      required_error:    "Account type is required",
      invalid_type_error: `Account type must be one of: ${ACCOUNT_TYPES.join(", ")}`,
    })
    .default("checking"),

  // Initial balance in DECIMAL form — service converts to cents.
  // Default 0 means new accounts start empty unless the user specifies.
  initial_balance: decimalAmountField.default(0),

  currency_code: z
    .string()
    .trim()
    .toUpperCase()
    .length(3, "Currency code must be exactly 3 characters (e.g. USD)")
    .default("USD"),

  color: z
    .string()
    .trim()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Color must be a valid hex code (e.g. #FF6B6B)")
    .optional()
    .nullable(),

  icon: z
    .string()
    .trim()
    .max(50, "Icon identifier must be under 50 characters")
    .optional()
    .nullable(),

  include_in_total: z.boolean().default(true),
  sort_order:       z.number().int().min(0).default(0),
});

// ── Update Account ────────────────────────────────────────────────────────────
// All fields optional — PATCH semantics.
// Note: balance is updated through transactions, NOT directly here.
// We expose an "adjust_balance" field only for manual balance corrections.
const updateAccountSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1,   "Account name cannot be empty")
    .max(100, "Account name must be under 100 characters")
    .optional(),

  type: z.enum(ACCOUNT_TYPES).optional(),

  color: z
    .string()
    .trim()
    .regex(/^#[0-9A-Fa-f]{6}$/, "Color must be a valid hex code (e.g. #FF6B6B)")
    .optional()
    .nullable(),

  icon: z
    .string()
    .trim()
    .max(50)
    .optional()
    .nullable(),

  include_in_total: z.boolean().optional(),
  is_archived:      z.boolean().optional(),
  sort_order:       z.number().int().min(0).optional(),

  // Optional manual balance adjustment (decimal form).
  // When provided, the service will set balance_cents to the exact cents value.
  // Use case: correcting balance after reconciling with a bank statement.
  adjust_balance: decimalAmountField.optional(),
});

module.exports = { createAccountSchema, updateAccountSchema };
