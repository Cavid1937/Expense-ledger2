// src/modules/subscriptions/subscriptions.service.js
// =============================================================================
// Subscriptions business logic layer.
//
// This module handles CRUD for subscription templates. The actual automatic
// transaction creation is handled by the cron job (subscriptions.cron.js),
// which calls processSubscription() from this service to keep all billing
// logic in one place and make it independently testable.
//
// Billing date calculation:
//   computeNextBillingDate() advances a date by one frequency interval.
//   It handles month-end edge cases (e.g. billing on Jan 31 → Feb 28/29,
//   not March 3) using date-fns which is already in our package.json.
// =============================================================================

const {
  addDays, addWeeks, addMonths, addQuarters, addYears,
  parseISO, formatISO,
} = require("date-fns");

const { db }        = require("../../config/database");
const { AppError }  = require("../../middleware/errorHandler");
const logger        = require("../../utils/logger");

// ── Billing date calculator ───────────────────────────────────────────────────

/**
 * Computes the next billing date after a given date, based on the frequency.
 *
 * Uses date-fns helpers which correctly handle:
 *   - Month-end edge cases (Jan 31 + 1 month = Feb 28, not Mar 3)
 *   - Leap years
 *   - DST transitions (date-fns works in local calendar dates)
 *
 * @param {string} fromDate          - YYYY-MM-DD string (current billing date)
 * @param {string} frequency         - One of the FREQUENCIES enum values
 * @param {number|null} intervalDays - Only used when frequency = "custom"
 * @returns {string} Next billing date as YYYY-MM-DD
 */
function computeNextBillingDate(fromDate, frequency, intervalDays = null) {
  const base = parseISO(fromDate);
  let next;

  switch (frequency) {
    case "daily":
      next = addDays(base, 1);
      break;
    case "weekly":
      next = addWeeks(base, 1);
      break;
    case "biweekly":
      next = addWeeks(base, 2);
      break;
    case "monthly":
      next = addMonths(base, 1);
      break;
    case "quarterly":
      next = addQuarters(base, 1);
      break;
    case "yearly":
      next = addYears(base, 1);
      break;
    case "custom":
      if (!intervalDays || intervalDays < 1) {
        throw new AppError("custom_interval_days is required for custom frequency", 400);
      }
      next = addDays(base, intervalDays);
      break;
    default:
      throw new AppError(`Unknown frequency: ${frequency}`, 400);
  }

  // Return as YYYY-MM-DD string (no time component — billing is date-based)
  return formatISO(next, { representation: "date" });
}

// ── CRUD methods ──────────────────────────────────────────────────────────────

/**
 * Creates a new subscription template.
 * Sets next_billing_date = start_date (the first billing happens on start_date).
 *
 * @param {string} userId
 * @param {object} data - Validated body from createSubscriptionSchema
 * @returns {object} Created subscription row
 */
async function createSubscription(userId, data) {
  const {
    name, account_id, category_id, amount_cents,
    frequency, custom_interval_days, start_date, end_date,
    note, logo_url, auto_create_transaction, status,
  } = data;

  // Verify the account belongs to the user
  const account = await db("accounts")
    .where({ id: account_id, user_id: userId })
    .whereNull("deleted_at")
    .first();

  if (!account) {
    throw new AppError("Account not found or access denied.", 404);
  }

  const [subscription] = await db("subscriptions")
    .insert({
      user_id:                 userId,
      account_id,
      category_id:             category_id          || null,
      name:                    name.trim(),
      amount_cents,
      frequency,
      custom_interval_days:    custom_interval_days  || null,
      start_date,
      // First billing is on start_date; cron advances this after each billing
      next_billing_date:       start_date,
      end_date:                end_date             || null,
      note:                    note                 || null,
      logo_url:                logo_url             || null,
      auto_create_transaction: auto_create_transaction ?? true,
      status:                  status               || "active",
      // last_billed_date starts as NULL — the idempotency check uses this
      // to confirm a subscription hasn't already been processed today
    })
    .returning("*");

  logger.info(
    `[subscriptions] Created "${subscription.name}" ` +
    `(${subscription.id}) for user ${userId} — ` +
    `${amount_cents} cents, ${frequency}, next: ${start_date}`
  );

  return subscription;
}

/**
 * Lists all subscriptions for the authenticated user.
 * Joins account and category names for display.
 *
 * @param {string} userId
 * @param {object} filters - { status?: "active" | "paused" }
 * @returns {object[]}
 */
async function listSubscriptions(userId, filters = {}) {
  const query = db("subscriptions as s")
    .where("s.user_id", userId)
    .select(
      "s.*",
      "a.name  as account_name",
      "c.name  as category_name",
      "c.icon  as category_icon",
      "c.color as category_color"
    )
    .leftJoin("accounts    as a", "s.account_id",  "a.id")
    .leftJoin("categories  as c", "s.category_id", "c.id")
    .orderBy("s.next_billing_date", "asc");

  if (filters.status) {
    query.where("s.status", filters.status);
  }

  return query;
}

/**
 * Returns a single subscription by ID, scoped to the user.
 *
 * @param {string} userId
 * @param {string} subscriptionId
 * @returns {object}
 */
async function getSubscriptionById(userId, subscriptionId) {
  const subscription = await db("subscriptions as s")
    .where({ "s.id": subscriptionId, "s.user_id": userId })
    .select("s.*", "a.name as account_name", "c.name as category_name")
    .leftJoin("accounts   as a", "s.account_id",  "a.id")
    .leftJoin("categories as c", "s.category_id", "c.id")
    .first();

  if (!subscription) {
    throw new AppError("Subscription not found.", 404);
  }

  return subscription;
}

/**
 * Updates a subscription's settings.
 * If next_billing_date is explicitly provided in updates, use it directly.
 * Otherwise leave it unchanged (the cron job manages it after billing).
 *
 * @param {string} userId
 * @param {string} subscriptionId
 * @param {object} updates - Validated partial body from updateSubscriptionSchema
 * @returns {object} Updated subscription
 */
async function updateSubscription(userId, subscriptionId, updates) {
  const existing = await db("subscriptions")
    .where({ id: subscriptionId, user_id: userId })
    .first();

  if (!existing) {
    throw new AppError("Subscription not found.", 404);
  }

  const patch = {};
  const fields = [
    "name", "account_id", "category_id", "amount_cents",
    "frequency", "custom_interval_days", "start_date",
    "next_billing_date", "end_date", "note", "logo_url",
    "auto_create_transaction", "status",
  ];

  for (const field of fields) {
    if (updates[field] !== undefined) patch[field] = updates[field];
  }

  if (Object.keys(patch).length === 0) return existing;

  patch.updated_at = new Date();

  const [updated] = await db("subscriptions")
    .where({ id: subscriptionId })
    .update(patch)
    .returning("*");

  logger.info(`[subscriptions] Updated subscription ${subscriptionId} for user ${userId}`);
  return updated;
}

/**
 * Deletes a subscription permanently.
 * Historical transactions that were auto-created by this subscription
 * are retained (subscription_id is set to NULL via SET NULL FK constraint).
 *
 * @param {string} userId
 * @param {string} subscriptionId
 */
async function deleteSubscription(userId, subscriptionId) {
  const deleted = await db("subscriptions")
    .where({ id: subscriptionId, user_id: userId })
    .delete();

  if (!deleted) {
    throw new AppError("Subscription not found.", 404);
  }

  logger.info(`[subscriptions] Deleted subscription ${subscriptionId} for user ${userId}`);
}

/**
 * Core billing function: creates a transaction for one subscription and
 * advances its next_billing_date.
 *
 * This is called BOTH by the cron job (automatic) and can be called manually
 * (e.g. "bill now" button). Keeping this in the service makes it testable.
 *
 * IMPORTANT: This function must always be called inside a Knex DB transaction
 * (the caller is responsible for providing trx). This is enforced by making
 * trx a required parameter and throwing if it's missing.
 *
 * @param {object} trx          - Active Knex transaction (required)
 * @param {object} subscription - Full subscription row from DB
 * @param {string} billingDate  - The date to record the transaction on (YYYY-MM-DD)
 * @returns {object} The created transaction row
 */
async function billSubscription(trx, subscription, billingDate) {
  if (!trx) {
    throw new Error("[billSubscription] Must be called inside a Knex transaction");
  }

  // Insert the transaction record
  const [transaction] = await trx("transactions")
    .insert({
      user_id:         subscription.user_id,
      account_id:      subscription.account_id,
      category_id:     subscription.category_id || null,
      amount_cents:    subscription.amount_cents,
      type:            "expense",   // Subscriptions are always expenses
      date:            billingDate,
      note:            subscription.note || `Auto: ${subscription.name}`,
      subscription_id: subscription.id,
    })
    .returning("*");

  // Deduct from the account balance using atomic SQL increment
  // (balance_cents - amount_cents, expressed as increment of negative value)
  await trx("accounts")
    .where({ id: subscription.account_id })
    .increment("balance_cents", -subscription.amount_cents);

  // Advance the billing date and stamp last_billed_date (idempotency key)
  const nextBillingDate = computeNextBillingDate(
    billingDate,
    subscription.frequency,
    subscription.custom_interval_days
  );

  await trx("subscriptions")
    .where({ id: subscription.id })
    .update({
      last_billed_date:  billingDate,
      next_billing_date: nextBillingDate,
      updated_at:        new Date(),
    });

  return { transaction, nextBillingDate };
}

module.exports = {
  createSubscription,
  listSubscriptions,
  getSubscriptionById,
  updateSubscription,
  deleteSubscription,
  billSubscription,
  computeNextBillingDate,
};
