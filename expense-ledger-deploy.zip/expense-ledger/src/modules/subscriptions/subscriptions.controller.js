// src/modules/subscriptions/subscriptions.controller.js
// =============================================================================
// Subscriptions HTTP controller. One function per endpoint.
// All routes are guarded by the authenticate middleware in routes.js.
// =============================================================================

const subscriptionsService = require("./subscriptions.service");
const { db }               = require("../../config/database");
const logger               = require("../../utils/logger");

// ── POST /api/v1/subscriptions ────────────────────────────────────────────────
/**
 * Creates a new subscription template.
 * Response 201: { success, message, data: { subscription } }
 */
async function create(req, res) {
  const subscription = await subscriptionsService.createSubscription(
    req.user.id,
    req.body
  );

  return res.status(201).json({
    success: true,
    message: "Subscription created successfully",
    data:    { subscription },
  });
}

// ── GET /api/v1/subscriptions ─────────────────────────────────────────────────
/**
 * Lists all subscriptions for the authenticated user.
 * Query param: status=active|paused (optional filter)
 * Response 200: { success, data: { subscriptions } }
 */
async function list(req, res) {
  const { status } = req.query;

  if (status && !["active", "paused"].includes(status)) {
    return res.status(400).json({
      success: false,
      message: "status must be one of: active, paused",
    });
  }

  const subscriptions = await subscriptionsService.listSubscriptions(
    req.user.id,
    { status }
  );

  return res.status(200).json({
    success: true,
    data:    { subscriptions },
  });
}

// ── GET /api/v1/subscriptions/:id ─────────────────────────────────────────────
/**
 * Returns a single subscription by UUID.
 * Response 200: { success, data: { subscription } }
 */
async function getById(req, res) {
  const subscription = await subscriptionsService.getSubscriptionById(
    req.user.id,
    req.params.id
  );

  return res.status(200).json({
    success: true,
    data:    { subscription },
  });
}

// ── PATCH /api/v1/subscriptions/:id ──────────────────────────────────────────
/**
 * Updates a subscription's settings. To pause a subscription,
 * PATCH { status: "paused" }.
 * Response 200: { success, message, data: { subscription } }
 */
async function update(req, res) {
  const subscription = await subscriptionsService.updateSubscription(
    req.user.id,
    req.params.id,
    req.body
  );

  return res.status(200).json({
    success: true,
    message: "Subscription updated successfully",
    data:    { subscription },
  });
}

// ── DELETE /api/v1/subscriptions/:id ─────────────────────────────────────────
/**
 * Permanently deletes a subscription.
 * Historical auto-created transactions are retained.
 * Response 200: { success, message }
 */
async function remove(req, res) {
  await subscriptionsService.deleteSubscription(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    message: "Subscription deleted. Past transactions have been retained.",
  });
}

// ── POST /api/v1/subscriptions/:id/bill-now ───────────────────────────────────
/**
 * Manually triggers billing for a subscription immediately.
 * Useful for: testing, catching up a missed payment, or billing on demand.
 * Uses today's date as the billing date and advances next_billing_date.
 * Response 200: { success, message, data: { transaction, next_billing_date } }
 */
async function billNow(req, res) {
  const todayDate = new Date().toISOString().slice(0, 10);

  // Verify ownership before billing
  const subscription = await subscriptionsService.getSubscriptionById(
    req.user.id,
    req.params.id
  );

  const result = await db.transaction(async (trx) => {
    return subscriptionsService.billSubscription(trx, subscription, todayDate);
  });

  logger.info(
    `[subscriptions] Manual bill-now triggered for subscription ` +
    `${req.params.id} by user ${req.user.id}`
  );

  return res.status(200).json({
    success: true,
    message: `Billed ${subscription.name} successfully. Next billing: ${result.nextBillingDate}`,
    data: {
      transaction:       result.transaction,
      next_billing_date: result.nextBillingDate,
    },
  });
}

module.exports = { create, list, getById, update, remove, billNow };
