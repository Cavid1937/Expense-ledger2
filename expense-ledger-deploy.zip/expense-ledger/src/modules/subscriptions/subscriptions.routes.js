// src/modules/subscriptions/subscriptions.routes.js
// =============================================================================
// Subscriptions module route definitions.
// All routes require a valid JWT.
// =============================================================================

const { Router }            = require("express");
const subscriptionsCtrl     = require("./subscriptions.controller");
const { validate }          = require("../../middleware/validate");
const { authenticate }      = require("../../middleware/auth");
const {
  createSubscriptionSchema,
  updateSubscriptionSchema,
} = require("./subscriptions.schema");

const router = Router();

router.use(authenticate);

/**
 * POST /api/v1/subscriptions
 * Body: { name, account_id, amount_cents, frequency, start_date, ... }
 */
router.post(
  "/",
  validate(createSubscriptionSchema),
  subscriptionsCtrl.create
);

/**
 * GET /api/v1/subscriptions
 * Query: status=active|paused (optional)
 */
router.get("/", subscriptionsCtrl.list);

/**
 * GET /api/v1/subscriptions/:id
 */
router.get("/:id", subscriptionsCtrl.getById);

/**
 * PATCH /api/v1/subscriptions/:id
 * Body: any subset of subscription fields
 * Send { status: "paused" } to pause, { status: "active" } to resume.
 */
router.patch(
  "/:id",
  validate(updateSubscriptionSchema),
  subscriptionsCtrl.update
);

/**
 * DELETE /api/v1/subscriptions/:id
 */
router.delete("/:id", subscriptionsCtrl.remove);

/**
 * POST /api/v1/subscriptions/:id/bill-now
 * Manually triggers an immediate billing cycle for a subscription.
 */
router.post("/:id/bill-now", subscriptionsCtrl.billNow);

module.exports = router;
