// src/modules/subscriptions/subscriptions.schema.js
// =============================================================================
// Zod validation schemas for the Subscriptions module.
//
// Key design decisions:
//   - amount_cents is always a positive integer (same convention as transactions)
//   - next_billing_date is a YYYY-MM-DD string — the cron job advances this
//     forward after each successful billing cycle
//   - status is "active" | "paused" — paused subscriptions are skipped by cron
//   - custom frequency requires custom_interval_days to be set
//   - end_date is optional (NULL = indefinite subscription)
// =============================================================================

const { z } = require("zod");

const FREQUENCIES = ["daily", "weekly", "biweekly", "monthly", "quarterly", "yearly", "custom"];

// ── Create Subscription ───────────────────────────────────────────────────────
const createSubscriptionSchema = z
  .object({
    name: z
      .string({ required_error: "Subscription name is required" })
      .trim()
      .min(1,   "Name cannot be empty")
      .max(150, "Name must be under 150 characters"),

    account_id: z
      .string({ required_error: "account_id is required" })
      .uuid("account_id must be a valid UUID"),

    category_id: z
      .string()
      .uuid("category_id must be a valid UUID")
      .optional()
      .nullable(),

    // Always stored as a positive integer in cents
    amount_cents: z
      .number({ required_error: "amount_cents is required" })
      .int("amount_cents must be an integer")
      .positive("amount_cents must be greater than zero"),

    frequency: z
      .enum(FREQUENCIES, {
        required_error:     "frequency is required",
        invalid_type_error: `frequency must be one of: ${FREQUENCIES.join(", ")}`,
      }),

    // Required only when frequency = "custom"
    custom_interval_days: z
      .number()
      .int()
      .positive("custom_interval_days must be a positive integer")
      .optional()
      .nullable(),

    // The first date this subscription should be billed — also becomes
    // next_billing_date on creation
    start_date: z
      .string({ required_error: "start_date is required" })
      .regex(/^\d{4}-\d{2}-\d{2}$/, "start_date must be in YYYY-MM-DD format"),

    end_date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "end_date must be in YYYY-MM-DD format")
      .optional()
      .nullable(),

    note: z
      .string()
      .trim()
      .max(500, "Note must be under 500 characters")
      .optional()
      .nullable(),

    logo_url: z
      .string()
      .url("logo_url must be a valid URL")
      .max(500)
      .optional()
      .nullable(),

    // Whether the cron job should auto-create a transaction on billing date
    auto_create_transaction: z.boolean().default(true),

    status: z
      .enum(["active", "paused"])
      .default("active"),
  })
  // Cross-field: custom frequency requires custom_interval_days
  .superRefine((data, ctx) => {
    if (data.frequency === "custom" && !data.custom_interval_days) {
      ctx.addIssue({
        code:    "custom",
        path:    ["custom_interval_days"],
        message: "custom_interval_days is required when frequency is 'custom'",
      });
    }

    if (data.end_date && data.start_date) {
      if (new Date(data.end_date) < new Date(data.start_date)) {
        ctx.addIssue({
          code:    "custom",
          path:    ["end_date"],
          message: "end_date must be after start_date",
        });
      }
    }
  });

// ── Update Subscription ────────────────────────────────────────────────────────
const updateSubscriptionSchema = z
  .object({
    name:                    z.string().trim().min(1).max(150).optional(),
    account_id:              z.string().uuid().optional(),
    category_id:             z.string().uuid().optional().nullable(),
    amount_cents:            z.number().int().positive().optional(),
    frequency:               z.enum(FREQUENCIES).optional(),
    custom_interval_days:    z.number().int().positive().optional().nullable(),
    start_date:              z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    end_date:                z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().nullable(),
    next_billing_date:       z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    note:                    z.string().trim().max(500).optional().nullable(),
    logo_url:                z.string().url().max(500).optional().nullable(),
    auto_create_transaction: z.boolean().optional(),
    status:                  z.enum(["active", "paused"]).optional(),
  });

module.exports = { createSubscriptionSchema, updateSubscriptionSchema };
