// src/modules/transactions/transactions.service.js
// =============================================================================
// Transactions business logic layer.
//
// Critical design rules enforced here:
//
//  1. ACID compliance via Knex transactions (knex.transaction()):
//     Any operation that touches BOTH the transactions table AND an account
//     balance runs inside a single DB transaction. If either INSERT/UPDATE
//     fails, the entire operation rolls back — preventing phantom money or
//     balance corruption.
//
//  2. amount_cents is ALWAYS stored as a positive integer.
//     The "type" column (expense/income/transfer) determines the math:
//       - expense  → subtract from account balance
//       - income   → add to account balance
//       - transfer → subtract from source, add to destination
//
//  3. Ownership checks are enforced on every read/write to guarantee a user
//     can never touch another user's data, even if they guess a valid UUID.
//
//  4. Updates and deletes reverse the original balance effect before applying
//     the new one, keeping account balances perfectly accurate.
// =============================================================================

const { db }        = require("../../config/database");
const { AppError }  = require("../../middleware/errorHandler");
const logger        = require("../../utils/logger");

// ── Private helpers ───────────────────────────────────────────────────────────

/**
 * Verifies an account exists, belongs to the given user, and is not deleted.
 * Throws 404 if not found. Returns the account row.
 *
 * @param {object} trx      - Knex transaction object (or db for non-transactional reads)
 * @param {string} accountId
 * @param {string} userId
 * @param {string} label    - Human label for error messages ("account", "destination account")
 */
async function getOwnedAccount(trx, accountId, userId, label = "account") {
  const account = await trx("accounts")
    .where({ id: accountId, user_id: userId })
    .whereNull("deleted_at")
    .select("id", "balance_cents", "currency_code", "name")
    .first();

  if (!account) {
    throw new AppError(`${label} not found or access denied.`, 404);
  }
  return account;
}

/**
 * Applies a balance delta (positive or negative) to an account within a
 * Knex transaction. Uses a raw increment to avoid race conditions — this is
 * equivalent to: UPDATE accounts SET balance_cents = balance_cents + delta
 *
 * @param {object} trx      - Active Knex transaction
 * @param {string} accountId
 * @param {number} delta    - Positive to add, negative to subtract (in cents)
 */
async function applyBalanceDelta(trx, accountId, delta) {
  await trx("accounts")
    .where({ id: accountId })
    .increment("balance_cents", delta);
}

/**
 * Computes the balance delta to apply for a given transaction type.
 * Returns an object describing which accounts to credit/debit.
 *
 * @param {string} type          - "expense" | "income" | "transfer"
 * @param {number} amountCents   - Always positive
 * @param {string} accountId     - Source account
 * @param {string|null} transferAccountId - Destination (transfers only)
 * @returns {{ source: { id, delta }, destination: { id, delta } | null }}
 */
function computeBalanceDeltas(type, amountCents, accountId, transferAccountId) {
  switch (type) {
    case "expense":
      return { source: { id: accountId, delta: -amountCents }, destination: null };
    case "income":
      return { source: { id: accountId, delta: +amountCents }, destination: null };
    case "transfer":
      return {
        source:      { id: accountId,         delta: -amountCents },
        destination: { id: transferAccountId, delta: +amountCents },
      };
    default:
      throw new AppError(`Unknown transaction type: ${type}`, 400);
  }
}

// ── Public service methods ────────────────────────────────────────────────────

/**
 * Creates a new transaction and updates account balance(s).
 * Runs entirely inside a Knex DB transaction for ACID compliance.
 *
 * @param {string} userId - Authenticated user's UUID
 * @param {object} data   - Validated body from createTransactionSchema
 * @returns {object}      - The created transaction row
 */
async function createTransaction(userId, data) {
  const {
    account_id, category_id, transfer_account_id,
    amount_cents, type, date, note, receipt_image_url, subscription_id,
  } = data;

  // Wrap everything in a Knex transaction so inserts + balance updates
  // are atomic. If ANYTHING throws, Postgres rolls back all changes.
  const newTransaction = await db.transaction(async (trx) => {
    // ── 1. Validate account ownership ─────────────────────────────────────────
    await getOwnedAccount(trx, account_id, userId, "account");

    if (type === "transfer") {
      await getOwnedAccount(trx, transfer_account_id, userId, "destination account");
    }

    // ── 2. Compute which accounts to debit/credit ──────────────────────────────
    const deltas = computeBalanceDeltas(type, amount_cents, account_id, transfer_account_id);

    // ── 3. Insert the transaction row ──────────────────────────────────────────
    const [transaction] = await trx("transactions")
      .insert({
        user_id:             userId,
        account_id,
        category_id:         category_id         || null,
        transfer_account_id: transfer_account_id || null,
        amount_cents,
        type,
        date,
        note:                note                || null,
        receipt_image_url:   receipt_image_url   || null,
        subscription_id:     subscription_id     || null,
      })
      .returning("*");

    // ── 4. Apply balance deltas ────────────────────────────────────────────────
    await applyBalanceDelta(trx, deltas.source.id, deltas.source.delta);

    if (deltas.destination) {
      await applyBalanceDelta(trx, deltas.destination.id, deltas.destination.delta);
    }

    logger.info(
      `[transactions] Created ${type} of ${amount_cents} cents ` +
      `for user ${userId} (txn: ${transaction.id})`
    );

    return transaction;
  });

  return newTransaction;
}

/**
 * Returns a paginated, filtered list of transactions for the authenticated user.
 * Uses query params for filtering by account, category, type, date range, and
 * a keyword search on the note field.
 *
 * @param {string} userId
 * @param {object} filters - Validated query params from listTransactionsSchema
 * @returns {{ data: object[], pagination: object }}
 */
async function listTransactions(userId, filters) {
  const {
    page, limit,
    account_id, category_id, type,
    date_from, date_to, search,
    sort_by, sort_order,
  } = filters;

  const offset = (page - 1) * limit;

  // Build the base query — always scoped to the authenticated user
  const baseQuery = db("transactions as t")
    .where("t.user_id", userId)
    .whereNull("t.deleted_at");

  // ── Apply filters ──────────────────────────────────────────────────────────
  if (account_id)  baseQuery.where("t.account_id",  account_id);
  if (category_id) baseQuery.where("t.category_id", category_id);
  if (type)        baseQuery.where("t.type",         type);
  if (date_from)   baseQuery.where("t.date", ">=",   date_from);
  if (date_to)     baseQuery.where("t.date", "<=",   date_to);
  if (search) {
    // Case-insensitive partial match on the note field
    baseQuery.whereILike("t.note", `%${search}%`);
  }

  // ── Run count and data queries in parallel for performance ─────────────────
  const [{ count }, rows] = await Promise.all([
    baseQuery.clone().count("t.id as count").first(),
    baseQuery
      .clone()
      .select(
        "t.id", "t.account_id", "t.category_id", "t.transfer_account_id",
        "t.amount_cents", "t.type", "t.date", "t.note",
        "t.receipt_image_url", "t.created_at",
        // Join category name + icon for display (saves a round-trip in the UI)
        "c.name   as category_name",
        "c.icon   as category_icon",
        "c.color  as category_color",
        // Source account name
        "a.name   as account_name",
      )
      .leftJoin("categories as c", "t.category_id",  "c.id")
      .leftJoin("accounts   as a", "t.account_id",   "a.id")
      .orderBy(`t.${sort_by}`, sort_order)
      .limit(limit)
      .offset(offset),
  ]);

  const totalCount = parseInt(count, 10);

  return {
    data: rows,
    pagination: {
      page,
      limit,
      total:       totalCount,
      total_pages: Math.ceil(totalCount / limit),
      has_more:    page * limit < totalCount,
    },
  };
}

/**
 * Returns a single transaction by ID, scoped to the authenticated user.
 *
 * @param {string} userId
 * @param {string} transactionId
 * @returns {object} Transaction row with joined category and account data
 */
async function getTransactionById(userId, transactionId) {
  const transaction = await db("transactions as t")
    .where({ "t.id": transactionId, "t.user_id": userId })
    .whereNull("t.deleted_at")
    .select(
      "t.*",
      "c.name   as category_name",
      "c.icon   as category_icon",
      "c.color  as category_color",
      "a.name   as account_name",
    )
    .leftJoin("categories as c", "t.category_id", "c.id")
    .leftJoin("accounts   as a", "t.account_id",  "a.id")
    .first();

  if (!transaction) {
    throw new AppError("Transaction not found.", 404);
  }

  return transaction;
}

/**
 * Updates a transaction and reconciles account balances.
 *
 * This is the most complex operation:
 *  1. Fetch the original transaction (need its values to reverse its effect).
 *  2. Reverse the original balance delta (undo the old transaction).
 *  3. Apply the new balance delta (apply the updated transaction).
 *  4. Update the transaction row.
 *
 * All four steps run inside a single Knex transaction.
 *
 * @param {string} userId
 * @param {string} transactionId
 * @param {object} updates - Validated partial body from updateTransactionSchema
 * @returns {object} Updated transaction row
 */
async function updateTransaction(userId, transactionId, updates) {
  const updatedTransaction = await db.transaction(async (trx) => {
    // ── 1. Fetch and lock the original transaction ─────────────────────────────
    // "FOR UPDATE" locks the row until the transaction commits, preventing
    // concurrent updates from creating race conditions on the balance.
    const original = await trx("transactions")
      .where({ id: transactionId, user_id: userId })
      .whereNull("deleted_at")
      .forUpdate()
      .first();

    if (!original) {
      throw new AppError("Transaction not found.", 404);
    }

    // Merge original values with incoming updates
    const merged = {
      account_id:          updates.account_id          ?? original.account_id,
      transfer_account_id: updates.transfer_account_id ?? original.transfer_account_id,
      amount_cents:        updates.amount_cents         ?? original.amount_cents,
      type:                updates.type                 ?? original.type,
      category_id:         updates.hasOwnProperty("category_id") ? updates.category_id : original.category_id,
      date:                updates.date                 ?? original.date,
      note:                updates.hasOwnProperty("note") ? updates.note : original.note,
      receipt_image_url:   updates.hasOwnProperty("receipt_image_url") ? updates.receipt_image_url : original.receipt_image_url,
    };

    // ── 2. Reverse the ORIGINAL transaction's balance effect ───────────────────
    const originalDeltas = computeBalanceDeltas(
      original.type,
      original.amount_cents,
      original.account_id,
      original.transfer_account_id
    );
    // Negate each delta to undo the original effect
    await applyBalanceDelta(trx, originalDeltas.source.id, -originalDeltas.source.delta);
    if (originalDeltas.destination) {
      await applyBalanceDelta(trx, originalDeltas.destination.id, -originalDeltas.destination.delta);
    }

    // ── 3. Validate ownership of any NEW accounts referenced ──────────────────
    if (merged.account_id !== original.account_id) {
      await getOwnedAccount(trx, merged.account_id, userId, "account");
    }
    if (merged.type === "transfer" && merged.transfer_account_id !== original.transfer_account_id) {
      await getOwnedAccount(trx, merged.transfer_account_id, userId, "destination account");
    }

    // ── 4. Apply NEW balance deltas ────────────────────────────────────────────
    const newDeltas = computeBalanceDeltas(
      merged.type,
      merged.amount_cents,
      merged.account_id,
      merged.transfer_account_id
    );
    await applyBalanceDelta(trx, newDeltas.source.id, newDeltas.source.delta);
    if (newDeltas.destination) {
      await applyBalanceDelta(trx, newDeltas.destination.id, newDeltas.destination.delta);
    }

    // ── 5. Update the transaction row ──────────────────────────────────────────
    const [updated] = await trx("transactions")
      .where({ id: transactionId })
      .update({
        account_id:          merged.account_id,
        transfer_account_id: merged.transfer_account_id,
        amount_cents:        merged.amount_cents,
        type:                merged.type,
        category_id:         merged.category_id,
        date:                merged.date,
        note:                merged.note,
        receipt_image_url:   merged.receipt_image_url,
        updated_at:          new Date(),
      })
      .returning("*");

    logger.info(`[transactions] Updated transaction ${transactionId} for user ${userId}`);
    return updated;
  });

  return updatedTransaction;
}

/**
 * Soft-deletes a transaction and reverses its balance effect.
 *
 * We soft-delete (set deleted_at) rather than hard-delete so that
 * historical reports and audit trails remain intact.
 *
 * @param {string} userId
 * @param {string} transactionId
 */
async function deleteTransaction(userId, transactionId) {
  await db.transaction(async (trx) => {
    // Fetch and lock the transaction
    const transaction = await trx("transactions")
      .where({ id: transactionId, user_id: userId })
      .whereNull("deleted_at")
      .forUpdate()
      .first();

    if (!transaction) {
      throw new AppError("Transaction not found.", 404);
    }

    // Reverse the balance effect before soft-deleting
    const deltas = computeBalanceDeltas(
      transaction.type,
      transaction.amount_cents,
      transaction.account_id,
      transaction.transfer_account_id
    );
    await applyBalanceDelta(trx, deltas.source.id, -deltas.source.delta);
    if (deltas.destination) {
      await applyBalanceDelta(trx, deltas.destination.id, -deltas.destination.delta);
    }

    // Soft-delete the transaction row
    await trx("transactions")
      .where({ id: transactionId })
      .update({ deleted_at: new Date() });

    logger.info(`[transactions] Soft-deleted transaction ${transactionId} for user ${userId}`);
  });
}

/**
 * Returns aggregated monthly spending grouped by category.
 * Used by the dashboard and budget progress calculations.
 *
 * @param {string} userId
 * @param {string} month - "YYYY-MM" e.g. "2025-01"
 * @returns {object[]} Array of { category_id, category_name, total_cents }
 */
async function getMonthlySummary(userId, month) {
  // Build date range from the month string
  const dateFrom = `${month}-01`;
  // Last day of month: first day of next month minus 1 day via Postgres
  const rows = await db("transactions as t")
    .where("t.user_id",  userId)
    .where("t.type",     "expense")   // Only expenses count against budgets
    .whereNull("t.deleted_at")
    .whereRaw("TO_CHAR(t.date, 'YYYY-MM') = ?", [month])
    .select(
      "t.category_id",
      "c.name  as category_name",
      "c.icon  as category_icon",
      "c.color as category_color",
      db.raw("SUM(t.amount_cents) as total_cents"),
      db.raw("COUNT(t.id)         as transaction_count"),
    )
    .leftJoin("categories as c", "t.category_id", "c.id")
    .groupBy("t.category_id", "c.name", "c.icon", "c.color")
    .orderBy("total_cents", "desc");

  // Cast aggregated values to numbers (pg returns them as strings)
  return rows.map((r) => ({
    ...r,
    total_cents:       parseInt(r.total_cents, 10),
    transaction_count: parseInt(r.transaction_count, 10),
  }));
}

module.exports = {
  createTransaction,
  listTransactions,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
  getMonthlySummary,
};
