// src/modules/transactions/transactions.routes.js
// =============================================================================
// Transactions module route definitions.
//
// All routes are protected by the authenticate middleware — a valid JWT is
// required for every endpoint. The user can only ever access their own data
// because the service layer scopes every query to req.user.id.
//
// Route ordering matters: the specific "/summary/monthly" route is registered
// BEFORE "/:id" to prevent Express from interpreting "summary" as a UUID.
// =============================================================================

const { Router }       = require("express");
const transactionsCtrl = require("./transactions.controller");
const { validate }     = require("../../middleware/validate");
const { authenticate } = require("../../middleware/auth");
const {
  createTransactionSchema,
  updateTransactionSchema,
  listTransactionsSchema,
} = require("./transactions.schema");

const router = Router();

// Every transactions route requires a valid JWT
router.use(authenticate);

// ── Aggregate / special routes (must come before /:id) ───────────────────────

/**
 * GET /api/v1/transactions/summary/monthly?month=YYYY-MM
 * Returns spending grouped by category for the given month.
 */
router.get("/summary/monthly", transactionsCtrl.monthlySummary);

// ── Collection routes ─────────────────────────────────────────────────────────

/**
 * POST /api/v1/transactions
 * Body: { account_id, amount_cents, type, date, category_id?, note?, ... }
 */
router.post(
  "/",
  validate(createTransactionSchema),
  transactionsCtrl.create
);

/**
 * GET /api/v1/transactions
 * Query: page, limit, account_id, category_id, type, date_from, date_to,
 *        search, sort_by, sort_order
 */
router.get(
  "/",
  // Validate query params using the same validate() middleware,
  // but target req.query instead of req.body
  (req, res, next) => {
    const result = listTransactionsSchema.safeParse(req.query);
    if (!result.success) return next(result.error);
    req.query = result.data; // Replace with coerced/defaulted values
    next();
  },
  transactionsCtrl.list
);

// ── Resource routes ───────────────────────────────────────────────────────────

/**
 * GET /api/v1/transactions/:id
 */
router.get("/:id", transactionsCtrl.getById);

/**
 * PATCH /api/v1/transactions/:id
 * Body: any subset of transaction fields (all optional)
 */
router.patch(
  "/:id",
  validate(updateTransactionSchema),
  transactionsCtrl.update
);

/**
 * DELETE /api/v1/transactions/:id
 * Soft-deletes the transaction and reverses its balance effect.
 */
router.delete("/:id", transactionsCtrl.remove);

module.exports = router;
