// src/modules/transactions/transactions.controller.js
// =============================================================================
// Transactions HTTP controller. One function per endpoint.
//
// Pattern followed throughout:
//   1. Extract validated data from req.body / req.params / req.query
//   2. Call the service with userId = req.user.id (enforced by authenticate)
//   3. Return a standardised JSON response
//
// No business logic, no DB queries live here.
// All async errors are forwarded to the global errorHandler automatically
// via the "express-async-errors" package registered in app.js.
// =============================================================================

const transactionsService = require("./transactions.service");

// ── POST /api/v1/transactions ─────────────────────────────────────────────────
/**
 * Creates a new transaction (expense, income, or transfer).
 * Response 201: { success, message, data: { transaction } }
 */
async function create(req, res) {
  const transaction = await transactionsService.createTransaction(
    req.user.id,
    req.body
  );

  return res.status(201).json({
    success: true,
    message: "Transaction created successfully",
    data:    { transaction },
  });
}

// ── GET /api/v1/transactions ──────────────────────────────────────────────────
/**
 * Lists all transactions for the authenticated user, with pagination + filters.
 * Query params are validated by the validate(listTransactionsSchema) middleware.
 * Response 200: { success, data: { transactions, pagination } }
 */
async function list(req, res) {
  const result = await transactionsService.listTransactions(
    req.user.id,
    req.query   // Already validated and coerced by the validate() middleware
  );

  return res.status(200).json({
    success: true,
    data: {
      transactions: result.data,
      pagination:   result.pagination,
    },
  });
}

// ── GET /api/v1/transactions/:id ──────────────────────────────────────────────
/**
 * Returns a single transaction by its UUID.
 * Response 200: { success, data: { transaction } }
 */
async function getById(req, res) {
  const transaction = await transactionsService.getTransactionById(
    req.user.id,
    req.params.id
  );

  return res.status(200).json({
    success: true,
    data:    { transaction },
  });
}

// ── PATCH /api/v1/transactions/:id ────────────────────────────────────────────
/**
 * Partially updates a transaction (and reconciles account balances).
 * Response 200: { success, message, data: { transaction } }
 */
async function update(req, res) {
  const transaction = await transactionsService.updateTransaction(
    req.user.id,
    req.params.id,
    req.body
  );

  return res.status(200).json({
    success: true,
    message: "Transaction updated successfully",
    data:    { transaction },
  });
}

// ── DELETE /api/v1/transactions/:id ──────────────────────────────────────────
/**
 * Soft-deletes a transaction and reverses its account balance effect.
 * Response 200: { success, message }
 */
async function remove(req, res) {
  await transactionsService.deleteTransaction(req.user.id, req.params.id);

  return res.status(200).json({
    success: true,
    message: "Transaction deleted successfully",
  });
}

// ── GET /api/v1/transactions/summary/monthly ──────────────────────────────────
/**
 * Returns spending aggregated by category for a given month.
 * Query param: month=YYYY-MM (defaults to current month if not provided)
 * Response 200: { success, data: { month, summary } }
 */
async function monthlySummary(req, res) {
  // Default to the current month if no param provided
  const month = req.query.month || new Date().toISOString().slice(0, 7);

  // Basic format validation
  if (!/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({
      success: false,
      message: "month query param must be in YYYY-MM format (e.g. 2025-01)",
    });
  }

  const summary = await transactionsService.getMonthlySummary(req.user.id, month);

  return res.status(200).json({
    success: true,
    data: { month, summary },
  });
}

module.exports = { create, list, getById, update, remove, monthlySummary };
