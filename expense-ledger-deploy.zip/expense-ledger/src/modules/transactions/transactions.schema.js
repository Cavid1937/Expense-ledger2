// src/modules/transactions/transactions.schema.js
// =============================================================================
// Zod validation schemas for the Transactions module.
//
// Key design decisions:
//   - amount_cents must always be a POSITIVE integer (>0). Business logic in
//     the service layer determines whether it adds or subtracts from a balance.
//   - transfer type requires transfer_account_id and forbids it being the same
//     as account_id (you can't transfer to yourself).
//   - Dates are accepted as ISO 8601 strings and coerced to JS Date objects.
//   - Filters schema covers the GET /transactions list endpoint with pagination,
//     date range filtering, category and type filtering.
// =============================================================================

const { z } = require("zod");

// ── Shared field definitions ──────────────────────────────────────────────────
const uuidField   = (label) => z.string({ required_error: `${label} is required` }).uuid(`${label} must be a valid UUID`);
const centsField  = (label) => z.number({ required_error: `${label} is required` }).int(`${label} must be an integer (no decimals)`).positive(`${label} must be greater than zero`);

// ── Create Transaction ────────────────────────────────────────────────────────
const createTransactionSchema = z
  .object({
    account_id: uuidField("account_id"),

    // category_id is optional — users may log uncategorised expenses
    category_id: z.string().uuid("category_id must be a valid UUID").optional().nullable(),

    // For transfers only — the destination account
    transfer_account_id: z.string().uuid("transfer_account_id must be a valid UUID").optional().nullable(),

    // Stored in DB as a positive integer (cents). e.g. $12.50 → 1250
    amount_cents: centsField("amount_cents"),

    type: z.enum(["expense", "income", "transfer"], {
      required_error: "type is required",
      invalid_type_error: "type must be one of: expense, income, transfer",
    }),

    // User-selected date for the transaction (not necessarily today)
    date: z
      .string({ required_error: "date is required" })
      .regex(/^\d{4}-\d{2}-\d{2}$/, "date must be in YYYY-MM-DD format"),

    note: z.string().trim().max(500, "Note must be under 500 characters").optional().nullable(),

    receipt_image_url: z
      .string()
      .url("receipt_image_url must be a valid URL")
      .max(1000)
      .optional()
      .nullable(),

    // If provided, links this transaction to a subscription template
    subscription_id: z.string().uuid().optional().nullable(),
  })
  // ── Cross-field validation ─────────────────────────────────────────────────
  .superRefine((data, ctx) => {
    // Rule 1: Transfer requires a destination account
    if (data.type === "transfer" && !data.transfer_account_id) {
      ctx.addIssue({
        code:    z.ZodIssueCode.custom,
        path:    ["transfer_account_id"],
        message: "transfer_account_id is required for transfer transactions",
      });
    }

    // Rule 2: Can't transfer money to the same account
    if (
      data.type === "transfer" &&
      data.transfer_account_id &&
      data.transfer_account_id === data.account_id
    ) {
      ctx.addIssue({
        code:    z.ZodIssueCode.custom,
        path:    ["transfer_account_id"],
        message: "transfer_account_id must be different from account_id",
      });
    }

    // Rule 3: Non-transfer transactions should not have transfer_account_id
    if (data.type !== "transfer" && data.transfer_account_id) {
      ctx.addIssue({
        code:    z.ZodIssueCode.custom,
        path:    ["transfer_account_id"],
        message: "transfer_account_id is only valid for transfer transactions",
      });
    }
  });

// ── Update Transaction ────────────────────────────────────────────────────────
// All fields optional — only provided fields are updated (PATCH semantics).
// We use partial() then add the same cross-field refinement rules.
const updateTransactionSchema = z
  .object({
    account_id:          z.string().uuid().optional(),
    category_id:         z.string().uuid().optional().nullable(),
    transfer_account_id: z.string().uuid().optional().nullable(),
    amount_cents:        z.number().int().positive().optional(),
    type:                z.enum(["expense", "income", "transfer"]).optional(),
    date:                z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    note:                z.string().trim().max(500).optional().nullable(),
    receipt_image_url:   z.string().url().max(1000).optional().nullable(),
  })
  .superRefine((data, ctx) => {
    if (
      data.type === "transfer" &&
      data.transfer_account_id &&
      data.transfer_account_id === data.account_id
    ) {
      ctx.addIssue({
        code:    z.ZodIssueCode.custom,
        path:    ["transfer_account_id"],
        message: "transfer_account_id must be different from account_id",
      });
    }
  });

// ── List / Filter Transactions ────────────────────────────────────────────────
// Used to validate query params on GET /transactions
const listTransactionsSchema = z.object({
  // Pagination
  page:  z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),

  // Filters
  account_id:  z.string().uuid().optional(),
  category_id: z.string().uuid().optional(),
  type:        z.enum(["expense", "income", "transfer"]).optional(),

  // Date range (YYYY-MM-DD)
  date_from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  date_to:   z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),

  // Full-text search on note field
  search: z.string().trim().max(100).optional(),

  // Sorting
  sort_by:    z.enum(["date", "amount_cents", "created_at"]).default("date"),
  sort_order: z.enum(["asc", "desc"]).default("desc"),
}).refine(
  (data) => {
    if (data.date_from && data.date_to) {
      return new Date(data.date_from) <= new Date(data.date_to);
    }
    return true;
  },
  { message: "date_from must be before or equal to date_to", path: ["date_from"] }
);

// ── UUID param schema (for :id route params) ───────────────────────────────────
const idParamSchema = z.object({
  id: z.string().uuid("Transaction ID must be a valid UUID"),
});

module.exports = {
  createTransactionSchema,
  updateTransactionSchema,
  listTransactionsSchema,
  idParamSchema,
};
