// src/middleware/auth.js
// =============================================================================
// JWT authentication middleware. Verifies the Bearer token on protected routes.
//
// On success:  attaches the decoded payload to req.user and calls next().
// On failure:  throws a 401 AppError which flows to the global errorHandler.
//
// Usage:
//   const { authenticate } = require("../../middleware/auth");
//   router.get("/me", authenticate, usersController.getMe);
// =============================================================================

const jwt             = require("jsonwebtoken");
const { AppError }    = require("./errorHandler");
const { db }          = require("../config/database");

/**
 * Extracts the JWT from the Authorization header ("Bearer <token>"),
 * verifies its signature and expiry, then fetches the matching user
 * from the DB to ensure the account still exists and isn't deleted.
 *
 * We re-query the DB on every request (not just trusting the JWT) so
 * that deactivated or deleted accounts are rejected immediately, without
 * waiting for the token to expire.
 */
async function authenticate(req, res, next) {
  try {
    // ── 1. Extract token ───────────────────────────────────────────────────────
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new AppError("Authentication required. Please log in.", 401);
    }

    const token = authHeader.split(" ")[1]; // "Bearer <token>" → "<token>"

    // ── 2. Verify signature + expiry ───────────────────────────────────────────
    // jwt.verify() throws JsonWebTokenError or TokenExpiredError on failure.
    // Both are handled by the global errorHandler.
    const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);

    // ── 3. Confirm user still exists and is not soft-deleted ──────────────────
    const user = await db("users")
      .where({ id: decoded.sub })   // "sub" (subject) = user UUID in our JWTs
      .whereNull("deleted_at")       // Exclude soft-deleted accounts
      .select("id", "email", "full_name", "currency_code", "currency_symbol", "timezone")
      .first();

    if (!user) {
      throw new AppError("User no longer exists.", 401);
    }

    // ── 4. Attach user to request ─────────────────────────────────────────────
    // All downstream controllers can access req.user without another DB hit.
    req.user = user;

    next();
  } catch (error) {
    next(error);
  }
}

module.exports = { authenticate };
