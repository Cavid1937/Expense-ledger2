// src/middleware/errorHandler.js
// =============================================================================
// Global Express error-handling middleware. Must be registered LAST in app.js
// (after all routes) because Express identifies error handlers by their
// 4-argument signature: (err, req, res, next).
//
// All errors thrown anywhere in the app — including async route handlers
// wrapped by "express-async-errors" — will eventually land here.
// =============================================================================

const logger = require("../utils/logger");

// ── Custom Application Error class ────────────────────────────────────────────
// Throwing an AppError lets us attach a specific HTTP status code and a
// client-safe message, keeping internal details out of API responses.
class AppError extends Error {
  /**
   * @param {string}  message    - Human-readable message sent to the client.
   * @param {number}  statusCode - HTTP status code (400, 401, 403, 404, 409…)
   * @param {boolean} isOperational - True = known/expected error (wrong password,
   *                                  duplicate email). False = unexpected bug.
   */
  constructor(message, statusCode = 500, isOperational = true) {
    super(message);
    this.statusCode    = statusCode;
    this.isOperational = isOperational;
    this.name          = this.constructor.name;

    // Capture stack trace, excluding the constructor call itself
    Error.captureStackTrace(this, this.constructor);
  }
}

// ── Error handler middleware ───────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Default to 500 if no statusCode is set on the error
  const statusCode = err.statusCode || 500;
  const isProduction = process.env.NODE_ENV === "production";

  // Always log the full error server-side (with stack in dev)
  if (statusCode >= 500) {
    logger.error(`[${req.method}] ${req.path} → ${statusCode}: ${err.message}`, {
      stack: err.stack,
    });
  } else {
    logger.warn(`[${req.method}] ${req.path} → ${statusCode}: ${err.message}`);
  }

  // ── Zod validation errors ────────────────────────────────────────────────────
  // Zod throws a ZodError when schema parsing fails. We reshape it into a
  // clean array of field-level messages for the client.
  if (err.name === "ZodError") {
    return res.status(422).json({
      success: false,
      message: "Validation failed",
      errors:  err.errors.map((e) => ({
        field:   e.path.join("."),
        message: e.message,
      })),
    });
  }

  // ── JWT errors ───────────────────────────────────────────────────────────────
  if (err.name === "JsonWebTokenError") {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }
  if (err.name === "TokenExpiredError") {
    return res.status(401).json({ success: false, message: "Token expired" });
  }

  // ── Knex / PostgreSQL errors ─────────────────────────────────────────────────
  // pg error codes: https://www.postgresql.org/docs/current/errcodes-appendix.html
  if (err.code === "23505") {
    // Unique constraint violation — e.g. duplicate email
    return res.status(409).json({
      success: false,
      message: "A record with that value already exists",
    });
  }
  if (err.code === "23503") {
    // Foreign key violation
    return res.status(400).json({
      success: false,
      message: "Referenced record does not exist",
    });
  }

  // ── Operational (known) AppErrors ────────────────────────────────────────────
  if (err.isOperational) {
    return res.status(statusCode).json({
      success: false,
      message: err.message,
    });
  }

  // ── Unknown / unexpected errors ───────────────────────────────────────────────
  // Never leak internal details in production
  return res.status(500).json({
    success: false,
    message: isProduction ? "An unexpected error occurred" : err.message,
    ...(isProduction ? {} : { stack: err.stack }),
  });
}

module.exports = { AppError, errorHandler };
