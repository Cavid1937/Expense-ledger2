// src/config/env.ts
// =============================================================================
// Environment variable management for Expense Ledger.
//
// ─── How Expo environment variables work ─────────────────────────────────────
//
//   Variables prefixed with EXPO_PUBLIC_ are inlined into the JavaScript
//   bundle at build time by Metro bundler. They are readable from any
//   component or utility via process.env.EXPO_PUBLIC_*.
//
//   Variables WITHOUT the prefix are only available server-side (e.g. in
//   metro.config.js or eas.json env blocks) and are NOT accessible in
//   the app bundle. Never put secrets in EXPO_PUBLIC_ variables.
//
// ─── Where to define variables ───────────────────────────────────────────────
//
//   Local development:
//     Create a .env.local file in the project root (never commit this):
//
//       EXPO_PUBLIC_API_URL=http://192.168.1.42:4000/api/v1
//       EXPO_PUBLIC_APP_ENV=development
//
//     Use your local machine's LAN IP (not localhost) — "localhost" on
//     a physical device refers to the device itself, not your dev machine.
//     Find it with: ipconfig (Windows) or ifconfig | grep inet (macOS/Linux)
//
//   EAS Cloud builds (preview + production):
//     Store secrets in EAS using the CLI — never in .env files committed
//     to version control:
//
//       # Add a secret scoped to all builds:
//       eas secret:create --scope project --name EXPO_PUBLIC_API_URL --value https://api.yourapp.com/api/v1
//
//       # List all secrets:
//       eas secret:list
//
//       # Push/profile-specific secrets (e.g. different URLs per environment):
//       eas secret:create --scope project --name EXPO_PUBLIC_API_URL_PRODUCTION --value https://api.yourapp.com/api/v1
//       eas secret:create --scope project --name EXPO_PUBLIC_API_URL_PREVIEW    --value https://staging.yourapp.com/api/v1
//
//     EAS injects these as environment variables during the cloud build.
//     They are NOT visible in the EAS dashboard after creation (write-only).
//
//   Per-environment URLs (alternative pattern):
//     Rather than one EXPO_PUBLIC_API_URL that you change per build, you
//     can define three named variables and resolve them here based on
//     EXPO_PUBLIC_APP_ENV. This approach is used below.
//
// ─── .gitignore ──────────────────────────────────────────────────────────────
//
//   Ensure your .gitignore contains:
//     .env
//     .env.local
//     .env.*.local
//     google-services.json
//     google-play-service-account.json
//     ios/GoogleService-Info.plist
//
// =============================================================================

type AppEnvironment = "development" | "preview" | "production";

// ── Environment detection ─────────────────────────────────────────────────────

const APP_ENV = (process.env.EXPO_PUBLIC_APP_ENV ?? "development") as AppEnvironment;

// ── API URL resolution ────────────────────────────────────────────────────────
//
// Priority order (first defined wins):
//   1. EXPO_PUBLIC_API_URL                 — explicit override for any environment
//   2. EXPO_PUBLIC_API_URL_<ENV>           — per-environment EAS secret
//   3. Hardcoded fallback per environment  — last resort
//
// Replace the fallback URLs with your actual deployed URLs before submitting.

const FALLBACK_URLS: Record<AppEnvironment, string> = {
  development: "http://192.168.1.42:4000/api/v1",  // ← REPLACE with your local IP
  preview:     "https://staging.yourapp.com/api/v1", // ← REPLACE with staging URL
  production:  "https://api.yourapp.com/api/v1",     // ← REPLACE with production URL
};

function resolveApiUrl(): string {
  // 1. Explicit override takes top priority
  if (process.env.EXPO_PUBLIC_API_URL) {
    return process.env.EXPO_PUBLIC_API_URL;
  }

  // 2. Per-environment EAS secret
  const envSpecific = process.env[`EXPO_PUBLIC_API_URL_${APP_ENV.toUpperCase()}`];
  if (envSpecific) return envSpecific;

  // 3. Hardcoded fallback
  return FALLBACK_URLS[APP_ENV];
}

// ── Validated config object ───────────────────────────────────────────────────
//
// Centralising config here means:
//   - One import throughout the app (import { ENV } from "@/src/config/env")
//   - Validation errors surface at startup, not buried in API call failures
//   - Easy to add new env vars without hunting for all usage sites

export const ENV = {
  APP_ENV,
  API_URL:    resolveApiUrl(),
  IS_DEV:     APP_ENV === "development",
  IS_PREVIEW: APP_ENV === "preview",
  IS_PROD:    APP_ENV === "production",
} as const;

// ── Startup validation ────────────────────────────────────────────────────────
// Runs once when this module is first imported (early in app boot).
// Logs a clear warning rather than throwing — a misconfigured URL should
// show a network error in the UI, not a white-screen crash.

if (!ENV.API_URL) {
  console.error(
    "[env] CRITICAL: API_URL is empty. " +
    "Set EXPO_PUBLIC_API_URL in your .env.local file or in EAS Secrets."
  );
} else if (ENV.IS_DEV && ENV.API_URL.includes("localhost")) {
  console.warn(
    "[env] WARNING: API_URL contains 'localhost'. " +
    "On a physical device, use your machine's LAN IP instead " +
    "(e.g. http://192.168.1.42:4000/api/v1). " +
    "Run `ifconfig | grep inet` on macOS to find it."
  );
}

if (ENV.IS_DEV) {
  console.log(`[env] App environment: ${ENV.APP_ENV}`);
  console.log(`[env] API URL: ${ENV.API_URL}`);
}
