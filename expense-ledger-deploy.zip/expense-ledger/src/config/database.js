// src/config/database.js
// =============================================================================
// Exports a single, shared Knex instance for the entire application.
//
// Why a singleton? Knex manages a connection pool internally. If we called
// knex(config) in every file, we'd create a new pool per file — exhausting
// DB connections quickly. One instance = one pool shared across all modules.
// =============================================================================

const knex        = require("knex");
const knexConfigs = require("../../knexfile");
const logger      = require("../utils/logger");

// Determine which environment config to load.
// Defaults to "development" if NODE_ENV is not set.
const env    = process.env.NODE_ENV || "development";
const config = knexConfigs[env];

if (!config) {
  throw new Error(
    `[database] No Knex config found for environment: "${env}". ` +
    `Check knexfile.js and ensure NODE_ENV is set correctly.`
  );
}

// Create the Knex instance (opens the connection pool).
const db = knex(config);

// ── Health check helper ────────────────────────────────────────────────────────
// Called during server startup to verify the DB is actually reachable.
// Throws if the connection fails so the server won't start in a broken state.
async function connectDB() {
  try {
    // "SELECT 1" is the lightest possible query — just proves connectivity.
    await db.raw("SELECT 1");
    logger.info(`[database] PostgreSQL connected (env: ${env})`);
  } catch (error) {
    logger.error("[database] Failed to connect to PostgreSQL:", error.message);
    // Re-throw so server.js can catch it and exit the process.
    throw error;
  }
}

module.exports = { db, connectDB };
