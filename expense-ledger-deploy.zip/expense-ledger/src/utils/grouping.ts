// src/utils/grouping.ts
// =============================================================================
// Groups a flat array of transactions into date sections for list rendering.
//
// Output format:
//   FlashList requires a flat array — it doesn't support nested data.
//   So we interleave "header" items with "transaction" items in a single array:
//
//   [
//     { kind: "header", date: "2026-04-16", label: "Today"          },
//     { kind: "item",   transaction: { id: "...", ... }              },
//     { kind: "item",   transaction: { id: "...", ... }              },
//     { kind: "header", date: "2026-04-15", label: "Yesterday"       },
//     { kind: "item",   transaction: { id: "...", ... }              },
//     { kind: "header", date: "2026-04-12", label: "April 12, 2026"  },
//     ...
//   ]
//
// Date label rules:
//   - Today    → "Today"
//   - Yesterday → "Yesterday"
//   - Within the last 7 days → "Monday", "Tuesday", etc.
//   - Older    → "April 12, 2026"
//
// Assumptions:
//   - Input transactions are already sorted newest-first (the API returns
//     them with sort_by=date&sort_order=desc)
//   - The date field is a YYYY-MM-DD string (no time component)
// =============================================================================

import type { Transaction } from "../api/transactions.api";

// ── Output types ──────────────────────────────────────────────────────────────

export interface DateHeader {
  kind:        "header";
  /** YYYY-MM-DD — used as the unique key for FlashList */
  date:        string;
  /** Human-readable label: "Today", "Yesterday", "Monday", "April 12, 2026" */
  label:       string;
  /** Total absolute spend for the day — shown as a day sub-total */
  totalCents:  number;
}

export interface TransactionItem {
  kind:        "item";
  transaction: Transaction;
}

export type LedgerRow = DateHeader | TransactionItem;

// ── Date label helper ─────────────────────────────────────────────────────────

/**
 * Returns a natural-language label for a given YYYY-MM-DD date string,
 * relative to today (also passed as a string for testability).
 *
 * @param dateStr   - YYYY-MM-DD string from the transaction
 * @param todayStr  - YYYY-MM-DD string for "today" (pass new Date for production)
 */
export function getDateLabel(dateStr: string, todayStr: string): string {
  const date  = new Date(dateStr  + "T00:00:00");
  const today = new Date(todayStr + "T00:00:00");

  const diffMs   = today.getTime() - date.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";

  if (diffDays >= 2 && diffDays <= 6) {
    // Within the current week → weekday name
    return date.toLocaleDateString("en-US", { weekday: "long" });
  }

  // Older → full date
  return date.toLocaleDateString("en-US", {
    month: "long",
    day:   "numeric",
    year:  "numeric",
  });
}

// ── Main grouping function ────────────────────────────────────────────────────

/**
 * Transforms a flat Transaction[] into a LedgerRow[] ready for FlashList.
 *
 * Each date group gets a DateHeader row followed by TransactionItem rows.
 * The header includes a totalCents field for the day's net expense display.
 *
 * @param transactions - Flat array sorted newest-first
 * @returns            - Interleaved headers + items for FlashList
 */
export function groupTransactionsByDate(transactions: Transaction[]): LedgerRow[] {
  if (!transactions.length) return [];

  const today   = new Date().toISOString().slice(0, 10);
  const rows:   LedgerRow[]         = [];
  let   current: string | null      = null;
  let   headerIndex: number         = -1;

  for (const txn of transactions) {
    const dateStr = txn.date.slice(0, 10);  // Ensure YYYY-MM-DD

    if (dateStr !== current) {
      // Start a new date group
      current = dateStr;

      const header: DateHeader = {
        kind:       "header",
        date:       dateStr,
        label:      getDateLabel(dateStr, today),
        totalCents: 0,   // Will be accumulated below
      };

      headerIndex = rows.length;
      rows.push(header);
    }

    // Accumulate day total on the header (expenses subtract, income adds)
    // We cast here because we'll only mutate the header we just pushed
    const header = rows[headerIndex] as DateHeader;
    if (txn.type === "expense") {
      header.totalCents -= txn.amount_cents;
    } else if (txn.type === "income") {
      header.totalCents += txn.amount_cents;
    }
    // Transfers don't affect the daily net

    rows.push({ kind: "item", transaction: txn });
  }

  return rows;
}

// ── Overload for infinite query pages ────────────────────────────────────────

/**
 * Flattens multiple paginated pages into a single Transaction[] before grouping.
 * Designed to work with React Query's useInfiniteQuery data structure.
 *
 * @param pages - Array of page results from useInfiniteQuery
 */
export function groupTransactionPages(
  pages: { transactions: Transaction[] }[]
): LedgerRow[] {
  const flat = pages.flatMap((page) => page.transactions);
  return groupTransactionsByDate(flat);
}
