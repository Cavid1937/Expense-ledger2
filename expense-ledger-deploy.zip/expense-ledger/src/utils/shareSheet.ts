// src/utils/shareSheet.ts
// =============================================================================
// Native file system write + share sheet trigger.
//
// Flow:
//   1. Write the CSV string to a temporary file in the app's cache directory
//      via expo-file-system. We use cacheDirectory (not documentDirectory) so
//      the OS can clean it up — we don't need the file to persist after sharing.
//
//   2. Invoke the native share sheet via expo-sharing (Sharing.shareAsync).
//      On iOS this opens the standard UIActivityViewController which supports:
//        - AirDrop to Mac / iPad / iPhone
//        - Mail attachment
//        - Save to Files app
//        - Open in Numbers / Excel / Google Sheets
//      On Android this opens the system Intent chooser with equivalent options.
//
//   3. Clean up the temp file after a short delay so we don't accumulate
//      stale exports in the cache directory over time.
//
// Error handling:
//   expo-sharing returns without throwing if the user dismisses the sheet,
//   so we don't need to distinguish cancellation from success.
//   We re-throw unexpected errors so the Settings screen can show a toast.
// =============================================================================

import * as FileSystem from "expo-file-system";
import * as Sharing    from "expo-sharing";
import { Platform }    from "react-native";

export interface ShareCsvOptions {
  /** The CSV string to write and share */
  csvContent: string;
  /** Suggested filename shown in the share sheet */
  filename:   string;
}

/**
 * Writes a CSV string to a temporary file and invokes the native share sheet.
 *
 * @throws Error if the device does not support sharing (rare — most do).
 * @throws Error if the file system write fails.
 */
export async function shareCsvFile(options: ShareCsvOptions): Promise<void> {
  const { csvContent, filename } = options;

  // ── 1. Check sharing availability ─────────────────────────────────────────
  // expo-sharing may not be available on emulators without Google Play (Android).
  const isAvailable = await Sharing.isAvailableAsync();
  if (!isAvailable) {
    throw new Error(
      "Sharing is not available on this device. " +
      "Try connecting a real device to export your data."
    );
  }

  // ── 2. Write CSV to cache directory ───────────────────────────────────────
  // FileSystem.cacheDirectory is guaranteed to exist and is writable.
  // We sanitise the filename — strip any path separators for safety.
  const safeFilename = filename.replace(/[/\\]/g, "_");
  const fileUri = `${FileSystem.cacheDirectory}${safeFilename}`;

  await FileSystem.writeAsStringAsync(fileUri, csvContent, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  // ── 3. Invoke share sheet ─────────────────────────────────────────────────
  await Sharing.shareAsync(fileUri, {
    mimeType:  "text/csv",
    dialogTitle: "Export Expense Ledger",  // Android only — shown above the Intent chooser
    UTI:       "public.comma-separated-values-text",  // iOS UTI for CSV files
  });

  // ── 4. Deferred cleanup ───────────────────────────────────────────────────
  // Wait 3 seconds before deleting so the receiving app has time to read the
  // file before it's removed. The share sheet's completion callback isn't
  // reliable enough to use for cleanup timing on all platforms.
  setTimeout(async () => {
    try {
      const info = await FileSystem.getInfoAsync(fileUri);
      if (info.exists) {
        await FileSystem.deleteAsync(fileUri, { idempotent: true });
      }
    } catch {
      // Cleanup failure is non-fatal — the OS will purge the cache eventually
    }
  }, 3_000);
}
