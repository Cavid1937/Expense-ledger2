// src/utils/notifications.ts
// =============================================================================
// Push notification utility layer.
//
// Responsibilities:
//   1. Request the user's permission to send push notifications
//   2. Retrieve the Expo Push Token (unique per device + Expo project)
//   3. Configure the foreground notification handler so alerts display
//      even when the app is actively in the foreground
//   4. Configure Android notification channels (required for Android 8+)
//
// Expo Push Token vs. FCM/APNs token:
//   We use getExpoPushTokenAsync() which returns an Expo-managed token
//   (format: "ExponentPushToken[xxxx]"). Expo's push service translates
//   this to the underlying APNs (iOS) or FCM (Android) token, handling
//   platform differences transparently. This means:
//     - No Firebase project setup needed for local/Expo Go testing
//     - For production builds, we can swap to getRawFCMToken() if we
//       want to use FCM directly — the API module abstracts this
//
// Permission strategy:
//   We request permissions lazily — called only after the user is
//   authenticated (from _layout.tsx). We never request on the login
//   screen, which would be poor UX.
//
//   On iOS: The system permission dialog fires here. Best practice is to
//   explain WHY before asking (see the "soft prompt" note in _layout.tsx).
//   On Android 13+: Also requires a runtime permission (POST_NOTIFICATIONS).
//   Below Android 13: Granted automatically.
// =============================================================================

import * as Notifications       from "expo-notifications";
import * as Device               from "expo-device";
import { Platform }              from "react-native";
import Constants                 from "expo-constants";

// ── Foreground notification handler ──────────────────────────────────────────
// This must be called once at the module level (not inside a component).
// It controls how notifications behave when the app is in the foreground.
// Without this, foreground notifications are silently swallowed on iOS.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,    // Show the banner even when app is open
    shouldPlaySound: true,    // Play the default notification sound
    shouldSetBadge:  true,    // Increment the app badge count
  }),
});

// ── Android notification channel ──────────────────────────────────────────────
// Android 8+ (API 26+) requires a channel for every notification category.
// Without a channel, notifications are silently dropped on Android O+.
export const BUDGET_ALERT_CHANNEL_ID = "budget_alerts";

async function ensureAndroidChannel(): Promise<void> {
  if (Platform.OS !== "android") return;

  await Notifications.setNotificationChannelAsync(BUDGET_ALERT_CHANNEL_ID, {
    name:              "Budget Alerts",
    description:       "Notifications when you approach or exceed a spending limit",
    importance:        Notifications.AndroidImportance.HIGH,
    sound:             "default",
    vibrationPattern:  [0, 250, 250, 250],
    lightColor:        "#C0613A",   // Terracotta — matches our budget warning color
    enableLights:      true,
    enableVibrate:     true,
    showBadge:         true,
  });
}

// ── Permission request ────────────────────────────────────────────────────────

export type NotificationSetupResult =
  | { success: true;  token: string }
  | { success: false; reason: "simulator" | "denied" | "unavailable" | "error"; message: string };

/**
 * Requests notification permissions and retrieves the Expo Push Token.
 *
 * Returns a discriminated union so the caller can handle each failure mode:
 *   - "simulator": Can't get a real token on a simulator (expected in dev)
 *   - "denied":    User declined — we should respect this and not ask again
 *   - "unavailable": expo-notifications not available (rare)
 *   - "error":     Unexpected error during token fetch
 *
 * @returns NotificationSetupResult
 */
export async function setupPushNotifications(): Promise<NotificationSetupResult> {
  // ── 1. Simulators can't receive real push notifications ───────────────────
  // We still set up the foreground handler and channel for testing
  // notification UI, but we can't get a real push token.
  if (!Device.isDevice) {
    console.log("[notifications] Skipping push token — running on simulator");
    return {
      success: false,
      reason:  "simulator",
      message: "Push tokens are not available on simulators. Use a real device for push notifications.",
    };
  }

  // ── 2. Ensure Android channel exists ──────────────────────────────────────
  await ensureAndroidChannel();

  // ── 3. Check / request permission ─────────────────────────────────────────
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync({
      ios: {
        allowAlert:    true,
        allowBadge:    true,
        allowSound:    true,
        allowProvisional: false,  // Don't use provisional — budget alerts need prominence
      },
    });
    finalStatus = status;
  }

  if (finalStatus !== "granted") {
    console.log("[notifications] Permission denied by user");
    return {
      success: false,
      reason:  "denied",
      message: "Notification permission was not granted. Budget alerts will not be delivered.",
    };
  }

  // ── 4. Retrieve Expo Push Token ───────────────────────────────────────────
  try {
    // projectId is required for getExpoPushTokenAsync in SDK 49+
    // It lives in Constants.expoConfig.extra.eas.projectId (set in app.json)
    const projectId =
      Constants.expoConfig?.extra?.eas?.projectId ??
      Constants.easConfig?.projectId;

    if (!projectId) {
      console.warn(
        "[notifications] No EAS projectId found in app.json. " +
        "Add it under expo.extra.eas.projectId to receive push notifications in production."
      );
    }

    const { data: token } = await Notifications.getExpoPushTokenAsync(
      projectId ? { projectId } : undefined
    );

    console.log("[notifications] Push token retrieved:", token);
    return { success: true, token };

  } catch (error: any) {
    console.error("[notifications] Failed to get push token:", error);
    return {
      success: false,
      reason:  "error",
      message: error?.message ?? "Failed to retrieve push token.",
    };
  }
}

// ── Notification response helpers ─────────────────────────────────────────────

/**
 * Extracts the navigation target from a notification's data payload.
 * Our backend cron job sends: { screen: "budgets", budgetId?: string }
 *
 * Returns a route string or null if no navigation is required.
 */
export function getNavigationTargetFromNotification(
  notification: Notifications.Notification
): string | null {
  const data = notification.request.content.data as Record<string, unknown>;

  if (!data) return null;

  switch (data.screen) {
    case "budgets":
      // Navigate to the specific budget if an ID was provided,
      // otherwise go to the budgets overview tab
      return "/(tabs)/budgets";

    case "transaction":
      // Future: deep-link to a specific transaction
      return data.transactionId ? `/transaction/${data.transactionId}` : null;

    default:
      return null;
  }
}

// ── Badge management ──────────────────────────────────────────────────────────

/** Clears the app badge count — call when the user opens the Budgets tab */
export async function clearBadge(): Promise<void> {
  await Notifications.setBadgeCountAsync(0);
}
