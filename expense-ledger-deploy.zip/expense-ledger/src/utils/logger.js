// src/utils/logger.js
// =============================================================================
// Centralised Winston logger. Use this instead of console.log everywhere so
// that logs are structured, leveled, and can be redirected to a log service
// (Datadog, CloudWatch, etc.) by swapping a single transport in production.
// =============================================================================

const { createLogger, format, transports } = require("winston");

const { combine, timestamp, printf, colorize, errors } = format;

// ── Custom log format for development (human-readable) ────────────────────────
const devFormat = combine(
  colorize({ all: true }),
  timestamp({ format: "HH:mm:ss" }),
  errors({ stack: true }),           // Print full stack trace on Error objects
  printf(({ level, message, timestamp, stack }) => {
    return stack
      ? `${timestamp} ${level}: ${message}\n${stack}`
      : `${timestamp} ${level}: ${message}`;
  })
);

// ── JSON format for production (machine-readable, easy to ingest) ─────────────
const prodFormat = combine(
  timestamp(),
  errors({ stack: true }),
  format.json()
);

const logger = createLogger({
  level:      process.env.LOG_LEVEL || "info",
  format:     process.env.NODE_ENV === "production" ? prodFormat : devFormat,
  transports: [
    new transports.Console(),
    // Uncomment to write logs to files in production:
    // new transports.File({ filename: "logs/error.log",  level: "error" }),
    // new transports.File({ filename: "logs/combined.log" }),
  ],
  // Don't crash the process on unhandled promise rejections
  exitOnError: false,
});

module.exports = logger;
