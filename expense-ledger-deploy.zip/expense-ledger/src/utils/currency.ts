// src/utils/currency.ts
// =============================================================================
// Currency conversion utilities — the bridge between user-facing decimals and
// the backend's integer-cents storage format.
//
// Why this matters:
//   The backend stores ALL monetary values as bigint cents (e.g. $12.50 = 1250)
//   to eliminate floating-point arithmetic errors entirely. The frontend speaks
//   in human decimals (e.g. "12.50"). These two functions are the ONLY place
//   that conversion happens — never inline in components or stores.
//
// Floating-point safety:
//   0.1 + 0.2 === 0.30000000000000004  ← This is why we use Math.round
//   Math.round(0.1 * 100 + 0.2 * 100) = 30  ✓
//   Math.round((0.1 + 0.2) * 100)      = 30  ✓ (Math.round saves us here too)
// =============================================================================

/**
 * Converts a user-facing decimal amount to integer cents for the backend.
 *
 * Uses Math.round to eliminate floating-point imprecision:
 *   toCents(50.25)    → 5025
 *   toCents(0.1)      → 10    (not 9 — Math.round protects us)
 *   toCents(1000)     → 100000
 *   toCents(0)        → 0
 *   toCents(-250.99)  → -25099 (handles overdraft / credit balance display)
 *
 * @param decimalAmount - A floating-point number as entered by the user
 * @returns             - A safe integer in cents, ready to send to the API
 */
export function toCents(decimalAmount: number): number {
  if (!isFinite(decimalAmount)) {
    throw new Error(`toCents: received non-finite value "${decimalAmount}"`);
  }
  return Math.round(decimalAmount * 100);
}

/**
 * Converts integer cents from the backend into a display-ready decimal string.
 *
 * Returns a string (not a number) because:
 *   1. toFixed(2) guarantees exactly 2 decimal places for display ("50.00")
 *   2. Returning a number would allow (100 / 100) = 1 to display as "1" not "1.00"
 *
 * Examples:
 *   toDecimal(5025)   → "50.25"
 *   toDecimal(100000) → "1000.00"
 *   toDecimal(1)      → "0.01"
 *   toDecimal(0)      → "0.00"
 *   toDecimal(-25099) → "-250.99"
 *
 * @param centsAmount - Integer cents value from the API response
 * @returns           - A formatted string with exactly 2 decimal places
 */
export function toDecimal(centsAmount: number): string {
  return (centsAmount / 100).toFixed(2);
}

/**
 * Formats cents as a full currency string with a symbol for display in the UI.
 * Respects locale formatting (comma separators, etc.).
 *
 * Examples:
 *   formatCurrency(5025, "$")   → "$50.25"
 *   formatCurrency(100000, "€") → "€1,000.00"
 *   formatCurrency(-25099, "£") → "-£250.99"
 *
 * @param centsAmount   - Integer cents value from the API
 * @param currencySymbol - The user's configured symbol (from auth store settings)
 * @returns              - A fully formatted, display-ready currency string
 */
export function formatCurrency(centsAmount: number, currencySymbol: string): string {
  const isNegative = centsAmount < 0;
  const absolute   = Math.abs(centsAmount) / 100;

  // toLocaleString gives us thousand separators and exactly 2 decimal places
  const formatted = absolute.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return isNegative
    ? `-${currencySymbol}${formatted}`
    :  `${currencySymbol}${formatted}`;
}

/**
 * Parses a user's text input into a safe decimal number.
 * Strips currency symbols, commas, and whitespace before parsing.
 * Returns null if the input is not a valid number.
 *
 * Use this on text field onChangeText handlers before calling toCents().
 *
 * Examples:
 *   parseAmountInput("50.25")   → 50.25
 *   parseAmountInput("$1,000")  → 1000
 *   parseAmountInput("abc")     → null
 *   parseAmountInput("")        → null
 *
 * @param raw - Raw string from a TextInput
 * @returns     Parsed number or null if invalid
 */
export function parseAmountInput(raw: string): number | null {
  // Remove currency symbols, commas, and surrounding whitespace
  const cleaned = raw.replace(/[^\d.-]/g, "").trim();
  if (!cleaned) return null;

  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? null : parsed;
}
