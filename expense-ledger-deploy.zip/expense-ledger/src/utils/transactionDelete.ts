// src/utils/transactionDelete.ts
// =============================================================================
// Shared transaction delete utility.
//
// Centralising this logic means the Alert copy, mutation call, and cache
// invalidation pattern is identical whether the user deletes from:
//   - The swipeable LedgerItem
//   - The Transaction Detail screen
//   - Any future entry point
//
// The function returns a Promise<boolean> so the caller knows whether the
// delete actually happened (useful for animating the row out of the list).
// =============================================================================

import { Alert }        from "react-native";
import type { QueryClient } from "react-query";
import apiClient        from "../api/client";

/**
 * Shows a native confirmation alert and, if confirmed, deletes the transaction
 * via the API and invalidates all related React Query caches.
 *
 * @param transactionId  - UUID of the transaction to delete
 * @param queryClient    - React Query client for cache invalidation
 * @param specificId     - If true, also invalidates ["transaction", transactionId]
 *                         (used when deleting from the Detail screen)
 * @returns              - true if deleted, false if cancelled
 */
export function confirmAndDeleteTransaction(
  transactionId: string,
  queryClient:   QueryClient,
  specificId     = false
): Promise<boolean> {
  return new Promise((resolve) => {
    Alert.alert(
      "Delete Transaction?",
      "This will reverse the balance effect on your account and cannot be undone.",
      [
        {
          text:    "Cancel",
          style:   "cancel",
          onPress: () => resolve(false),
        },
        {
          text:    "Delete",
          style:   "destructive",
          onPress: async () => {
            try {
              await apiClient.delete(`/transactions/${transactionId}`);

              // Invalidate all caches that reference transactions or balances
              await Promise.all([
                queryClient.invalidateQueries("recent-transactions"),
                queryClient.invalidateQueries(["transactions"]),
                queryClient.invalidateQueries("accounts-summary"),
                queryClient.invalidateQueries("budget-progress"),
                ...(specificId
                  ? [queryClient.invalidateQueries(["transaction", transactionId])]
                  : []
                ),
              ]);

              resolve(true);
            } catch {
              Alert.alert(
                "Delete Failed",
                "Could not delete this transaction. Please try again."
              );
              resolve(false);
            }
          },
        },
      ],
      { cancelable: true, onDismiss: () => resolve(false) }
    );
  });
}
