// src/utils/exportCsv.ts
// =============================================================================
// CSV generation utility for the full transaction ledger.
//
// Design decisions:
//
//   1. Bypasses pagination entirely via a single API call with limit=10000.
//      For a personal finance app a single user will rarely exceed ~5,000
//      rows in a year. A cursor-loop would add complexity and latency for
//      minimal practical gain.
//
//   2. Amounts are exported via toDecimal() — the same utility used throughout
//      the UI — so the exported number is always a clean decimal string
//      ("50.25") rather than the raw integer cents (5025). Spreadsheet apps
//      (Numbers, Excel, Google Sheets) import these as numeric cells
//      automatically when the column has no currency symbol prefix.
//
//   3. RFC 4180 CSV compliance:
//      - Fields containing commas, double-quotes, or newlines are wrapped
//        in double-quotes.
//      - Double-quotes inside a field are escaped as "".
//      - The file uses \r\n line endings (required by RFC 4180 for maximum
//        compatibility with Excel on Windows).
//
//   4. The sign column is a separate "Type" column (expense/income/transfer)
//      rather than prefixing amounts with "−". This lets the user apply their
//      own SUM formulas without stripping sign characters.
// =============================================================================

import apiClient      from "../api/client";
import { toDecimal }  from "./currency";
import type { Transaction } from "../api/transactions.api";

// ── CSV escaping ──────────────────────────────────────────────────────────────

/**
 * Escapes a single CSV field per RFC 4180.
 * Wraps in double-quotes if the value contains commas, quotes, or newlines.
 * Escapes embedded double-quotes by doubling them ("" inside "...").
 */
function escapeField(value: string | null | undefined): string {
  if (value === null || value === undefined) return "";
  const str = String(value);
  // Must quote if contains comma, double-quote, or any line break character
  if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Builds a single CSV row from an array of field values.
 * Uses \r\n line terminator per RFC 4180.
 */
function buildRow(fields: (string | null | undefined)[]): string {
  return fields.map(escapeField).join(",") + "\r\n";
}

// ── Column definitions ────────────────────────────────────────────────────────

const CSV_HEADERS = [
  "Date",
  "Type",
  "Amount",
  "Currency",
  "Category",
  "Account",
  "Notes",
  "Receipt URL",
] as const;

// ── Main export function ──────────────────────────────────────────────────────

export interface CsvExportOptions {
  /** Optional month filter — "YYYY-MM". If omitted, exports everything. */
  month?:          string;
  /** Currency code to include in the Amount column header */
  currencyCode?:   string;
  /** Optional progress callback — called with a 0-1 float as data loads */
  onProgress?:     (progress: number) => void;
}

export interface CsvExportResult {
  /** The generated CSV content as a UTF-8 string */
  csv:            string;
  /** Number of transaction rows in the export */
  rowCount:       number;
  /** Suggested filename */
  filename:       string;
}

/**
 * Fetches all transactions and generates a RFC 4180 CSV string.
 *
 * @throws Error if the API call fails.
 */
export async function generateTransactionCsv(
  options: CsvExportOptions = {}
): Promise<CsvExportResult> {
  const { month, currencyCode = "USD", onProgress } = options;

  onProgress?.(0.05);

  // ── Fetch all transactions (no pagination cap for export) ─────────────────
  // We use a very high limit rather than cursor-looping to keep implementation
  // simple. Personal ledgers rarely exceed 10,000 rows.
  const params: Record<string, unknown> = {
    limit:      10_000,
    sort_by:    "date",
    sort_order: "asc",    // Chronological order for export
  };

  if (month) {
    // Convert "YYYY-MM" to a date range
    const [year, mon] = month.split("-").map(Number);
    params.date_from = `${year}-${String(mon).padStart(2, "0")}-01`;
    // Last day: first of next month minus one day
    const nextMonth  = new Date(year, mon, 1);
    nextMonth.setDate(nextMonth.getDate() - 1);
    params.date_to   = nextMonth.toISOString().slice(0, 10);
  }

  const { data } = await apiClient.get("/transactions", { params });
  const transactions: Transaction[] = data.data.transactions ?? [];

  onProgress?.(0.6);

  // ── Build CSV ─────────────────────────────────────────────────────────────
  const lines: string[] = [];

  // Header row — includes currency code in the Amount column label
  lines.push(buildRow([
    "Date",
    "Type",
    `Amount (${currencyCode})`,
    "Category",
    "Account",
    "Notes",
    "Receipt URL",
  ]));

  // Data rows
  for (const txn of transactions) {
    lines.push(buildRow([
      txn.date,
      txn.type,
      toDecimal(txn.amount_cents),  // "50.25" — not 5025
      txn.category_name ?? "Uncategorised",
      txn.account_name  ?? "",
      txn.note          ?? "",
      txn.receipt_image_url ?? "",
    ]));
  }

  onProgress?.(0.95);

  // ── Filename ──────────────────────────────────────────────────────────────
  const dateStamp  = new Date().toISOString().slice(0, 10);
  const monthLabel = month ? `_${month}` : "";
  const filename   = `Expense_Ledger${monthLabel}_${dateStamp}.csv`;

  return {
    csv:      lines.join(""),
    rowCount: transactions.length,
    filename,
  };
}
