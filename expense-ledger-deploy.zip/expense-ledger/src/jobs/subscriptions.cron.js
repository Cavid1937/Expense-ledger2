// src/jobs/subscriptions.cron.js
// =============================================================================
// Daily Subscription Billing Cron Job
// =============================================================================
//
// Runs at 00:01 every day (server local time). For each active subscription
// whose next_billing_date is today or earlier, it creates a transaction and
// updates the account balance atomically.
//
// ── Safety guarantees ──────────────────────────────────────────────────────────
//
//  1. IDEMPOTENCY (no double-billing):
//     Before billing, we check: last_billed_date != today.
//     This means if the cron job crashes and restarts mid-run, it can safely
//     re-process the full subscriptions list — any already-billed subscription
//     is skipped because its last_billed_date was already updated.
//     We also SELECT ... FOR UPDATE the subscription row itself inside the
//     transaction, ensuring two simultaneous cron instances can't both bill
//     the same subscription.
//
//  2. ATOMICITY (no partial billing):
//     Each subscription is billed inside its own db.transaction() block:
//       - INSERT into transactions
//       - UPDATE accounts.balance_cents (atomic increment)
//       - UPDATE subscriptions.last_billed_date + next_billing_date
//     If any of these fail, the entire operation rolls back — the account
//     balance and the transaction ledger stay perfectly in sync.
//
//  3. CONCURRENCY (safe alongside manual user transactions):
//     We lock the account row with SELECT ... FOR UPDATE inside the DB
//     transaction. This prevents a manual user transaction (which also uses
//     FOR UPDATE on the account) from racing the cron job and applying
//     two balance deltas on a stale read.
//
//  4. ISOLATION (one failure doesn't stop the batch):
//     Each subscription is processed in its own try/catch. A failed billing
//     (e.g. DB timeout on one subscription) is logged and skipped — the job
//     continues processing remaining subscriptions rather than halting entirely.
//
//  5. EXPIRED SUBSCRIPTIONS:
//     If a subscription has an end_date and today is past it, the subscription
//     is automatically paused rather than billed.
//
// ── Execution flow ─────────────────────────────────────────────────────────────
//
//   00:01 ──► fetchDueSubscriptions()
//                  SELECT where status='active'
//                         AND next_billing_date <= today
//                         AND (end_date IS NULL OR end_date >= today)
//               ──► for each subscription:
//                       handleExpired()          → pause if past end_date
//                       checkIdempotency()       → skip if already billed today
//                       db.transaction():
//                           SELECT account FOR UPDATE
//                           billSubscription()   → INSERT transaction
//                                                → UPDATE balance (atomic increment)
//                                                → UPDATE last_billed_date + next_billing_date
//                       log result
//
// =============================================================================

const cron    = require("node-cron");
const { db }  = require("../config/database");
const logger  = require("../utils/logger");
const { billSubscription } = require("../modules/subscriptions/subscriptions.service");

// ── Constants ─────────────────────────────────────────────────────────────────

// Cron expression: "1 0 * * *" = 00:01 every day
// Format: minute hour day-of-month month day-of-week
const CRON_SCHEDULE = "1 0 * * *";

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Returns today's date as a YYYY-MM-DD string in UTC.
 * We use UTC consistently to avoid timezone-related double-billing or
 * missed-billing issues when the server's local timezone shifts (DST).
 */
function getTodayUTC() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Fetches all active subscriptions whose next_billing_date is today or overdue.
 * Includes subscriptions that are overdue (next_billing_date < today) so we
 * catch up any missed billing from previous failed cron runs.
 *
 * We do NOT filter out already-billed-today subscriptions here — the
 * idempotency check inside the transaction handles that. This keeps the
 * query simple and the guard logic explicit and readable.
 *
 * @param {string} today - YYYY-MM-DD
 * @returns {object[]} Array of subscription rows
 */
async function fetchDueSubscriptions(today) {
  return db("subscriptions")
    .where("status",            "active")
    .where("next_billing_date", "<=", today)
    .where("auto_create_transaction", true)
    // Include subscriptions with no end_date OR whose end_date is still future
    .where(function () {
      this.whereNull("end_date").orWhere("end_date", ">=", today);
    })
    .select("*");
}

/**
 * Pauses an expired subscription (end_date has passed).
 * Returns true if the subscription was paused, false if it was still valid.
 *
 * @param {object} subscription
 * @param {string} today - YYYY-MM-DD
 * @returns {boolean} true if expired and paused
 */
async function handleExpiredSubscription(subscription, today) {
  if (subscription.end_date && subscription.end_date < today) {
    await db("subscriptions")
      .where({ id: subscription.id })
      .update({ status: "paused", updated_at: new Date() });

    logger.info(
      `[cron:subscriptions] Paused expired subscription ` +
      `"${subscription.name}" (${subscription.id}) — ` +
      `end_date was ${subscription.end_date}`
    );
    return true;
  }
  return false;
}

/**
 * Idempotency guard: returns true if this subscription was already billed today.
 * This is the core protection against double-billing on cron restarts.
 *
 * last_billed_date is updated atomically inside the DB transaction at the end
 * of billSubscription(), so this check is reliable even under concurrent execution.
 *
 * @param {object} subscription
 * @param {string} today - YYYY-MM-DD
 * @returns {boolean} true if already billed today (should skip)
 */
function alreadyBilledToday(subscription, today) {
  return subscription.last_billed_date === today;
}

// ── Core billing runner ───────────────────────────────────────────────────────

/**
 * Processes a single subscription billing cycle.
 *
 * Steps (all inside a single DB transaction for atomicity):
 *   1. Lock the subscription row FOR UPDATE (prevents concurrent cron instances
 *      from billing the same subscription simultaneously)
 *   2. Re-read last_billed_date from the locked row (double-check idempotency
 *      with the freshest data, after the lock is held)
 *   3. Lock the account row FOR UPDATE (prevents race with manual transactions)
 *   4. Delegate to billSubscription() which:
 *        - INSERTs a transaction row
 *        - Atomically decrements account.balance_cents
 *        - Updates subscription.last_billed_date and next_billing_date
 *
 * @param {object} subscription - Subscription row (pre-fetched, may be slightly stale)
 * @param {string} today        - YYYY-MM-DD billing date
 * @returns {{ status: "billed" | "skipped", nextBillingDate?: string }}
 */
async function processSubscription(subscription, today) {
  return db.transaction(async (trx) => {
    // ── Step 1: Lock the subscription row ─────────────────────────────────────
    // Re-read inside the transaction to get the most current state.
    // FOR UPDATE ensures two cron processes can't process the same subscription
    // at the same time — the second one blocks until the first commits.
    const locked = await trx("subscriptions")
      .where({ id: subscription.id })
      .forUpdate()          // Row-level lock held until transaction commits
      .first();

    if (!locked) {
      // Subscription was deleted between fetch and lock — skip silently
      return { status: "skipped", reason: "subscription no longer exists" };
    }

    // ── Step 2: Re-check idempotency with freshest data (post-lock) ───────────
    // This is the critical guard: after acquiring the lock, we re-read
    // last_billed_date. If another cron instance already committed a billing
    // for today before we got the lock, we see it here and skip.
    if (alreadyBilledToday(locked, today)) {
      return { status: "skipped", reason: "already billed today (idempotency guard)" };
    }

    // ── Step 3: Lock the account row ──────────────────────────────────────────
    // This serialises the balance update with any concurrent manual transaction
    // that the user might be submitting at the same moment.
    // The transactions module also uses FOR UPDATE on accounts — both will
    // queue up and execute sequentially, never on a stale balance.
    const account = await trx("accounts")
      .where({ id: locked.account_id })
      .forUpdate()
      .first();

    if (!account) {
      throw new Error(`Account ${locked.account_id} not found for subscription ${locked.id}`);
    }

    // ── Step 4: Execute the billing ────────────────────────────────────────────
    // billSubscription() handles: INSERT transaction, UPDATE balance (increment),
    // UPDATE last_billed_date + next_billing_date — all on the trx connection.
    const { transaction, nextBillingDate } = await billSubscription(trx, locked, today);

    return {
      status:          "billed",
      transactionId:   transaction.id,
      nextBillingDate,
    };
  });
}

// ── Main job function ─────────────────────────────────────────────────────────

/**
 * The main cron job body. Fetches all due subscriptions and processes each one.
 * Each subscription is processed independently so one failure doesn't block others.
 *
 * Results are aggregated and logged as a summary at the end of each run.
 */
async function runSubscriptionBilling() {
  const today = getTodayUTC();
  const runStart = Date.now();

  logger.info(`[cron:subscriptions] ──────────────────────────────────────`);
  logger.info(`[cron:subscriptions] Starting billing run for ${today}`);

  let billed  = 0;
  let skipped = 0;
  let failed  = 0;
  let expired = 0;

  let subscriptions = [];

  try {
    subscriptions = await fetchDueSubscriptions(today);
  } catch (fetchError) {
    // If we can't even query the DB, log and bail — don't proceed
    logger.error(
      `[cron:subscriptions] FATAL: Failed to fetch due subscriptions: ${fetchError.message}`,
      { stack: fetchError.stack }
    );
    return;
  }

  if (subscriptions.length === 0) {
    logger.info(`[cron:subscriptions] No subscriptions due today. Run complete.`);
    return;
  }

  logger.info(
    `[cron:subscriptions] Found ${subscriptions.length} subscription(s) to process`
  );

  // ── Process each subscription independently ────────────────────────────────
  for (const subscription of subscriptions) {
    try {
      // Check expiry first (outside the DB transaction — just a status update)
      const wasExpired = await handleExpiredSubscription(subscription, today);
      if (wasExpired) {
        expired++;
        continue;
      }

      // Quick pre-check before acquiring DB locks (performance optimisation —
      // avoids opening a transaction for already-billed subscriptions)
      if (alreadyBilledToday(subscription, today)) {
        logger.debug(
          `[cron:subscriptions] Skipping "${subscription.name}" (${subscription.id}) ` +
          `— already billed today (pre-lock check)`
        );
        skipped++;
        continue;
      }

      // Process the billing atomically
      const result = await processSubscription(subscription, today);

      if (result.status === "billed") {
        billed++;
        logger.info(
          `[cron:subscriptions] ✓ Billed "${subscription.name}" ` +
          `(${subscription.id}) — ` +
          `${subscription.amount_cents} cents → ` +
          `txn: ${result.transactionId}, ` +
          `next billing: ${result.nextBillingDate}`
        );
      } else {
        skipped++;
        logger.debug(
          `[cron:subscriptions] → Skipped "${subscription.name}" ` +
          `(${subscription.id}): ${result.reason}`
        );
      }
    } catch (error) {
      // This subscription failed — log it and move on to the next one.
      // The failed subscription will be retried on the next cron run
      // because last_billed_date was NOT updated (the transaction rolled back).
      failed++;
      logger.error(
        `[cron:subscriptions] ✗ Failed to bill "${subscription.name}" ` +
        `(${subscription.id}): ${error.message}`,
        { stack: error.stack }
      );
    }
  }

  const elapsed = Date.now() - runStart;

  // ── Final summary log ──────────────────────────────────────────────────────
  logger.info(
    `[cron:subscriptions] Run complete in ${elapsed}ms — ` +
    `billed: ${billed}, skipped: ${skipped}, expired: ${expired}, failed: ${failed}`
  );

  if (failed > 0) {
    logger.warn(
      `[cron:subscriptions] ${failed} subscription(s) failed to bill. ` +
      `They will be retried on the next run.`
    );
  }
}

// ── Job registration ──────────────────────────────────────────────────────────

/**
 * Registers the subscription billing cron job.
 * Call this from server.js after the DB connection is confirmed healthy.
 *
 * The job is NOT started automatically on require() — it must be explicitly
 * initialised so tests can import this module without kicking off a cron.
 *
 * Usage in server.js:
 *   const { initSubscriptionCron } = require("./src/jobs/subscriptions.cron");
 *   initSubscriptionCron();
 */
function initSubscriptionCron() {
  logger.info(
    `[cron:subscriptions] Registering billing job — schedule: "${CRON_SCHEDULE}" (00:01 daily UTC)`
  );

  const job = cron.schedule(
    CRON_SCHEDULE,
    async () => {
      try {
        await runSubscriptionBilling();
      } catch (unexpectedError) {
        // Safety net: cron.schedule swallows errors by default — we log them here
        // so they're never silently lost.
        logger.error(
          "[cron:subscriptions] Unexpected error in billing run:",
          { message: unexpectedError.message, stack: unexpectedError.stack }
        );
      }
    },
    {
      scheduled:  true,
      timezone:   "UTC",  // Always run in UTC — prevents DST-related timing drift
    }
  );

  logger.info("[cron:subscriptions] Billing job registered and active.");
  return job;
}

// ── Exports ───────────────────────────────────────────────────────────────────
// Export the main function too so it can be triggered manually in dev/tests:
//   const { runSubscriptionBilling } = require("./src/jobs/subscriptions.cron");
//   await runSubscriptionBilling(); // run immediately without waiting for cron
module.exports = { initSubscriptionCron, runSubscriptionBilling };
