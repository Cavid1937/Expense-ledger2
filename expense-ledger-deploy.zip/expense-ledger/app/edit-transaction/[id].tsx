// app/edit-transaction/[id].tsx
// =============================================================================
// Edit Transaction screen.
//
// Key technical challenge — cents → string pre-fill:
//   The form's amountInput field is typed as string (matching our Zod schema).
//   The backend stores amounts as bigint cents: 5025 = $50.25
//   We must convert: toDecimal(5025) → "50.25" (string, exactly 2 dp)
//   This is the inverse of the toCents() call we make at submit time.
//
//   The conversion happens in the useEffect that watches the fetched transaction:
//     setValue("amountInput", toDecimal(txn.amount_cents))
//   toDecimal() returns a string via .toFixed(2), which is exactly what the
//   Playfair Display TextInput expects.
//
// Form architecture:
//   Reuses transactionSchema, react-hook-form, and CategoryPicker exactly
//   as in add-transaction.tsx — no new validation logic.
//   The only difference is:
//     - defaultValues come from the fetched transaction (not empty strings)
//     - submit calls PATCH /transactions/:id instead of POST /transactions
//     - "type" cannot be changed on an existing transfer (guarded in UI)
//
// On success:
//   Invalidates ["transaction", id], "recent-transactions", ["transactions"],
//   and "accounts-summary" (because the amount or type may have changed,
//   altering the account balance), then navigates back.
// =============================================================================

import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useForm, Controller }          from "react-hook-form";
import { zodResolver }                  from "@hookform/resolvers/zod";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useFonts }                     from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";
import { transactionSchema, type TransactionFormValues } from "../../src/validations/transaction.schema";
import { CategoryPicker, DEFAULT_CATEGORIES, type Category } from "../../src/components/CategoryPicker";
import { useAuthStore }            from "../../src/store/auth.store";
import apiClient                   from "../../src/api/client";
import { fetchTransactionById }    from "../../src/api/transactions.api";
import { toCents, toDecimal }      from "../../src/utils/currency";

// ── Helpers ───────────────────────────────────────────────────────────────────

function sanitiseAmountInput(raw: string): string {
  let c     = raw.replace(/[^\d.]/g, "");
  const pts = c.split(".");
  if (pts.length > 2) c = pts[0] + "." + pts.slice(1).join("");
  if (pts[1]?.length > 2) c = pts[0] + "." + pts[1].slice(0, 2);
  return c;
}

function formatDateDisplay(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-US", {
    weekday: "long", day: "numeric", month: "long",
  });
}

const todayISO = () => new Date().toISOString().slice(0, 10);

// ── Type toggle ───────────────────────────────────────────────────────────────
function TypeToggle({
  value,
  onChange,
  disabled,
}: {
  value:    "expense" | "income";
  onChange: (v: "expense" | "income") => void;
  disabled: boolean;
}) {
  return (
    <View style={toggleStyles.wrap}>
      {(["expense", "income"] as const).map((t) => {
        const active = value === t;
        return (
          <Pressable key={t} onPress={() => !disabled && onChange(t)}
            style={[toggleStyles.pill, active && toggleStyles.pillActive, disabled && { opacity: 0.5 }]}
            accessibilityRole="button" accessibilityState={{ selected: active, disabled }}>
            <Text style={[toggleStyles.label, active && toggleStyles.labelActive]}>
              {t === "expense" ? "Expense" : "Income"}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const toggleStyles = StyleSheet.create({
  wrap:        { flexDirection: "row", backgroundColor: COLORS.bgCard, borderRadius: RADIUS.full, padding: 3, alignSelf: "center", marginBottom: SPACE.lg, borderWidth: 1, borderColor: COLORS.rule },
  pill:        { paddingVertical: SPACE.sm, paddingHorizontal: SPACE.lg, borderRadius: RADIUS.full },
  pillActive:  { backgroundColor: COLORS.ink },
  label:       { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.sm, color: COLORS.inkMuted, letterSpacing: 0.4 },
  labelActive: { color: COLORS.inkInvert, fontFamily: FONTS.bodySemiBold },
});

// ── Detail row (category / date picker) ──────────────────────────────────────
function DetailRow({
  icon, label, value, placeholder, onPress, error,
}: {
  icon: string; label: string; value?: string;
  placeholder: string; onPress: () => void; error?: string;
}) {
  return (
    <>
      <Pressable onPress={onPress}
        style={({ pressed }) => [rowStyles.row, pressed && { opacity: 0.65 }]}
        accessibilityRole="button" accessibilityLabel={label}>
        <View style={rowStyles.iconWrap}><Text style={rowStyles.icon}>{icon}</Text></View>
        <View style={rowStyles.textWrap}>
          <Text style={rowStyles.rowLabel}>{label}</Text>
          <Text style={[rowStyles.rowValue, !value && rowStyles.placeholder]}>
            {value ?? placeholder}
          </Text>
        </View>
        <Text style={rowStyles.chevron}>›</Text>
      </Pressable>
      {error && <Text style={rowStyles.error}>{error}</Text>}
    </>
  );
}

const rowStyles = StyleSheet.create({
  row:        { flexDirection: "row", alignItems: "center", paddingVertical: SPACE.md, gap: SPACE.md },
  iconWrap:   { width: 38, height: 38, borderRadius: RADIUS.md, backgroundColor: COLORS.bgCard, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: COLORS.rule },
  icon:       { fontSize: 17 },
  textWrap:   { flex: 1 },
  rowLabel:   { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, letterSpacing: 1, textTransform: "uppercase", marginBottom: 2 },
  rowValue:   { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.ink },
  placeholder:{ fontFamily: FONTS.bodyRegular, color: COLORS.inkMuted },
  chevron:    { fontFamily: FONTS.bodyBold, fontSize: FONT_SIZE.xl, color: COLORS.rule },
  error:      { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.xs, color: COLORS.negative, paddingLeft: 54, marginBottom: SPACE.xs },
});

// ── Skeleton loader ───────────────────────────────────────────────────────────
function EditSkeleton() {
  return (
    <View style={styles.screen}>
      <View style={styles.topBar}>
        <View style={{ width: 60, height: 16, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={{ alignItems: "center", paddingVertical: SPACE.xl }}>
        <View style={{ width: 220, height: 68, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={{ paddingHorizontal: SPACE.lg, gap: SPACE.md }}>
        {[1,2,3,4].map(i => (
          <View key={i} style={{ height: 54, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.md }} />
        ))}
      </View>
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────
export default function EditTransactionScreen() {
  const { id }         = useLocalSearchParams<{ id: string }>();
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [selectedCategory,   setSelectedCategory]   = useState<Category | null>(null);
  const [serverError,        setServerError]         = useState<string | null>(null);

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black, PlayfairDisplay_700Bold,
    DMSans_400Regular, DMSans_500Medium, DMSans_600SemiBold,
  });

  // ── Fetch existing transaction ─────────────────────────────────────────────
  const { data: txn, isLoading } = useQuery(
    ["transaction", id],
    () => fetchTransactionById(id!),
    { enabled: !!id, staleTime: 30_000 }
  );

  // ── Form setup ─────────────────────────────────────────────────────────────
  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<TransactionFormValues>({
    resolver:      zodResolver(transactionSchema),
    defaultValues: {
      type:        "expense",
      amountInput: "",
      category_id: "",
      account_id:  "",
      date:        todayISO(),
      notes:       "",
    },
    mode: "onSubmit",
  });

  // ── Pre-fill form from fetched transaction ─────────────────────────────────
  // This is the critical step: toDecimal(5025) → "50.25"
  useEffect(() => {
    if (!txn) return;

    // Convert cents → decimal string for the hero amount input
    const decimalStr = toDecimal(txn.amount_cents); // e.g. "50.25"

    setValue("amountInput", decimalStr, { shouldDirty: false });
    setValue("account_id",  txn.account_id, { shouldDirty: false });
    setValue("date",        txn.date,       { shouldDirty: false });
    setValue("notes",       txn.note ?? "", { shouldDirty: false });

    // Only set type for expense/income — transfers are locked
    if (txn.type !== "transfer") {
      setValue("type", txn.type, { shouldDirty: false });
    }

    if (txn.category_id) {
      setValue("category_id", txn.category_id, { shouldDirty: false });

      // Pre-select the category in our picker state
      const cat = DEFAULT_CATEGORIES.find(c => c.id === txn.category_id);
      if (cat) setSelectedCategory(cat);
    }
  }, [txn]);

  const watchType   = watch("type");
  const watchAmount = watch("amountInput");
  const watchDate   = watch("date");

  const handleCategorySelect = useCallback((cat: Category) => {
    setSelectedCategory(cat);
    setValue("category_id", cat.id, { shouldDirty: true });
  }, [setValue]);

  // ── PATCH mutation ─────────────────────────────────────────────────────────
  const patchMutation = useMutation(
    async (values: TransactionFormValues) => {
      // THE CRITICAL CONVERSION: string "50.25" → integer cents 5025
      const amount_cents = toCents(parseFloat(values.amountInput));

      const payload: Record<string, unknown> = {
        amount_cents,
        type:        values.type,
        date:        values.date,
        note:        values.notes?.trim() || null,
        category_id: values.category_id  || null,
        account_id:  values.account_id,
      };

      const { data } = await apiClient.patch(`/transactions/${id}`, payload);
      return data;
    },
    {
      onSuccess: async () => {
        await Promise.all([
          // Update the specific transaction cache (Detail screen stays fresh)
          queryClient.invalidateQueries(["transaction", id]),
          // Update list caches (Ledger + Dashboard reflect the change)
          queryClient.invalidateQueries("recent-transactions"),
          queryClient.invalidateQueries(["transactions"]),
          // Balance may have changed if amount or type changed
          queryClient.invalidateQueries("accounts-summary"),
          queryClient.invalidateQueries("budget-progress"),
        ]);
        router.back();
      },
      onError: (err: any) => {
        setServerError(
          err?.response?.data?.message ?? "Could not save changes. Please try again."
        );
      },
    }
  );

  const onSubmit = (values: TransactionFormValues) => {
    setServerError(null);
    patchMutation.mutate(values);
  };

  // ── Loading / error states ─────────────────────────────────────────────────
  if (isLoading || !fontsLoaded) return <EditSkeleton />;

  if (!txn) {
    return (
      <View style={[styles.screen, { alignItems: "center", justifyContent: "center" }]}>
        <Text style={{ fontFamily: FONTS.bodyRegular, color: COLORS.inkMuted }}>
          Transaction not found.
        </Text>
        <Pressable onPress={() => router.back()} style={{ marginTop: SPACE.md }}>
          <Text style={{ fontFamily: FONTS.bodySemiBold, color: COLORS.sand }}>← Go back</Text>
        </Pressable>
      </View>
    );
  }

  const isTransfer   = txn.type === "transfer";
  const amountColor  = watchType === "expense" ? COLORS.negative : COLORS.positive;
  const displayAmt   = watchAmount || "0.00";

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Top bar ──────────────────────────────────────────────────── */}
        <View style={styles.topBar}>
          <Pressable onPress={() => router.back()}
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]} hitSlop={8}>
            <Text style={styles.backText}>← Cancel</Text>
          </Pressable>
          <Text style={styles.screenTitle}>Edit Transaction</Text>
          <View style={{ width: 72 }} />{/* Spacer for optical centering */}
        </View>

        {/* ── Transfer lock notice ─────────────────────────────────────── */}
        {isTransfer && (
          <View style={styles.transferNotice}>
            <Text style={styles.transferNoticeText}>
              ⇄  Transfer — type cannot be changed
            </Text>
          </View>
        )}

        {/* ── Type toggle ──────────────────────────────────────────────── */}
        {!isTransfer && (
          <Controller
            control={control}
            name="type"
            render={({ field: { value, onChange } }) => (
              <TypeToggle value={value} onChange={onChange} disabled={isTransfer} />
            )}
          />
        )}

        {/* ── Hero amount input ─────────────────────────────────────────── */}
        <View style={styles.amountBlock}>
          <Text style={[styles.currencySymbol, { color: amountColor + "99" }]}>
            {currencySymbol}
          </Text>
          <Controller
            control={control}
            name="amountInput"
            render={({ field: { onChange, value } }) => (
              <TextInput
                style={[styles.amountInput, { color: amountColor }]}
                value={value}
                onChangeText={(raw) => onChange(sanitiseAmountInput(raw))}
                placeholder="0.00"
                placeholderTextColor={COLORS.rule}
                keyboardType="decimal-pad"
                returnKeyType="done"
                selectTextOnFocus
                maxLength={12}
                accessibilityLabel="Transaction amount"
              />
            )}
          />
        </View>

        {errors.amountInput && (
          <Text style={styles.amountError}>{errors.amountInput.message}</Text>
        )}

        {/* Server error */}
        {serverError && (
          <Pressable style={styles.serverError} onPress={() => setServerError(null)}>
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </Pressable>
        )}

        <View style={styles.rule} />

        {/* ── Detail rows ──────────────────────────────────────────────── */}
        <View style={styles.detailRows}>
          <DetailRow
            icon={selectedCategory?.icon ?? "🏷️"}
            label="Category"
            value={selectedCategory?.name}
            placeholder="Select a category"
            onPress={() => setShowCategoryPicker(true)}
            error={errors.category_id?.message}
          />
          <View style={styles.innerRule} />
          <DetailRow
            icon="📅"
            label="Date"
            value={formatDateDisplay(watchDate)}
            placeholder="Select a date"
            onPress={() => Alert.alert("Date Picker", "Full date picker coming in next sprint.")}
          />
        </View>

        {/* ── Notes ────────────────────────────────────────────────────── */}
        <View style={styles.rule} />
        <Controller
          control={control}
          name="notes"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextInput
              style={styles.notesInput}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              multiline
              numberOfLines={3}
              placeholder="e.g., Roja Elysium 100ml, oversized leather jacket, or monthly salicylic acid restock."
              placeholderTextColor={COLORS.inkMuted}
              textAlignVertical="top"
            />
          )}
        />
        {errors.notes && (
          <Text style={styles.fieldError}>{errors.notes.message}</Text>
        )}

        <View style={styles.rule} />

        {/* ── Unsaved changes indicator ────────────────────────────────── */}
        {isDirty && !patchMutation.isLoading && (
          <View style={styles.dirtyBadge}>
            <Text style={styles.dirtyBadgeText}>Unsaved changes</Text>
          </View>
        )}

        {/* ── Save button ───────────────────────────────────────────────── */}
        <Pressable
          style={({ pressed }) => [
            styles.saveBtn,
            pressed && styles.saveBtnPressed,
            (patchMutation.isLoading || !isDirty) && styles.saveBtnDisabled,
          ]}
          onPress={handleSubmit(onSubmit)}
          disabled={patchMutation.isLoading || !isDirty}
          accessibilityRole="button"
          accessibilityLabel="Save changes"
        >
          {patchMutation.isLoading ? (
            <ActivityIndicator size="small" color={COLORS.inkInvert} />
          ) : (
            <Text style={styles.saveBtnText}>Save Changes</Text>
          )}
        </Pressable>

        <View style={{ height: SPACE.xl }} />
      </ScrollView>

      {/* ── Category picker ──────────────────────────────────────────────── */}
      <CategoryPicker
        visible={showCategoryPicker}
        selectedId={selectedCategory?.id ?? null}
        transactionType={isTransfer ? "expense" : watchType}
        onSelect={handleCategorySelect}
        onClose={() => setShowCategoryPicker(false)}
      />
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { paddingHorizontal: SPACE.lg, paddingBottom: SPACE.xxl },

  topBar: {
    flexDirection:   "row",
    justifyContent:  "space-between",
    alignItems:      "center",
    paddingTop:      SPACE.xxl,
    paddingBottom:   SPACE.lg,
  },
  backBtn:    { paddingVertical: SPACE.xs },
  backText:   { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.sand, letterSpacing: 0.2 },
  screenTitle:{ fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.base, color: COLORS.inkMid, letterSpacing: 0.3 },

  transferNotice: {
    backgroundColor: COLORS.bgCard,
    borderWidth:     1,
    borderColor:     COLORS.rule,
    borderRadius:    RADIUS.md,
    paddingVertical: SPACE.sm,
    paddingHorizontal: SPACE.md,
    marginBottom:    SPACE.lg,
    alignItems:      "center",
  },
  transferNoticeText: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMid,
    letterSpacing: 0.3,
  },

  amountBlock: {
    flexDirection:   "row",
    alignItems:      "flex-end",
    justifyContent:  "center",
    paddingVertical: SPACE.xl,
    gap:             SPACE.xs,
  },
  currencySymbol: {
    fontFamily:  FONTS.displayBold,
    fontSize:    FONT_SIZE.xxxl,
    lineHeight:  FONT_SIZE.xxxl * 1.1,
    paddingBottom: 4,
  },
  amountInput: {
    fontFamily:         "PlayfairDisplay_900Black",
    fontSize:           72,
    lineHeight:         72,
    letterSpacing:      -2,
    minWidth:           60,
    maxWidth:           260,
    textAlign:          "center",
    padding:            0,
    margin:             0,
    includeFontPadding: false,
  },
  amountError: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.negative,
    textAlign:  "center",
    marginTop:  -SPACE.md,
    marginBottom: SPACE.sm,
  },

  serverError: {
    backgroundColor: "rgba(193,18,31,0.08)",
    borderWidth:     1,
    borderColor:     COLORS.negative,
    borderRadius:    RADIUS.md,
    padding:         SPACE.md,
    marginBottom:    SPACE.md,
  },
  serverErrorText: { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.sm, color: COLORS.negative, lineHeight: 18 },

  rule:      { height: 1, backgroundColor: COLORS.rule, marginVertical: SPACE.md },
  innerRule: { height: 1, backgroundColor: COLORS.rule, opacity: 0.5 },
  detailRows:{ },

  notesInput: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.inkMid,
    lineHeight:    FONT_SIZE.base * 1.7,
    minHeight:     80,
    paddingTop:    SPACE.sm,
    paddingBottom: SPACE.sm,
  },
  fieldError: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.xs,
    color:        COLORS.negative,
    marginBottom: SPACE.xs,
  },

  dirtyBadge: {
    alignSelf:       "center",
    backgroundColor: COLORS.bgCard,
    borderRadius:    RADIUS.full,
    paddingHorizontal: SPACE.md,
    paddingVertical:   4,
    marginBottom:    SPACE.sm,
  },
  dirtyBadgeText: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 0.5,
  },

  saveBtn: {
    backgroundColor: COLORS.ink,
    borderRadius:    RADIUS.full,
    paddingVertical: 17,
    alignItems:      "center",
    justifyContent:  "center",
    marginTop:       SPACE.md,
    minHeight:       56,
    shadowColor:     "#8A7A5A",
    shadowOffset:    { width: 0, height: 5 },
    shadowOpacity:   0.18,
    shadowRadius:    12,
    elevation:       6,
  },
  saveBtnPressed:  { opacity: 0.82, transform: [{ scale: 0.985 }] },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.md,
    color:         COLORS.inkInvert,
    letterSpacing: 0.4,
  },
});
