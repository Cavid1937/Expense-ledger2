// app/transaction/[id].tsx
// =============================================================================
// Transaction Detail screen — accessible from the Ledger and Dashboard.
//
// Routing:
//   Expo Router dynamic route: /transaction/[id]
//   Navigate to it: router.push(`/transaction/${txn.id}`)
//   The [id] segment is available via useLocalSearchParams().id
//
// Data:
//   Single React Query fetch: fetchTransactionById(id)
//   Mutation: uploadReceipt() / removeReceipt() update receipt_image_url
//   After mutation: invalidateQueries to keep Ledger + Dashboard in sync
//
// UI concept: "high-end digital receipt"
//   The screen is structured like a luxury paper receipt — amount at the top
//   in massive Playfair Display Black, followed by a thin rule, then a series
//   of clean label-value rows (date, category, account, type) separated by
//   hairline borders, and the receipt attachment section at the bottom.
//   Everything is cream paper on ink — no rounded cards, no shadows.
//
// Layout (top to bottom):
//   ┌────────────────────────────────────────────┐
//   │  ← Back               [Edit] (future)      │
//   ├────────────────────────────────────────────┤
//   │                                            │
//   │         −$52.00    ← sign + amount         │
//   │         Food & Dining                      │
//   │         Sunday, April 14, 2026             │
//   │                                            │
//   ├────────────────────────────────────────────┤
//   │  DETAILS                                   │
//   │  Category  │  Food & Dining                │
//   │  Account   │  Chase Checking               │
//   │  Type      │  Expense                      │
//   │  Date      │  April 14, 2026               │
//   ├────────────────────────────────────────────┤
//   │  NOTE                                      │
//   │  "Bvlgari Tygar 100ml EDP..."              │
//   ├────────────────────────────────────────────┤
//   │  RECEIPT                                   │
//   │  [ReceiptUploader]                         │
//   ├────────────────────────────────────────────┤
//   │  Delete Transaction (destructive)          │
//   └────────────────────────────────────────────┘
// =============================================================================

import React, { useCallback } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useFonts }   from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";
import { ReceiptUploader }       from "../../src/components/ReceiptUploader";
import { useAuthStore }          from "../../src/store/auth.store";
import {
  fetchTransactionById,
  uploadReceipt,
  removeReceipt,
  type Transaction,
} from "../../src/api/transactions.api";
import { formatCurrency } from "../../src/utils/currency";
import apiClient          from "../../src/api/client";

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatLongDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-US", {
    weekday: "long",
    month:   "long",
    day:     "numeric",
    year:    "numeric",
  });
}

function formatShortDate(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-US", {
    month: "long",
    day:   "numeric",
    year:  "numeric",
  });
}

function typeLabel(type: Transaction["type"]): string {
  return type.charAt(0).toUpperCase() + type.slice(1);
}

// ── Detail row ────────────────────────────────────────────────────────────────
function DetailRow({
  label,
  value,
  last = false,
}: {
  label: string;
  value: string;
  last?: boolean;
}) {
  return (
    <View style={[detailStyles.row, !last && detailStyles.rowBorder]}>
      <Text style={detailStyles.label}>{label}</Text>
      <Text style={detailStyles.value} numberOfLines={2}>{value}</Text>
    </View>
  );
}

const detailStyles = StyleSheet.create({
  row: {
    flexDirection:  "row",
    alignItems:     "flex-start",
    justifyContent: "space-between",
    paddingVertical: SPACE.md,
    gap:             SPACE.md,
  },
  rowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.rule,
  },
  label: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMuted,
    letterSpacing: 0.3,
    width:         96,
    flexShrink:    0,
  },
  value: {
    flex:          1,
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.ink,
    textAlign:     "right",
  },
});

// ── Skeleton loader ───────────────────────────────────────────────────────────
function DetailSkeleton() {
  return (
    <View style={styles.screen}>
      {/* Back button */}
      <View style={styles.topBar}>
        <View style={{ width: 60, height: 18, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      {/* Hero */}
      <View style={styles.heroBlock}>
        <View style={{ width: 220, height: 68, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm, marginBottom: SPACE.sm }} />
        <View style={{ width: 130, height: 18, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm, marginBottom: SPACE.xs }} />
        <View style={{ width: 180, height: 14, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={styles.rule} />
      {/* Detail rows */}
      <View style={{ paddingHorizontal: SPACE.lg, paddingTop: SPACE.md }}>
        {[1, 2, 3, 4].map(i => (
          <View key={i} style={[detailStyles.row, detailStyles.rowBorder]}>
            <View style={{ width: 80, height: 13, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
            <View style={{ width: 120, height: 13, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
          </View>
        ))}
      </View>
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────
export default function TransactionDetailScreen() {
  const { id }         = useLocalSearchParams<{ id: string }>();
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black,
    PlayfairDisplay_700Bold,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_600SemiBold,
  });

  // ── Fetch transaction ──────────────────────────────────────────────────────
  const { data: txn, isLoading, isError } = useQuery(
    ["transaction", id],
    () => fetchTransactionById(id!),
    {
      enabled:   !!id,
      staleTime: 30_000,
    }
  );

  // ── Receipt upload mutation ────────────────────────────────────────────────
  const uploadMutation = useMutation(
    ({ localUri, mimeType }: { localUri: string; mimeType: string }) =>
      uploadReceipt(id!, localUri, mimeType),
    {
      onSuccess: (result) => {
        // Update the cached transaction with the new receipt URL
        // so the UI reflects the CDN URL without a full refetch
        queryClient.setQueryData<Transaction>(["transaction", id], (old) =>
          old ? { ...old, receipt_image_url: result.receipt_image_url } : old!
        );
        // Also invalidate the lists so Ledger + Dashboard stay in sync
        queryClient.invalidateQueries("recent-transactions");
        queryClient.invalidateQueries(["transactions"]);
      },
      onError: () => {
        Alert.alert("Upload Failed", "Could not upload the receipt. Please try again.");
      },
    }
  );

  // ── Receipt remove mutation ────────────────────────────────────────────────
  const removeMutation = useMutation(
    () => removeReceipt(id!),
    {
      onSuccess: () => {
        queryClient.setQueryData<Transaction>(["transaction", id], (old) =>
          old ? { ...old, receipt_image_url: null } : old!
        );
        queryClient.invalidateQueries("recent-transactions");
        queryClient.invalidateQueries(["transactions"]);
      },
      onError: () => {
        Alert.alert("Remove Failed", "Could not remove the receipt. Please try again.");
      },
    }
  );

  // ── Delete transaction ─────────────────────────────────────────────────────
  const deleteMutation = useMutation(
    () => apiClient.delete(`/transactions/${id}`),
    {
      onSuccess: () => {
        // Invalidate all transaction lists so they refetch without this entry
        queryClient.invalidateQueries("recent-transactions");
        queryClient.invalidateQueries(["transactions"]);
        queryClient.invalidateQueries("accounts-summary");
        router.back();
      },
      onError: () => {
        Alert.alert("Delete Failed", "Could not delete this transaction. Please try again.");
      },
    }
  );

  const confirmDelete = useCallback(() => {
    Alert.alert(
      "Delete Transaction",
      "This will reverse the balance effect on your account. This cannot be undone.",
      [
        { text: "Cancel",            style: "cancel"      },
        { text: "Delete",            style: "destructive",
          onPress: () => deleteMutation.mutate() },
      ]
    );
  }, [deleteMutation]);

  // ── Render states ──────────────────────────────────────────────────────────
  if (!fontsLoaded || isLoading) return <DetailSkeleton />;

  if (isError || !txn) {
    return (
      <View style={[styles.screen, { alignItems: "center", justifyContent: "center" }]}>
        <Text style={{ fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.base, color: COLORS.inkMuted }}>
          Transaction not found.
        </Text>
        <Pressable onPress={() => router.back()} style={{ marginTop: SPACE.md }}>
          <Text style={{ fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.sand }}>
            ← Go back
          </Text>
        </Pressable>
      </View>
    );
  }

  // ── Derived display values ─────────────────────────────────────────────────
  const isExpense  = txn.type === "expense";
  const isIncome   = txn.type === "income";
  const sign       = isExpense ? "−" : isIncome ? "+" : "";
  const amountStr  = formatCurrency(txn.amount_cents, currencySymbol);
  const amountColor = isExpense ? COLORS.ink : isIncome ? COLORS.positive : COLORS.inkMid;

  return (
    <View style={styles.screen}>
      {/* ── Top navigation bar ──────────────────────────────────────────── */}
      <View style={styles.topBar}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel="Go back"
        >
          <Text style={styles.backBtnText}>← Back</Text>
        </Pressable>

        {/* Future: edit button */}
        <Pressable
          style={styles.editBtn}
          onPress={() => Alert.alert("Edit Transaction", "Edit form coming in the next sprint.")}
        >
          <Text style={styles.editBtnText}>Edit</Text>
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* ── Hero: amount + category + date ──────────────────────────────── */}
        <View style={styles.heroBlock}>
          {/* Amount — Playfair Black at maximum scale */}
          <View style={styles.amountRow}>
            <Text style={[styles.sign, { color: amountColor + "AA" }]}>{sign}</Text>
            <Text
              style={[styles.amount, { color: amountColor }]}
              adjustsFontSizeToFit
              minimumFontScale={0.5}
              numberOfLines={1}
            >
              {amountStr}
            </Text>
          </View>

          {/* Category */}
          {txn.category_name && (
            <View style={styles.categoryRow}>
              {txn.category_icon && (
                <Text style={styles.categoryIcon}>{txn.category_icon}</Text>
              )}
              <Text style={styles.categoryName}>{txn.category_name}</Text>
            </View>
          )}

          {/* Date */}
          <Text style={styles.dateLabel}>{formatLongDate(txn.date)}</Text>
        </View>

        {/* ── Thick horizontal rule ────────────────────────────────────────── */}
        <View style={styles.heavyRule} />

        {/* ── Details section ──────────────────────────────────────────────── */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>DETAILS</Text>
          <View style={styles.sectionContent}>
            <DetailRow label="Type"     value={typeLabel(txn.type)}              />
            <DetailRow label="Date"     value={formatShortDate(txn.date)}        />
            <DetailRow label="Account"  value={txn.account_name ?? "—"}          />
            <DetailRow label="Category" value={txn.category_name ?? "Uncategorised"} last />
          </View>
        </View>

        {/* ── Note section (only if note exists) ───────────────────────────── */}
        {txn.note && (
          <>
            <View style={styles.rule} />
            <View style={styles.section}>
              <Text style={styles.sectionLabel}>NOTE</Text>
              <Text style={styles.noteText}>{txn.note}</Text>
            </View>
          </>
        )}

        {/* ── Receipt section ──────────────────────────────────────────────── */}
        <View style={styles.rule} />
        <View style={styles.section}>
          <ReceiptUploader
            receiptUrl={txn.receipt_image_url}
            onPickImage={(localUri, mimeType) =>
              uploadMutation.mutate({ localUri, mimeType })
            }
            onRemove={() => removeMutation.mutate()}
            isUploading={uploadMutation.isLoading}
            disabled={deleteMutation.isLoading}
          />
        </View>

        {/* ── Meta: created timestamp ─────────────────────────────────────── */}
        <View style={styles.rule} />
        <View style={styles.metaRow}>
          <Text style={styles.metaText}>
            Logged {new Date(txn.created_at).toLocaleDateString("en-US", {
              month: "short", day: "numeric", year: "numeric",
            })}
          </Text>
          {txn.created_at !== txn.updated_at && (
            <Text style={styles.metaText}>
              · Edited {new Date(txn.updated_at).toLocaleDateString("en-US", {
                month: "short", day: "numeric",
              })}
            </Text>
          )}
        </View>

        {/* ── Delete button ────────────────────────────────────────────────── */}
        <View style={styles.deleteBlock}>
          <Pressable
            onPress={confirmDelete}
            disabled={deleteMutation.isLoading}
            style={({ pressed }) => [
              styles.deleteBtn,
              pressed && styles.deleteBtnPressed,
              deleteMutation.isLoading && styles.deleteBtnDisabled,
            ]}
            accessibilityRole="button"
            accessibilityLabel="Delete transaction"
          >
            {deleteMutation.isLoading ? (
              <ActivityIndicator size="small" color={COLORS.negative} />
            ) : (
              <Text style={styles.deleteBtnText}>Delete Transaction</Text>
            )}
          </Pressable>
        </View>

        <View style={{ height: SPACE.xxxl }} />
      </ScrollView>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: {
    flex:            1,
    backgroundColor: COLORS.bg,
  },

  // Top nav
  topBar: {
    flexDirection:     "row",
    justifyContent:    "space-between",
    alignItems:        "center",
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.xxl,
    paddingBottom:     SPACE.md,
  },
  backBtn: {
    paddingVertical: SPACE.xs,
  },
  backBtnText: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.sand,
    letterSpacing: 0.2,
  },
  editBtn: {
    borderWidth:       1,
    borderColor:       COLORS.rule,
    paddingHorizontal: SPACE.md,
    paddingVertical:   6,
    borderRadius:      RADIUS.full,
  },
  editBtnText: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMid,
    letterSpacing: 0.3,
  },

  scrollContent: {
    flexGrow: 1,
  },

  // Hero
  heroBlock: {
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.lg,
    paddingBottom:     SPACE.xl,
    alignItems:        "flex-start",
  },
  amountRow: {
    flexDirection: "row",
    alignItems:    "flex-start",
    marginBottom:  SPACE.sm,
    gap:           2,
  },
  sign: {
    fontFamily:  FONTS.displayBold,
    fontSize:    FONT_SIZE.xxxl,
    lineHeight:  FONT_SIZE.xxxl * 1.1,
    paddingTop:  6,
  },
  amount: {
    fontFamily:    "PlayfairDisplay_900Black",
    fontSize:      FONT_SIZE.display,
    lineHeight:    FONT_SIZE.display,
    letterSpacing: -2,
    flexShrink:    1,
  },
  categoryRow: {
    flexDirection: "row",
    alignItems:    "center",
    gap:           SPACE.xs,
    marginBottom:  SPACE.xs,
  },
  categoryIcon: {
    fontSize: 16,
  },
  categoryName: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.md,
    color:         COLORS.inkMid,
  },
  dateLabel: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.inkMuted,
    letterSpacing: 0.2,
  },

  // Rules
  heavyRule: {
    height:          2,
    backgroundColor: COLORS.ink,
    marginHorizontal: SPACE.lg,
  },
  rule: {
    height:           1,
    backgroundColor:  COLORS.rule,
    marginHorizontal: SPACE.lg,
  },

  // Sections
  section: {
    paddingHorizontal: SPACE.lg,
    paddingVertical:   SPACE.md,
  },
  sectionLabel: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 2,
    textTransform: "uppercase",
    marginBottom:  SPACE.sm,
  },
  sectionContent: {
    // Wraps DetailRow items
  },

  // Note
  noteText: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.inkMid,
    lineHeight: FONT_SIZE.base * 1.7,
    fontStyle:  "italic",
  },

  // Meta
  metaRow: {
    flexDirection:     "row",
    paddingHorizontal: SPACE.lg,
    paddingVertical:   SPACE.md,
    gap:               SPACE.xs,
  },
  metaText: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 0.3,
  },

  // Delete
  deleteBlock: {
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.lg,
    paddingBottom:     SPACE.xl,
  },
  deleteBtn: {
    borderWidth:     1,
    borderColor:     COLORS.negative,
    borderRadius:    RADIUS.full,
    paddingVertical: 13,
    alignItems:      "center",
    justifyContent:  "center",
    minHeight:       48,
  },
  deleteBtnPressed: {
    backgroundColor: COLORS.negativeBg,
  },
  deleteBtnDisabled: {
    opacity: 0.5,
  },
  deleteBtnText: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.negative,
    letterSpacing: 0.3,
  },
});
