// app/settings/accounts.tsx
// =============================================================================
// Account Management screen.
//
// Layout concept: each account is presented as a "ledger folio" — a full-width
// row with the account name in mid-weight type and the balance rendered in
// Playfair Display at a generous size. Think a bank ledger's account summary
// page, not a generic settings list.
//
// Features:
//   - Live balance from React Query (accounts-summary cache)
//   - Show archived accounts in a separate "Archived" section at 50% opacity
//   - FAB-style "New Account" button in the header
//   - Tap any account row → navigate to manage-account/[id] (edit)
//   - Pull-to-refresh
// =============================================================================

import React, { useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { router }       from "expo-router";
import { useQuery, useQueryClient } from "react-query";
import { useFonts }     from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";
import { useAuthStore }         from "../../src/store/auth.store";
import { fetchAccountsSummary, type Account } from "../../src/api/accounts.api";
import { formatCurrency }       from "../../src/utils/currency";
import { ACCOUNT_TYPE_LABELS }  from "../../src/validations/account.schema";

// ── Account type icon map ─────────────────────────────────────────────────────
const TYPE_ICONS: Record<string, string> = {
  cash:        "💵",
  checking:    "🏦",
  savings:     "🐖",
  credit_card: "💳",
  investment:  "📈",
  loan:        "📋",
  other:       "◈",
};

// ── Account row ───────────────────────────────────────────────────────────────
function AccountRow({
  account,
  currencySymbol,
  isArchived,
}: {
  account:       Account;
  currencySymbol: string;
  isArchived:    boolean;
}) {
  const typeLabel = ACCOUNT_TYPE_LABELS[account.type as keyof typeof ACCOUNT_TYPE_LABELS] ?? account.type;
  const typeIcon  = TYPE_ICONS[account.type] ?? "◈";

  const balanceCents   = account.balance_cents;
  const isNegative     = balanceCents < 0;
  const balanceFormatted = formatCurrency(Math.abs(balanceCents), currencySymbol);
  const balanceColor   = isNegative ? COLORS.negative : COLORS.ink;

  return (
    <Pressable
      onPress={() => router.push(`/settings/manage-account/${account.id}`)}
      style={({ pressed }) => [
        rowStyles.row,
        pressed    && rowStyles.rowPressed,
        isArchived && rowStyles.rowArchived,
      ]}
      accessibilityRole="button"
      accessibilityLabel={`${account.name}, ${balanceFormatted}`}
    >
      {/* Icon */}
      <View style={[
        rowStyles.iconWrap,
        account.color ? { backgroundColor: account.color + "18" } : {},
      ]}>
        <Text style={rowStyles.icon}>{typeIcon}</Text>
        {/* Colour dot */}
        {account.color && (
          <View style={[rowStyles.colorDot, { backgroundColor: account.color }]} />
        )}
      </View>

      {/* Name + type */}
      <View style={rowStyles.meta}>
        <Text style={rowStyles.name} numberOfLines={1}>{account.name}</Text>
        <View style={rowStyles.typePillWrap}>
          <Text style={rowStyles.typeLabel}>{typeLabel}</Text>
          {!account.include_in_total && (
            <Text style={rowStyles.excludedBadge}>Excluded from total</Text>
          )}
        </View>
      </View>

      {/* Balance */}
      <View style={rowStyles.balanceWrap}>
        <Text style={[rowStyles.balance, { color: balanceColor }]}>
          {isNegative ? "−" : ""}{balanceFormatted}
        </Text>
        <Text style={rowStyles.currency}>{account.currency_code}</Text>
      </View>

      <Text style={rowStyles.chevron}>›</Text>
    </Pressable>
  );
}

const rowStyles = StyleSheet.create({
  row: {
    flexDirection:     "row",
    alignItems:        "center",
    paddingVertical:   SPACE.md,
    paddingHorizontal: SPACE.lg,
    backgroundColor:   COLORS.bg,
    gap:               SPACE.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.rule,
    minHeight:         72,
  },
  rowPressed:  { backgroundColor: COLORS.bgCard },
  rowArchived: { opacity: 0.45 },

  iconWrap: {
    width:           42,
    height:          42,
    borderRadius:    RADIUS.lg,
    backgroundColor: COLORS.bgCard,
    alignItems:      "center",
    justifyContent:  "center",
    position:        "relative",
    flexShrink:      0,
    borderWidth:     1,
    borderColor:     COLORS.rule,
  },
  icon:      { fontSize: 20 },
  colorDot:  { position: "absolute", bottom: 2, right: 2, width: 7, height: 7, borderRadius: 4 },

  meta:        { flex: 1 },
  name: {
    fontFamily: FONTS.bodyMedium,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.ink,
    lineHeight: FONT_SIZE.base * 1.3,
    marginBottom: 3,
  },
  typePillWrap: {
    flexDirection: "row",
    alignItems:    "center",
    gap:           SPACE.sm,
  },
  typeLabel: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 0.3,
  },
  excludedBadge: {
    fontFamily:      FONTS.bodyMedium,
    fontSize:        9,
    color:           COLORS.inkMuted,
    backgroundColor: COLORS.bgCard,
    borderWidth:     1,
    borderColor:     COLORS.rule,
    borderRadius:    RADIUS.sm,
    paddingHorizontal: 5,
    paddingVertical:   1,
    letterSpacing:   0.3,
  },

  balanceWrap: { alignItems: "flex-end", flexShrink: 0 },
  balance: {
    fontFamily:    "PlayfairDisplay_700Bold",
    fontSize:      FONT_SIZE.lg,
    lineHeight:    FONT_SIZE.lg * 1.2,
    letterSpacing: -0.3,
  },
  currency: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 0.5,
    marginTop:     2,
  },

  chevron: {
    fontFamily: FONTS.bodyBold,
    fontSize:   FONT_SIZE.xl,
    color:      COLORS.rule,
    lineHeight: FONT_SIZE.xl,
    flexShrink: 0,
  },
});

// ── Section header ────────────────────────────────────────────────────────────
function SectionHeader({ label }: { label: string }) {
  return (
    <View style={secStyles.wrap}>
      <Text style={secStyles.label}>{label.toUpperCase()}</Text>
      <View style={secStyles.rule} />
    </View>
  );
}

const secStyles = StyleSheet.create({
  wrap:  { paddingTop: SPACE.lg, paddingHorizontal: SPACE.lg, paddingBottom: SPACE.sm },
  label: { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, letterSpacing: 2, marginBottom: SPACE.sm },
  rule:  { height: 1, backgroundColor: COLORS.rule },
});

// ── Net worth strip ───────────────────────────────────────────────────────────
function NetWorthStrip({
  totalCents,
  currencySymbol,
}: {
  totalCents:     number;
  currencySymbol: string;
}) {
  const isNeg = totalCents < 0;
  return (
    <View style={netStyles.strip}>
      <Text style={netStyles.label}>NET WORTH</Text>
      <Text style={[netStyles.amount, isNeg && { color: "#F4827C" }]}>
        {isNeg ? "−" : ""}{formatCurrency(Math.abs(totalCents), currencySymbol)}
      </Text>
    </View>
  );
}

const netStyles = StyleSheet.create({
  strip: {
    backgroundColor: COLORS.bgInvert,
    paddingVertical:   SPACE.lg,
    paddingHorizontal: SPACE.lg,
    alignItems:        "center",
    gap:               SPACE.xs,
  },
  label: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         "#6B6860",
    letterSpacing: 2,
  },
  amount: {
    fontFamily:    "PlayfairDisplay_900Black",
    fontSize:      FONT_SIZE.xxxl,
    color:         COLORS.inkInvert,
    letterSpacing: -1,
    lineHeight:    FONT_SIZE.xxxl * 1.1,
  },
});

// ── Skeleton ──────────────────────────────────────────────────────────────────
function SkeletonRow() {
  return (
    <View style={[rowStyles.row, { opacity: 0.5 }]}>
      <View style={[rowStyles.iconWrap, { backgroundColor: COLORS.bgSkeletonA }]} />
      <View style={{ flex: 1, gap: 6 }}>
        <View style={{ height: 14, width: 140, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
        <View style={{ height: 11, width:  80, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={{ alignItems: "flex-end", gap: 4 }}>
        <View style={{ height: 20, width: 80, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
        <View style={{ height: 11, width: 30, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────
export default function AccountsScreen() {
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [showArchived, setShowArchived] = useState(false);

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black, PlayfairDisplay_700Bold,
    DMSans_400Regular, DMSans_500Medium, DMSans_600SemiBold,
  });

  const { data, isLoading, isRefetching, refetch } = useQuery(
    ["accounts-summary", showArchived],
    () => fetchAccountsSummary(showArchived),
    { staleTime: 30_000 }
  );

  const activeAccounts   = (data?.accounts ?? []).filter(a => !a.is_archived);
  const archivedAccounts = (data?.accounts ?? []).filter(a =>  a.is_archived);

  if (!fontsLoaded) return null;

  return (
    <View style={styles.screen}>
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          hitSlop={8}
        >
          <Text style={styles.backText}>← Back</Text>
        </Pressable>
        <Text style={styles.title}>Accounts</Text>
        <Pressable
          style={styles.newBtn}
          onPress={() => router.push("/settings/manage-account/new")}
          accessibilityRole="button"
          accessibilityLabel="Create new account"
        >
          <Text style={styles.newBtnText}>+ New</Text>
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={refetch}
            tintColor={COLORS.inkMuted}
          />
        }
      >
        {/* Net worth strip */}
        {!isLoading && data && (
          <NetWorthStrip
            totalCents={data.total_balance_cents}
            currencySymbol={currencySymbol}
          />
        )}

        {isLoading ? (
          <>
            <SectionHeader label="Active Accounts" />
            {[1,2,3].map(i => <SkeletonRow key={i} />)}
          </>
        ) : (
          <>
            {/* Active accounts */}
            <SectionHeader label={`Active · ${activeAccounts.length}`} />
            {activeAccounts.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyGlyph}>◌</Text>
                <Text style={styles.emptyHeading}>No accounts yet.</Text>
                <Text style={styles.emptyBody}>
                  Add your wallet, bank account,{"\n"}
                  or that credit card you pay off monthly.
                </Text>
                <Pressable
                  style={styles.emptyBtn}
                  onPress={() => router.push("/settings/manage-account/new")}
                >
                  <Text style={styles.emptyBtnText}>Add First Account</Text>
                </Pressable>
              </View>
            ) : (
              activeAccounts.map(acc => (
                <AccountRow
                  key={acc.id}
                  account={acc}
                  currencySymbol={currencySymbol}
                  isArchived={false}
                />
              ))
            )}

            {/* Archived accounts — collapsible section */}
            {archivedAccounts.length > 0 && (
              <>
                <Pressable
                  style={styles.archivedToggle}
                  onPress={() => setShowArchived(s => !s)}
                >
                  <Text style={styles.archivedToggleText}>
                    {showArchived ? "▾" : "▸"} Archived ({archivedAccounts.length})
                  </Text>
                </Pressable>

                {showArchived && archivedAccounts.map(acc => (
                  <AccountRow
                    key={acc.id}
                    account={acc}
                    currencySymbol={currencySymbol}
                    isArchived
                  />
                ))}
              </>
            )}
          </>
        )}

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen:        { flex: 1, backgroundColor: COLORS.bg },
  scrollContent: { flexGrow: 1 },

  header: {
    flexDirection:     "row",
    alignItems:        "center",
    justifyContent:    "space-between",
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.xxl,
    paddingBottom:     SPACE.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.ruleHeavy,
  },
  backBtn:  { paddingVertical: SPACE.xs },
  backText: { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.sand, letterSpacing: 0.2 },
  title:    { fontFamily: "PlayfairDisplay_700Bold", fontSize: FONT_SIZE.xl, color: COLORS.ink },
  newBtn:   { borderWidth: 1, borderColor: COLORS.ink, paddingVertical: 7, paddingHorizontal: SPACE.md, borderRadius: RADIUS.full },
  newBtnText: { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.sm, color: COLORS.ink, letterSpacing: 0.3 },

  archivedToggle: {
    paddingHorizontal: SPACE.lg,
    paddingVertical:   SPACE.md,
    borderTopWidth:    1,
    borderTopColor:    COLORS.rule,
  },
  archivedToggleText: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMuted,
    letterSpacing: 0.3,
  },

  emptyState: { alignItems: "center", paddingTop: SPACE.xxxl, paddingHorizontal: SPACE.xl },
  emptyGlyph: { fontSize: 48, color: COLORS.rule, lineHeight: 56, marginBottom: SPACE.md },
  emptyHeading: { fontFamily: FONTS.displayBold, fontSize: FONT_SIZE.xl, color: COLORS.ink, marginBottom: SPACE.sm, textAlign: "center" },
  emptyBody: { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.base, color: COLORS.inkMid, textAlign: "center", lineHeight: FONT_SIZE.base * 1.65, marginBottom: SPACE.xl },
  emptyBtn: { borderWidth: 1, borderColor: COLORS.ink, paddingVertical: 12, paddingHorizontal: SPACE.xl, borderRadius: RADIUS.full },
  emptyBtnText: { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.ink, letterSpacing: 0.3 },
});
