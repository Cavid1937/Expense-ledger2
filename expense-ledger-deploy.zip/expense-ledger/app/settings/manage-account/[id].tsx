// app/settings/manage-account/[id].tsx
// =============================================================================
// Add / Edit Account screen.
//
// Route:
//   /settings/manage-account/new   → create mode
//   /settings/manage-account/:id   → edit mode (pre-fills from fetched account)
//
// Balance input:
//   Uses the same invisible-input + massive Playfair Display pattern as
//   add-transaction.tsx. The balance is a string in the form ("1250.00"),
//   converted to a decimal float at submit time:
//     parseFloat("1250.00") → 1250.0 (sent as initial_balance to POST)
//     or as adjust_balance to PATCH
//
//   Negative values are allowed (credit cards, loans can have negative balances).
//
// Archive:
//   Soft-archive via PATCH { is_archived: true }.
//   We never hard-delete accounts with historical transactions — the backend
//   enforces this with a 409 if transactions exist. Archiving is the
//   correct lifecycle for accounts you no longer use.
//
// Color picker:
//   A row of preset ink-adjacent colors consistent with our editorial palette.
// =============================================================================

import React, { useEffect, useState, useCallback } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useForm, Controller }          from "react-hook-form";
import { zodResolver }                  from "@hookform/resolvers/zod";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useFonts }                     from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../../src/constants/theme";
import {
  accountSchema,
  type AccountFormValues,
  ACCOUNT_TYPES,
  ACCOUNT_TYPE_LABELS,
  type AccountType,
} from "../../../src/validations/account.schema";
import {
  fetchAccountById,
  createAccount,
  updateAccount,
} from "../../../src/api/accounts.api";
import { useAuthStore } from "../../../src/store/auth.store";

// ── Preset colors ─────────────────────────────────────────────────────────────
const PRESET_COLORS = [
  "#2C2C2C", "#7A6652", "#5C7A6E", "#4A5C7A",
  "#8A6A3A", "#7A5C5C", "#3A6A7A", "#2D6A4F",
];

// ── Type selector ─────────────────────────────────────────────────────────────
function TypeSelector({
  value,
  onChange,
}: {
  value:    AccountType;
  onChange: (v: AccountType) => void;
}) {
  return (
    <View style={typeStyles.grid}>
      {ACCOUNT_TYPES.map((t) => {
        const active = value === t;
        return (
          <Pressable
            key={t}
            onPress={() => onChange(t)}
            style={[typeStyles.pill, active && typeStyles.pillActive]}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
          >
            <Text style={[typeStyles.label, active && typeStyles.labelActive]}>
              {ACCOUNT_TYPE_LABELS[t]}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const typeStyles = StyleSheet.create({
  grid:        { flexDirection: "row", flexWrap: "wrap", gap: SPACE.sm },
  pill:        { paddingVertical: 8, paddingHorizontal: SPACE.md, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.rule, backgroundColor: COLORS.bg },
  pillActive:  { backgroundColor: COLORS.ink, borderColor: COLORS.ink },
  label:       { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.sm, color: COLORS.inkMuted },
  labelActive: { color: COLORS.inkInvert, fontFamily: FONTS.bodySemiBold },
});

// ── Field wrapper ─────────────────────────────────────────────────────────────
function Field({
  label,
  error,
  children,
}: {
  label:    string;
  error?:   string;
  children: React.ReactNode;
}) {
  return (
    <View style={fieldStyles.wrap}>
      <Text style={fieldStyles.label}>{label.toUpperCase()}</Text>
      {children}
      {error && <Text style={fieldStyles.error}>{error}</Text>}
    </View>
  );
}

const fieldStyles = StyleSheet.create({
  wrap:  { marginBottom: SPACE.lg },
  label: { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, letterSpacing: 2, marginBottom: SPACE.sm },
  error: { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.xs, color: COLORS.negative, marginTop: SPACE.xs },
});

// ── Balance sanitiser ─────────────────────────────────────────────────────────
function sanitiseBalance(raw: string): string {
  // Allow digits, one decimal point, and a leading minus for negatives
  let c     = raw.replace(/[^\d.-]/g, "");
  // Allow at most one leading minus
  const neg = c.startsWith("-");
  c = (neg ? "-" : "") + c.replace(/-/g, "");
  const pts = c.split(".");
  if (pts.length > 2) c = pts[0] + "." + pts.slice(1).join("");
  if (pts[1]?.length > 2) c = pts[0] + "." + pts[1].slice(0, 2);
  return c;
}

// ── Skeleton ──────────────────────────────────────────────────────────────────
function ManageSkeleton() {
  return (
    <View style={styles.screen}>
      <View style={styles.topBar}>
        <View style={{ width: 60, height: 16, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={{ alignItems: "center", paddingVertical: SPACE.xl }}>
        <View style={{ width: 200, height: 68, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
      <View style={{ paddingHorizontal: SPACE.lg, gap: SPACE.lg }}>
        {[1,2,3].map(i => (
          <View key={i} style={{ height: 48, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.md }} />
        ))}
      </View>
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────
export default function ManageAccountScreen() {
  const { id }         = useLocalSearchParams<{ id: string }>();
  const isNew          = id === "new";
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [serverError, setServerError] = useState<string | null>(null);

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black, PlayfairDisplay_700Bold,
    DMSans_400Regular, DMSans_500Medium, DMSans_600SemiBold,
  });

  // ── Fetch existing account (edit mode only) ───────────────────────────────
  const { data: account, isLoading } = useQuery(
    ["account", id],
    () => fetchAccountById(id!),
    { enabled: !isNew && !!id, staleTime: 30_000 }
  );

  // ── Form ──────────────────────────────────────────────────────────────────
  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<AccountFormValues>({
    resolver:      zodResolver(accountSchema),
    defaultValues: {
      name:             "",
      type:             "checking",
      balanceInput:     "0.00",
      currency_code:    "USD",
      color:            PRESET_COLORS[0],
      include_in_total: true,
    },
    mode: "onSubmit",
  });

  // Pre-fill form in edit mode
  useEffect(() => {
    if (!account) return;

    // THE KEY CONVERSION: balance_cents → decimal string
    // e.g. 125000 → "1250.00"
    const decimalStr = (account.balance_cents / 100).toFixed(2);

    setValue("name",             account.name,             { shouldDirty: false });
    setValue("type",             account.type as AccountType, { shouldDirty: false });
    setValue("balanceInput",     decimalStr,                { shouldDirty: false });
    setValue("currency_code",    account.currency_code,    { shouldDirty: false });
    setValue("color",            account.color,             { shouldDirty: false });
    setValue("include_in_total", account.include_in_total, { shouldDirty: false });
  }, [account]);

  const watchBalance  = watch("balanceInput");
  const watchColor    = watch("color");
  const watchType     = watch("type");

  // ── Create mutation ────────────────────────────────────────────────────────
  const createMutation = useMutation(
    (values: AccountFormValues) =>
      createAccount({
        name:             values.name.trim(),
        type:             values.type,
        initial_balance:  parseFloat(values.balanceInput || "0"),
        currency_code:    values.currency_code,
        color:            values.color ?? null,
        include_in_total: values.include_in_total,
      }),
    {
      onSuccess: async () => {
        await queryClient.invalidateQueries("accounts-summary");
        router.back();
      },
      onError: (err: any) => {
        setServerError(err?.response?.data?.message ?? "Could not create account.");
      },
    }
  );

  // ── Update mutation ────────────────────────────────────────────────────────
  const updateMutation = useMutation(
    (values: AccountFormValues) =>
      updateAccount(id!, {
        name:             values.name.trim(),
        type:             values.type,
        color:            values.color ?? null,
        include_in_total: values.include_in_total,
        // Only send adjust_balance if balance actually changed
        ...(account && (parseFloat(values.balanceInput) * 100) !== account.balance_cents
          ? { adjust_balance: parseFloat(values.balanceInput) }
          : {}),
      }),
    {
      onSuccess: async () => {
        await Promise.all([
          queryClient.invalidateQueries("accounts-summary"),
          queryClient.invalidateQueries(["account", id]),
        ]);
        router.back();
      },
      onError: (err: any) => {
        setServerError(err?.response?.data?.message ?? "Could not save changes.");
      },
    }
  );

  // ── Archive mutation ───────────────────────────────────────────────────────
  const archiveMutation = useMutation(
    (archive: boolean) => updateAccount(id!, { is_archived: archive }),
    {
      onSuccess: async () => {
        await queryClient.invalidateQueries("accounts-summary");
        router.back();
      },
      onError: (err: any) => {
        Alert.alert("Error", err?.response?.data?.message ?? "Could not archive account.");
      },
    }
  );

  const onSubmit = (values: AccountFormValues) => {
    setServerError(null);
    if (isNew) {
      createMutation.mutate(values);
    } else {
      updateMutation.mutate(values);
    }
  };

  const handleArchive = () => {
    const isCurrentlyArchived = account?.is_archived ?? false;
    Alert.alert(
      isCurrentlyArchived ? "Restore Account" : "Archive Account",
      isCurrentlyArchived
        ? "This account will reappear in your active accounts."
        : "This account will be hidden from your active list. All historical transactions are preserved.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text:    isCurrentlyArchived ? "Restore" : "Archive",
          style:   isCurrentlyArchived ? "default" : "destructive",
          onPress: () => archiveMutation.mutate(!isCurrentlyArchived),
        },
      ]
    );
  };

  const isMutating = createMutation.isLoading || updateMutation.isLoading;
  const displayBalance = watchBalance || "0.00";
  const isNegativeBalance = parseFloat(displayBalance) < 0;
  const balanceColor = isNegativeBalance ? COLORS.negative : COLORS.positive;

  if (isLoading && !isNew || !fontsLoaded) return <ManageSkeleton />;

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Top bar ──────────────────────────────────────────────────── */}
        <View style={styles.topBar}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
            hitSlop={8}
          >
            <Text style={styles.backText}>← Cancel</Text>
          </Pressable>
          <Text style={styles.screenTitle}>
            {isNew ? "New Account" : "Edit Account"}
          </Text>
          <View style={{ width: 72 }} />
        </View>

        {/* ── Hero balance input ────────────────────────────────────────── */}
        <View style={styles.balanceBlock}>
          <Text style={[styles.currencySymbol, { color: balanceColor + "99" }]}>
            {currencySymbol}
          </Text>
          <Controller
            control={control}
            name="balanceInput"
            render={({ field: { onChange, value } }) => (
              <TextInput
                style={[styles.balanceInput, { color: balanceColor }]}
                value={value}
                onChangeText={(raw) => onChange(sanitiseBalance(raw))}
                placeholder="0.00"
                placeholderTextColor={COLORS.rule}
                keyboardType="numbers-and-punctuation"
                returnKeyType="done"
                selectTextOnFocus
                maxLength={14}
                accessibilityLabel="Account balance"
              />
            )}
          />
        </View>
        {errors.balanceInput && (
          <Text style={styles.balanceError}>{errors.balanceInput.message}</Text>
        )}
        {!isNew && (
          <Text style={styles.balanceHint}>
            Changing this will set the balance directly (balance correction).
          </Text>
        )}

        {/* ── Server error ─────────────────────────────────────────────── */}
        {serverError && (
          <Pressable style={styles.serverError} onPress={() => setServerError(null)}>
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </Pressable>
        )}

        <View style={styles.rule} />

        {/* ── Fields ───────────────────────────────────────────────────── */}
        <View style={styles.fields}>

          <Field label="Account Name" error={errors.name?.message}>
            <Controller
              control={control}
              name="name"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextInput
                  style={styles.textInput}
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  placeholder={
                    watchType === "credit_card"
                      ? "e.g., Daily Spending for Low Tops & Fragrances"
                      : watchType === "savings"
                      ? "e.g., Skincare & Wash-Off Gel Fund"
                      : "e.g., Main Checking, Cash Wallet"
                  }
                  placeholderTextColor={COLORS.inkMuted}
                  autoCapitalize="words"
                  returnKeyType="next"
                  autoFocus={isNew}
                />
              )}
            />
          </Field>

          <Field label="Account Type" error={errors.type?.message}>
            <Controller
              control={control}
              name="type"
              render={({ field: { value, onChange } }) => (
                <TypeSelector value={value} onChange={onChange} />
              )}
            />
          </Field>

          <Field label="Color" error={errors.color?.message}>
            <View style={styles.colorRow}>
              {PRESET_COLORS.map((c) => (
                <Pressable
                  key={c}
                  onPress={() => setValue("color", c, { shouldDirty: true })}
                  style={[
                    styles.colorSwatch,
                    { backgroundColor: c },
                    watchColor === c && styles.colorSwatchSelected,
                  ]}
                />
              ))}
            </View>
          </Field>

          <Field label="Currency Code" error={errors.currency_code?.message}>
            <Controller
              control={control}
              name="currency_code"
              render={({ field: { onChange, value } }) => (
                <TextInput
                  style={[styles.textInput, { width: 80 }]}
                  value={value}
                  onChangeText={(v) => onChange(v.toUpperCase())}
                  placeholder="USD"
                  placeholderTextColor={COLORS.inkMuted}
                  autoCapitalize="characters"
                  maxLength={3}
                />
              )}
            />
          </Field>

          {/* Include in net worth total */}
          <View style={styles.switchRow}>
            <View style={styles.switchMeta}>
              <Text style={styles.switchLabel}>Include in net worth</Text>
              <Text style={styles.switchSub}>
                Disable for credit cards or accounts you track separately.
              </Text>
            </View>
            <Controller
              control={control}
              name="include_in_total"
              render={({ field: { value, onChange } }) => (
                <Switch
                  value={value}
                  onValueChange={onChange}
                  trackColor={{ false: COLORS.rule, true: COLORS.sand }}
                  thumbColor={COLORS.bg}
                />
              )}
            />
          </View>
        </View>

        <View style={styles.rule} />

        {/* ── Save ─────────────────────────────────────────────────────── */}
        <Pressable
          style={({ pressed }) => [
            styles.saveBtn,
            pressed                       && styles.saveBtnPressed,
            (isMutating || !isDirty && !isNew) && styles.saveBtnDisabled,
          ]}
          onPress={handleSubmit(onSubmit)}
          disabled={isMutating || (!isDirty && !isNew)}
          accessibilityRole="button"
          accessibilityLabel={isNew ? "Create account" : "Save changes"}
        >
          {isMutating ? (
            <ActivityIndicator size="small" color={COLORS.inkInvert} />
          ) : (
            <Text style={styles.saveBtnText}>
              {isNew ? "Create Account" : "Save Changes"}
            </Text>
          )}
        </Pressable>

        {/* ── Archive / Restore (edit mode only) ───────────────────────── */}
        {!isNew && (
          <Pressable
            style={({ pressed }) => [
              styles.archiveBtn,
              pressed && { opacity: 0.6 },
              archiveMutation.isLoading && { opacity: 0.4 },
            ]}
            onPress={handleArchive}
            disabled={archiveMutation.isLoading}
          >
            {archiveMutation.isLoading
              ? <ActivityIndicator size="small" color={COLORS.inkMuted} />
              : <Text style={styles.archiveBtnText}>
                  {account?.is_archived ? "Restore Account" : "Archive Account"}
                </Text>
            }
          </Pressable>
        )}

        <View style={{ height: SPACE.xl }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { paddingHorizontal: SPACE.lg, paddingBottom: SPACE.xxl },

  topBar: {
    flexDirection:   "row",
    justifyContent:  "space-between",
    alignItems:      "center",
    paddingTop:      SPACE.xxl,
    paddingBottom:   SPACE.lg,
  },
  backBtn:      { paddingVertical: SPACE.xs },
  backText:     { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.base, color: COLORS.sand, letterSpacing: 0.2 },
  screenTitle:  { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.base, color: COLORS.inkMid, letterSpacing: 0.3 },

  balanceBlock: {
    flexDirection:   "row",
    alignItems:      "flex-end",
    justifyContent:  "center",
    paddingVertical: SPACE.xl,
    gap:             SPACE.xs,
  },
  currencySymbol: {
    fontFamily:   FONTS.displayBold,
    fontSize:     FONT_SIZE.xxxl,
    lineHeight:   FONT_SIZE.xxxl * 1.1,
    paddingBottom: 4,
  },
  balanceInput: {
    fontFamily:         "PlayfairDisplay_900Black",
    fontSize:           72,
    lineHeight:         72,
    letterSpacing:      -2,
    minWidth:           60,
    maxWidth:           240,
    textAlign:          "center",
    padding:            0,
    margin:             0,
    includeFontPadding: false,
  },
  balanceError: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.sm,
    color:        COLORS.negative,
    textAlign:    "center",
    marginTop:    -SPACE.md,
    marginBottom: SPACE.sm,
  },
  balanceHint: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.xs,
    color:        COLORS.inkMuted,
    textAlign:    "center",
    fontStyle:    "italic",
    marginTop:    -SPACE.sm,
    marginBottom: SPACE.sm,
  },

  serverError: {
    backgroundColor: "rgba(193,18,31,0.08)",
    borderWidth: 1, borderColor: COLORS.negative,
    borderRadius: RADIUS.md, padding: SPACE.md, marginBottom: SPACE.md,
  },
  serverErrorText: { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.sm, color: COLORS.negative, lineHeight: 18 },

  rule:   { height: 1, backgroundColor: COLORS.rule, marginVertical: SPACE.md },
  fields: { gap: 0 },

  textInput: {
    width:             "100%",
    backgroundColor:   COLORS.bgCard,
    borderWidth:       1,
    borderColor:       COLORS.rule,
    borderRadius:      RADIUS.md,
    paddingHorizontal: SPACE.md,
    paddingVertical:   13,
    fontFamily:        FONTS.bodyRegular,
    fontSize:          FONT_SIZE.base,
    color:             COLORS.ink,
  },

  colorRow:           { flexDirection: "row", flexWrap: "wrap", gap: SPACE.sm },
  colorSwatch:        { width: 32, height: 32, borderRadius: 16 },
  colorSwatchSelected:{ borderWidth: 2.5, borderColor: COLORS.ink },

  switchRow: {
    flexDirection:   "row",
    alignItems:      "center",
    gap:             SPACE.md,
    paddingVertical: SPACE.sm,
    marginBottom:    SPACE.md,
  },
  switchMeta: { flex: 1 },
  switchLabel: { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.base, color: COLORS.ink, marginBottom: 3 },
  switchSub:   { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, lineHeight: FONT_SIZE.xs * 1.6 },

  saveBtn: {
    backgroundColor: COLORS.ink,
    borderRadius:    RADIUS.full,
    paddingVertical: 17,
    alignItems:      "center",
    justifyContent:  "center",
    minHeight:       56,
    shadowColor:     "#8A7A5A",
    shadowOffset:    { width: 0, height: 5 },
    shadowOpacity:   0.18,
    shadowRadius:    12,
    elevation:       6,
    marginBottom:    SPACE.md,
  },
  saveBtnPressed:  { opacity: 0.82, transform: [{ scale: 0.985 }] },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText:     { fontFamily: FONTS.bodySemiBold, fontSize: FONT_SIZE.md, color: COLORS.inkInvert, letterSpacing: 0.4 },

  archiveBtn: {
    borderWidth:     1,
    borderColor:     COLORS.rule,
    borderRadius:    RADIUS.full,
    paddingVertical: 13,
    alignItems:      "center",
    justifyContent:  "center",
    minHeight:       48,
  },
  archiveBtnText: { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.base, color: COLORS.inkMid, letterSpacing: 0.3 },
});
