// app/_layout.tsx
// =============================================================================
// Root layout — final version with push notification integration.
//
// DIFF from previous version:
//   + setupPushNotifications() called after user is authenticated
//   + registerPushToken() mutation syncs the token to the backend
//   + Notification response listener deep-links to /(tabs)/budgets on tap
//   + deregisterPushToken() called during logout (via auth store subscription)
//   + clearBadge() clears the badge count once the app is open
//
// Notification setup lifecycle:
//   App launch
//     → hydrate() checks SecureStore for refresh token
//     → isAuthenticated = true
//     → useEffect fires: setupPushNotifications()
//         → Permission dialog (if not yet granted)
//         → getExpoPushTokenAsync() → token string
//         → registerPushToken(token) → POST /users/push-token
//     → Notification response listener registered
//
// Why set up notifications in the root layout?
//   The notification response listener must be registered once, at the
//   root of the app, before any screens render. If registered inside a
//   specific screen (e.g., the Budgets tab), it would be unregistered
//   whenever the user navigates away — incoming taps on notifications
//   while on a different screen would be silently dropped.
// =============================================================================

import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  View,
  StatusBar,
  AppState,
  type AppStateStatus,
} from "react-native";
import { Redirect, Slot, SplashScreen, router } from "expo-router";
import { QueryClient, QueryClientProvider }       from "react-query";
import * as Notifications                         from "expo-notifications";

import { useAuthStore }               from "../src/store/auth.store";
import { COLORS }                     from "../src/constants/theme";
import {
  setupPushNotifications,
  getNavigationTargetFromNotification,
  clearBadge,
} from "../src/utils/notifications";
import { registerPushToken }          from "../src/api/user.api";

SplashScreen.preventAutoHideAsync();

// ── React Query client ────────────────────────────────────────────────────────
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry:                1,
      staleTime:            15_000,
      refetchOnWindowFocus: false,
    },
  },
});

// ── Root layout ───────────────────────────────────────────────────────────────
export default function RootLayout() {
  const isHydrated      = useAuthStore((state) => state.isHydrated);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const hydrate         = useAuthStore((state) => state.hydrate);

  // Refs for notification listeners — must be cleaned up on unmount
  const notificationListener = useRef<Notifications.Subscription>();
  const responseListener     = useRef<Notifications.Subscription>();

  // ── Hydration ──────────────────────────────────────────────────────────────
  useEffect(() => {
    hydrate();
  }, []);

  useEffect(() => {
    if (isHydrated) SplashScreen.hideAsync();
  }, [isHydrated]);

  // ── Push notification setup ────────────────────────────────────────────────
  // Only runs when the user is authenticated — we don't ask for notification
  // permission before the user has logged in.
  useEffect(() => {
    if (!isAuthenticated) return;

    let mounted = true;

    async function initNotifications() {
      // ── 1. Request permission + get token ─────────────────────────────────
      const result = await setupPushNotifications();

      if (!mounted) return;

      if (result.success) {
        // ── 2. Sync token to backend ─────────────────────────────────────────
        // Wrapped in try/catch so a failed token sync doesn't crash the app.
        // The user can still use the app — they just won't get push alerts
        // until the token is successfully synced (it will be retried on
        // next app launch).
        try {
          await registerPushToken(result.token);
          console.log("[layout] Push token synced to backend");
        } catch (err) {
          console.warn("[layout] Failed to sync push token:", err);
        }
      } else {
        // Log the reason but don't block the user from using the app
        console.log(`[layout] Push setup skipped: ${result.reason} — ${result.message}`);
      }

      // ── 3. Clear badge count when app comes to foreground ─────────────────
      // This prevents stale badge numbers from persisting after the user
      // opens the app to check their budgets.
      await clearBadge();
    }

    initNotifications();

    // ── 4. Foreground notification listener ───────────────────────────────────
    // Fires when a notification arrives while the app is in the foreground.
    // The setNotificationHandler (in notifications.ts) controls display behaviour.
    // Here we just log for debugging — add custom in-app toast UI here if desired.
    notificationListener.current = Notifications.addNotificationReceivedListener(
      (notification) => {
        console.log("[layout] Foreground notification received:", notification.request.content.title);

        // Invalidate budget progress so the Budgets tab refreshes when the user
        // navigates to it — the data behind the alert is now stale
        queryClient.invalidateQueries("budget-progress");
      }
    );

    // ── 5. Notification tap (response) listener ────────────────────────────────
    // Fires when the user TAPS a notification (from any app state: background,
    // killed, or foreground).
    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        const notification = response.notification;
        const content      = notification.request.content;

        console.log(
          "[layout] Notification tapped:",
          content.title,
          "| data:", JSON.stringify(content.data)
        );

        // Determine the navigation target from the notification payload
        const target = getNavigationTargetFromNotification(notification);

        if (target) {
          // Small delay to ensure the navigator is mounted before pushing.
          // Without this, navigating immediately after cold launch can fail
          // because the tab navigator hasn't registered its routes yet.
          setTimeout(() => {
            try {
              router.push(target as any);
            } catch (err) {
              console.warn("[layout] Navigation from notification failed:", err);
            }
          }, 300);
        }

        // Clear the badge after the user taps a notification
        clearBadge();
      }
    );

    return () => {
      mounted = false;
      notificationListener.current?.remove();
      responseListener.current?.remove();
    };
  }, [isAuthenticated]);

  // ── AppState change: clear badge when app comes to foreground ─────────────
  useEffect(() => {
    if (!isAuthenticated) return;

    const subscription = AppState.addEventListener(
      "change",
      (nextState: AppStateStatus) => {
        if (nextState === "active") {
          clearBadge();
        }
      }
    );

    return () => subscription.remove();
  }, [isAuthenticated]);

  // ── Loading screen ─────────────────────────────────────────────────────────
  if (!isHydrated) {
    return (
      <View style={styles.loading}>
        <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />
        <ActivityIndicator size="large" color={COLORS.sand} />
      </View>
    );
  }

  // ── Auth guard ─────────────────────────────────────────────────────────────
  return (
    <QueryClientProvider client={queryClient}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />
      {!isAuthenticated
        ? <Redirect href="/(auth)/login" />
        : <Redirect href="/(tabs)/dashboard" />
      }
      <Slot />
    </QueryClientProvider>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex:            1,
    backgroundColor: COLORS.bg,
    alignItems:      "center",
    justifyContent:  "center",
  },
});
