// app/(tabs)/ledger.tsx
// =============================================================================
// Ledger screen — full transaction history.
//
// Performance:
//   @shopify/flash-list replaces FlatList. FlashList recycles cell components
//   via a pool, keeping memory flat and scroll at 60fps regardless of list
//   length. getItemType() is critical — it maintains separate recycler pools
//   for headers and items, preventing layout corruption.
//
// Data:
//   useInfiniteQuery manages cursor-based pagination:
//     - First page loads on mount
//     - Subsequent pages load when the user scrolls near the bottom (40%)
//     - Search/filter changes reset back to page 1 via queryKey change
//
// Search:
//   Input is debounced 350ms before the queryKey updates, preventing an API
//   call on every keystroke while the user is still typing.
//
// Layout:
//   "Ledger" header → borderless search → filter pills → FlashList
// =============================================================================

import React, { useCallback, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { FlashList }        from "@shopify/flash-list";
import { useInfiniteQuery } from "react-query";
import { router }           from "expo-router";
import { useFonts }         from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";
import { LedgerItem, LedgerDateHeader }  from "../../src/components/LedgerItem";
import { QuickAddFAB }                   from "../../src/components/QuickAddFAB";
import { useAuthStore }                  from "../../src/store/auth.store";
import { fetchTransactionsPage }         from "../../src/api/transactions.api";
import { groupTransactionPages, type LedgerRow } from "../../src/utils/grouping";

// ── Debounce hook ─────────────────────────────────────────────────────────────
function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState<T>(value);
  const timer = useRef<ReturnType<typeof setTimeout>>();
  React.useEffect(() => {
    timer.current = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer.current);
  }, [value, delay]);
  return debounced;
}

type TypeFilter = "" | "expense" | "income";

const FILTER_OPTIONS: { label: string; value: TypeFilter }[] = [
  { label: "All",      value: ""        },
  { label: "Expenses", value: "expense" },
  { label: "Income",   value: "income"  },
];

function FilterPills({ value, onChange }: { value: TypeFilter; onChange: (v: TypeFilter) => void }) {
  return (
    <View style={pillStyles.row}>
      {FILTER_OPTIONS.map((opt) => {
        const active = value === opt.value;
        return (
          <Pressable key={opt.value} onPress={() => onChange(opt.value)}
            style={[pillStyles.pill, active && pillStyles.pillActive]}
            accessibilityRole="button" accessibilityState={{ selected: active }}
          >
            <Text style={[pillStyles.label, active && pillStyles.labelActive]}>{opt.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const pillStyles = StyleSheet.create({
  row:         { flexDirection: "row", paddingHorizontal: SPACE.lg, paddingVertical: SPACE.sm, gap: SPACE.sm },
  pill:        { paddingVertical: 6, paddingHorizontal: SPACE.md, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.rule, backgroundColor: COLORS.bg },
  pillActive:  { backgroundColor: COLORS.ink, borderColor: COLORS.ink },
  label:       { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, letterSpacing: 0.5 },
  labelActive: { color: COLORS.inkInvert, fontFamily: FONTS.bodySemiBold },
});

function EmptyState({ query }: { query: string }) {
  return (
    <View style={emptyStyles.container}>
      <Text style={emptyStyles.glyph}>◌</Text>
      {query ? (
        <>
          <Text style={emptyStyles.heading}>No results for "{query}"</Text>
          <Text style={emptyStyles.body}>Try a category name, note, or amount.</Text>
        </>
      ) : (
        <>
          <Text style={emptyStyles.heading}>Nothing here yet.</Text>
          <Text style={emptyStyles.body}>Your transactions will appear here{"\n"}once you've logged a few entries.</Text>
        </>
      )}
    </View>
  );
}

const emptyStyles = StyleSheet.create({
  container: { alignItems: "center", paddingTop: SPACE.xxxl, paddingHorizontal: SPACE.xl },
  glyph:     { fontSize: 52, color: COLORS.rule, marginBottom: SPACE.lg, lineHeight: 60 },
  heading:   { fontFamily: FONTS.displayBold, fontSize: FONT_SIZE.xl, color: COLORS.ink, marginBottom: SPACE.sm, textAlign: "center" },
  body:      { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.base, color: COLORS.inkMid, textAlign: "center", lineHeight: FONT_SIZE.base * 1.65 },
});

// ── Main screen ───────────────────────────────────────────────────────────────
export default function LedgerScreen() {
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [searchInput, setSearchInput] = useState("");
  const [typeFilter,  setTypeFilter]  = useState<TypeFilter>("");
  const debouncedSearch               = useDebounce(searchInput, 350);

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black, PlayfairDisplay_700Bold,
    DMSans_400Regular, DMSans_500Medium, DMSans_600SemiBold,
  });

  // ── Infinite query ─────────────────────────────────────────────────────────
  const {
    data, isLoading, isFetchingNextPage,
    hasNextPage, fetchNextPage, refetch, isRefetching,
  } = useInfiniteQuery(
    ["transactions", debouncedSearch, typeFilter],
    ({ pageParam = 1 }) => fetchTransactionsPage({
      page:   pageParam,
      search: debouncedSearch || undefined,
      type:   typeFilter      || undefined,
    }),
    {
      getNextPageParam: (last) => last.pagination.has_more ? last.pagination.page + 1 : undefined,
      staleTime: 15_000,
    }
  );

  // ── Group pages into flat header+item array ────────────────────────────────
  const rows: LedgerRow[] = useMemo(() => {
    if (!data?.pages) return [];
    return groupTransactionPages(data.pages);
  }, [data]);

  const totalCount = data?.pages[0]?.pagination.total ?? 0;

  const handleEndReached = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage) fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // ── renderItem — stable reference for FlashList ────────────────────────────
  const renderItem = useCallback(({ item }: { item: LedgerRow }) => {
    if (item.kind === "header") {
      return <LedgerDateHeader item={item} currencySymbol={currencySymbol} />;
    }
    return (
      <LedgerItem
        transaction={item.transaction}
        currencySymbol={currencySymbol}
        onPress={(txn) => console.log("tapped:", txn.id)}
      />
    );
  }, [currencySymbol]);

  // ── getItemType: separate recycler pools per item shape ───────────────────
  const getItemType = useCallback((item: LedgerRow) => item.kind, []);

  const ListFooter = useCallback(() =>
    isFetchingNextPage ? (
      <View style={styles.footerLoader}>
        <ActivityIndicator size="small" color={COLORS.inkMuted} />
        <Text style={styles.footerText}>Loading more…</Text>
      </View>
    ) : <View style={{ height: 100 }} />
  , [isFetchingNextPage]);

  // ── Skeleton loader ────────────────────────────────────────────────────────
  if (isLoading || !fontsLoaded) {
    return (
      <View style={styles.screen}>
        <View style={styles.header}>
          <View style={styles.skeletonTitle} />
          <View style={styles.skeletonSubtitle} />
        </View>
        <View style={styles.skeletonSearchBar} />
        {Array.from({ length: 7 }).map((_, i) => (
          <View key={i} style={styles.skeletonRow}>
            <View style={styles.skeletonIcon} />
            <View style={{ flex: 1, gap: 6 }}>
              <View style={[styles.skeletonLine, { width: 110 + (i % 3) * 20 }]} />
              <View style={[styles.skeletonLine, { width: 70 }]} />
            </View>
            <View style={[styles.skeletonLine, { width: 60 }]} />
          </View>
        ))}
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <View style={styles.header}>
        <Text style={styles.title}>Ledger</Text>
        {totalCount > 0 && (
          <Text style={styles.subtitle}>
            {totalCount.toLocaleString()} transaction{totalCount !== 1 ? "s" : ""}
          </Text>
        )}
      </View>

      {/* ── Search ──────────────────────────────────────────────────────── */}
      <View style={styles.searchRow}>
        <Text style={styles.searchIcon}>⌕</Text>
        <TextInput
          style={styles.searchInput}
          value={searchInput}
          onChangeText={setSearchInput}
          placeholder='Search — "Bvlgari Tygar", "leather jacket"…'
          placeholderTextColor={COLORS.inkMuted}
          returnKeyType="search"
          autoCapitalize="none"
          autoCorrect={false}
        />
        {searchInput.length > 0 && (
          <Pressable onPress={() => setSearchInput("")} hitSlop={8} accessibilityLabel="Clear search">
            <Text style={styles.clearBtn}>✕</Text>
          </Pressable>
        )}
      </View>

      {/* ── Filter pills ─────────────────────────────────────────────────── */}
      <FilterPills value={typeFilter} onChange={setTypeFilter} />
      <View style={styles.rule} />

      {/* ── List ─────────────────────────────────────────────────────────── */}
      {rows.length === 0 ? (
        <EmptyState query={debouncedSearch} />
      ) : (
        <FlashList
          data={rows}
          renderItem={renderItem}
          getItemType={getItemType}
          estimatedItemSize={62}
          keyExtractor={(item) =>
            item.kind === "header" ? `hdr-${item.date}` : `txn-${item.transaction.id}`
          }
          onEndReached={handleEndReached}
          onEndReachedThreshold={0.4}
          ListFooterComponent={ListFooter}
          refreshing={isRefetching}
          onRefresh={refetch}
          drawDistance={800}
          overrideItemLayout={(layout, item) => {
            layout.size = item.kind === "header" ? 52 : 68;
          }}
        />
      )}

      {/* ── FAB ──────────────────────────────────────────────────────────── */}
      <QuickAddFAB onPress={() => router.push("/(tabs)/add-transaction")} />
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },

  header: {
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.xxl,
    paddingBottom:     SPACE.md,
  },
  title: {
    fontFamily:    "PlayfairDisplay_900Black",
    fontSize:      FONT_SIZE.xxxl,
    color:         COLORS.ink,
    lineHeight:    FONT_SIZE.xxxl * 1.1,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontFamily:    FONTS.bodyRegular,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMuted,
    marginTop:     4,
    letterSpacing: 0.3,
  },

  searchRow: {
    flexDirection:     "row",
    alignItems:        "center",
    paddingHorizontal: SPACE.lg,
    paddingVertical:   SPACE.sm,
    gap:               SPACE.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.rule,
  },
  searchIcon:  { fontSize: 20, color: COLORS.inkMuted, lineHeight: 24 },
  searchInput: {
    flex:            1,
    fontFamily:      FONTS.bodyRegular,
    fontSize:        FONT_SIZE.base,
    color:           COLORS.ink,
    paddingVertical: SPACE.sm,
  },
  clearBtn: { fontFamily: FONTS.bodyMedium, fontSize: FONT_SIZE.sm, color: COLORS.inkMuted },

  rule:        { height: 1, backgroundColor: COLORS.rule },

  footerLoader: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: SPACE.sm, paddingVertical: SPACE.lg },
  footerText:   { fontFamily: FONTS.bodyRegular, fontSize: FONT_SIZE.sm, color: COLORS.inkMuted, letterSpacing: 0.3 },

  // Skeletons
  skeletonTitle:     { height: 36, width: 150, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm, marginBottom: SPACE.xs },
  skeletonSubtitle:  { height: 14, width:  80, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm },
  skeletonSearchBar: { height: 48, marginHorizontal: SPACE.lg, marginVertical: SPACE.sm, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.md },
  skeletonRow:       { flexDirection: "row", alignItems: "center", paddingHorizontal: SPACE.lg, paddingVertical: SPACE.md, gap: SPACE.md },
  skeletonIcon:      { width: 40, height: 40, borderRadius: RADIUS.md, backgroundColor: COLORS.bgSkeletonA },
  skeletonLine:      { height: 13, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm },
});
