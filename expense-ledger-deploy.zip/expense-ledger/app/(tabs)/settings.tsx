// app/(tabs)/settings.tsx
// =============================================================================
// Settings screen — final version with real CSV export wired.
//
// DIFF from previous version:
//   + import useExportCsv hook
//   + "Export to CSV" row shows "Exporting…" loading state during export
//   + subtitle dynamically shows last export date (future: store in MMKV)
// =============================================================================

import React, { useState } from "react";
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  ActivityIndicator,
} from "react-native";
import { router }       from "expo-router";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { useFonts }     from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS, TAB_BAR_HEIGHT } from "../../src/constants/theme";
import { SettingsRow, SettingsSection } from "../../src/components/SettingsRow";
import { useAuthStore }   from "../../src/store/auth.store";
import { useExportCsv }   from "../../src/hooks/useExportCsv";   // ← NEW
import apiClient          from "../../src/api/client";
import {
  fetchCategories,
  createCategory,
  deleteCategory,
  type Category,
} from "../../src/api/categories.api";

// ── Preset data ───────────────────────────────────────────────────────────────
const PRESET_COLORS = ["#2C2C2C","#7A6652","#5C7A6E","#7A5C5C","#4A5C7A","#8A6A3A","#3A6A7A","#2D6A4F","#7A4A7A","#6A7A3A"];
const PRESET_ICONS  = ["👕","🧴","💊","📚","🍽️","🚗","🎬","💰","🏠","✈️","📱","🎵","⚡","🏋️","🫧","💼"];

// ── New Category Modal ────────────────────────────────────────────────────────
function NewCategoryModal({ visible, onClose, onCreated }: {
  visible: boolean; onClose: () => void; onCreated: (cat: Category) => void;
}) {
  const queryClient = useQueryClient();
  const [name, setName]   = useState("");
  const [icon, setIcon]   = useState("📦");
  const [color,setColor]  = useState(PRESET_COLORS[0]);
  const [type, setType]   = useState<"expense"|"income">("expense");
  const [nameErr,setNameErr] = useState("");

  const mutation = useMutation(createCategory, {
    onSuccess: (cat) => {
      queryClient.invalidateQueries("categories");
      onCreated(cat);
      setName(""); setIcon("📦"); setColor(PRESET_COLORS[0]); setType("expense");
      onClose();
    },
    onError: (err: any) => setNameErr(err?.response?.data?.message ?? "Could not create category."),
  });

  const submit = () => {
    if (!name.trim()) { setNameErr("Please enter a name."); return; }
    setNameErr("");
    mutation.mutate({ name: name.trim(), icon, color, type });
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={m.overlay}>
        <Pressable style={StyleSheet.absoluteFillObject} onPress={onClose} />
        <View style={m.sheet}>
          <View style={m.handle} />
          <Text style={m.title}>New Category</Text>
          <Text style={m.subtitle}>Add "Oversized Fits", "Fragrance Rotation", etc.</Text>
          <View style={m.field}>
            <Text style={m.lbl}>NAME</Text>
            <TextInput style={[m.input, nameErr && m.inputErr]} value={name} onChangeText={v=>{setName(v);setNameErr("");}} placeholder="e.g., Oversized Fits" placeholderTextColor={COLORS.inkMuted} autoFocus returnKeyType="done" />
            {nameErr ? <Text style={m.err}>{nameErr}</Text> : null}
          </View>
          <View style={m.field}>
            <Text style={m.lbl}>TYPE</Text>
            <View style={m.row}>
              {(["expense","income"] as const).map(t=>(
                <Pressable key={t} onPress={()=>setType(t)} style={[m.pill, type===t && m.pillA]}>
                  <Text style={[m.pillT, type===t && m.pillTA]}>{t.charAt(0).toUpperCase()+t.slice(1)}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={m.field}>
            <Text style={m.lbl}>ICON</Text>
            <View style={m.grid}>
              {PRESET_ICONS.map(ic=>(
                <Pressable key={ic} onPress={()=>setIcon(ic)} style={[m.iconOpt, ic===icon && m.iconSel]}>
                  <Text style={{fontSize:20}}>{ic}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={m.field}>
            <Text style={m.lbl}>COLOR</Text>
            <View style={m.row}>
              {PRESET_COLORS.map(c=>(
                <Pressable key={c} onPress={()=>setColor(c)} style={[m.swatch,{backgroundColor:c},c===color&&m.swatchSel]} />
              ))}
            </View>
          </View>
          <Pressable style={[m.btn,mutation.isLoading&&{opacity:0.6}]} onPress={submit} disabled={mutation.isLoading}>
            {mutation.isLoading?<ActivityIndicator size="small" color={COLORS.inkInvert}/>:<Text style={m.btnT}>Create Category</Text>}
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const m = StyleSheet.create({
  overlay:  { flex:1, justifyContent:"flex-end", backgroundColor:"rgba(17,17,16,0.5)" },
  sheet:    { backgroundColor:COLORS.bg, borderTopLeftRadius:RADIUS.xl, borderTopRightRadius:RADIUS.xl, borderTopWidth:1.5, borderTopColor:COLORS.ink, padding:SPACE.lg, paddingBottom:40 },
  handle:   { width:40, height:3, backgroundColor:COLORS.rule, borderRadius:RADIUS.full, alignSelf:"center", marginBottom:SPACE.lg },
  title:    { fontFamily:FONTS.displayBold, fontSize:FONT_SIZE.xl, color:COLORS.ink, marginBottom:4 },
  subtitle: { fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.sm, color:COLORS.inkMuted, marginBottom:SPACE.lg, lineHeight:FONT_SIZE.sm*1.55 },
  field:    { marginBottom:SPACE.md },
  lbl:      { fontFamily:FONTS.bodyMedium, fontSize:FONT_SIZE.xs, color:COLORS.inkMuted, letterSpacing:2, textTransform:"uppercase", marginBottom:SPACE.sm },
  input:    { backgroundColor:COLORS.bgCard, borderWidth:1, borderColor:COLORS.rule, borderRadius:RADIUS.md, paddingHorizontal:SPACE.md, paddingVertical:12, fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.base, color:COLORS.ink },
  inputErr: { borderColor:COLORS.negative },
  err:      { fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.xs, color:COLORS.negative, marginTop:4 },
  row:      { flexDirection:"row", flexWrap:"wrap", gap:SPACE.sm },
  pill:     { paddingVertical:8, paddingHorizontal:SPACE.lg, borderRadius:RADIUS.full, borderWidth:1, borderColor:COLORS.rule },
  pillA:    { backgroundColor:COLORS.ink, borderColor:COLORS.ink },
  pillT:    { fontFamily:FONTS.bodyMedium, fontSize:FONT_SIZE.sm, color:COLORS.inkMuted },
  pillTA:   { color:COLORS.inkInvert },
  grid:     { flexDirection:"row", flexWrap:"wrap", gap:SPACE.sm },
  iconOpt:  { width:42, height:42, borderRadius:RADIUS.md, borderWidth:1, borderColor:COLORS.rule, alignItems:"center", justifyContent:"center" },
  iconSel:  { borderColor:COLORS.ink, borderWidth:2 },
  swatch:   { width:28, height:28, borderRadius:14 },
  swatchSel:{ borderWidth:2.5, borderColor:COLORS.ink },
  btn:      { backgroundColor:COLORS.ink, borderRadius:RADIUS.full, paddingVertical:15, alignItems:"center", marginTop:SPACE.sm, minHeight:52 },
  btnT:     { fontFamily:FONTS.bodySemiBold, fontSize:FONT_SIZE.base, color:COLORS.inkInvert, letterSpacing:0.3 },
});

// ── Custom Category Row ───────────────────────────────────────────────────────
function CustomCategoryRow({ cat }: { cat: Category }) {
  const queryClient = useQueryClient();
  const del = useMutation(()=>deleteCategory(cat.id),{
    onSuccess:()=>queryClient.invalidateQueries("categories"),
  });
  const confirmDel = () => Alert.alert(`Delete "${cat.name}"?`,"Transactions will become uncategorised.",[
    {text:"Cancel",style:"cancel"},
    {text:"Delete",style:"destructive",onPress:()=>del.mutate()},
  ]);
  return (
    <View style={cc.row}>
      <View style={[cc.icon,{backgroundColor:cat.color+"22"}]}>
        <Text style={{fontSize:16}}>{cat.icon}</Text>
      </View>
      <Text style={cc.name} numberOfLines={1}>{cat.name}</Text>
      <Pressable onPress={confirmDel} hitSlop={8}>
        {del.isLoading?<ActivityIndicator size="small" color={COLORS.negative}/>:<Text style={cc.del}>⊖</Text>}
      </Pressable>
    </View>
  );
}
const cc = StyleSheet.create({
  row:  {flexDirection:"row",alignItems:"center",paddingVertical:SPACE.sm,paddingHorizontal:SPACE.lg,gap:SPACE.md,borderBottomWidth:1,borderBottomColor:COLORS.rule,minHeight:52},
  icon: {width:32,height:32,borderRadius:RADIUS.md,alignItems:"center",justifyContent:"center"},
  name: {flex:1,fontFamily:FONTS.bodyMedium,fontSize:FONT_SIZE.base,color:COLORS.ink},
  del:  {fontSize:18,color:COLORS.inkMuted},
});

// ── Main screen ───────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const { user, logout }            = useAuthStore();
  const queryClient                 = useQueryClient();
  const [showNewCat, setShowNewCat] = useState(false);

  // ── CSV export hook ─────────────────────────────────────────────────────────
  const { exportCsv, isExporting } = useExportCsv();  // ← NEW

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black, PlayfairDisplay_700Bold,
    DMSans_400Regular, DMSans_500Medium, DMSans_600SemiBold,
  });

  const { data: categories = [] } = useQuery("categories", fetchCategories, { staleTime: 60_000 });
  const customCats = categories.filter(c => c.is_custom && !c.is_archived);

  const handleLogout = () => Alert.alert("Log Out","Are you sure?",[
    {text:"Cancel",style:"cancel"},
    {text:"Log Out",style:"destructive",onPress:async()=>{
      try{await apiClient.post("/auth/logout");}catch{}
      await logout();
    }},
  ]);

  if (!fontsLoaded) return null;

  const displayName = user?.full_name ?? user?.email?.split("@")[0] ?? "—";

  return (
    <View style={s.screen}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        <View style={s.header}>
          <Text style={s.title}>Settings</Text>
        </View>
        <View style={s.topRule} />

        {/* Profile */}
        <SettingsSection title="Profile">
          <View style={s.profileBlock}>
            <View style={s.avatar}>
              <Text style={s.avatarI}>{(displayName[0]??"?").toUpperCase()}</Text>
            </View>
            <View style={{flex:1,gap:3}}>
              <Text style={s.pName} numberOfLines={1}>{displayName}</Text>
              <Text style={s.pEmail} numberOfLines={1}>{user?.email??"—"}</Text>
            </View>
          </View>
          <SettingsRow title="Currency" value={`${user?.currency_symbol??"$"} · ${user?.currency_code??"USD"}`} variant="value" showChevron={false} icon="💱" />
          <SettingsRow title="Timezone"  value={user?.timezone??"UTC"} variant="value" showChevron={false} icon="🕐" showBorder={false} />
        </SettingsSection>

        {/* Finance */}
        <SettingsSection title="Finance">
          <SettingsRow title="Accounts" subtitle="Wallets, cards, and cash" icon="🏦" onPress={() => router.push("/settings/accounts")} />
          <SettingsRow title="Budgets"  subtitle="Monthly spending limits"  icon="◈"  onPress={() => router.push("/(tabs)/budgets")} showBorder={false} />
        </SettingsSection>

        {/* Categories */}
        <SettingsSection title="Categories">
          {customCats.length === 0
            ? <View style={s.emptyCats}><Text style={s.emptyCatsT}>No custom categories yet.{"\n"}Add "Oversized Fits" or "Fragrance Rotation."</Text></View>
            : customCats.map(cat => <CustomCategoryRow key={cat.id} cat={cat} />)
          }
          <SettingsRow title="Add Custom Category" icon="+" iconColor={COLORS.sand} onPress={()=>setShowNewCat(true)} showChevron={false} showBorder={false} />
        </SettingsSection>

        {/* Data — WIRED export */}
        <SettingsSection title="Data">
          {/*
            The export row has three states:
              - Normal:     "Export to CSV" with download icon
              - Exporting:  "Exporting…"   with ActivityIndicator
              - Both states: Pressable is disabled during export to prevent double-tap
          */}
          <Pressable
            onPress={() => exportCsv()}
            disabled={isExporting}
            style={({ pressed }) => [
              s.exportRow,
              pressed && { opacity: 0.6 },
              isExporting && { opacity: 0.75 },
            ]}
            accessibilityRole="button"
            accessibilityLabel={isExporting ? "Exporting data" : "Export to CSV"}
            accessibilityState={{ disabled: isExporting }}
          >
            {/* Icon */}
            <View style={[s.exportIconWrap, { backgroundColor: COLORS.positive + "18" }]}>
              {isExporting
                ? <ActivityIndicator size="small" color={COLORS.positive} />
                : <Text style={s.exportIcon}>↓</Text>
              }
            </View>
            {/* Labels */}
            <View style={s.exportMeta}>
              <Text style={s.exportTitle}>
                {isExporting ? "Exporting…" : "Export to CSV"}
              </Text>
              <Text style={s.exportSub}>
                {isExporting
                  ? "Preparing your ledger, please wait…"
                  : "AirDrop, email, or save to Files"
                }
              </Text>
            </View>
            {/* Chevron (hidden while exporting) */}
            {!isExporting && <Text style={s.exportChevron}>›</Text>}
          </Pressable>

          <SettingsRow title="Privacy Policy" icon="🔒" onPress={()=>{}} showBorder={false} />
        </SettingsSection>

        {/* About */}
        <SettingsSection title="About">
          <SettingsRow title="Version" value="1.0.0" variant="value" showChevron={false} showBorder={false} />
        </SettingsSection>

        {/* Log out */}
        <View style={s.logoutBlock}>
          <Pressable style={({pressed})=>[s.logoutBtn,pressed&&s.logoutP]} onPress={handleLogout} accessibilityRole="button" accessibilityLabel="Log out">
            <Text style={s.logoutT}>Log Out</Text>
          </Pressable>
        </View>

        <View style={{height: TAB_BAR_HEIGHT + SPACE.xl}} />
      </ScrollView>

      <NewCategoryModal visible={showNewCat} onClose={()=>setShowNewCat(false)} onCreated={()=>{}} />
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  screen:  { flex:1, backgroundColor:COLORS.bg },
  scroll:  { flexGrow:1 },
  header:  { paddingHorizontal:SPACE.lg, paddingTop:SPACE.xxl, paddingBottom:SPACE.md },
  title:   { fontFamily:"PlayfairDisplay_900Black", fontSize:FONT_SIZE.xxxl, color:COLORS.ink, letterSpacing:-0.5, lineHeight:FONT_SIZE.xxxl*1.1 },
  topRule: { height:1, backgroundColor:COLORS.ruleHeavy, marginHorizontal:SPACE.lg, marginBottom:SPACE.lg },

  profileBlock: { flexDirection:"row", alignItems:"center", paddingHorizontal:SPACE.lg, paddingVertical:SPACE.md, borderBottomWidth:1, borderBottomColor:COLORS.rule, gap:SPACE.md },
  avatar:       { width:48, height:48, borderRadius:24, backgroundColor:COLORS.sand, alignItems:"center", justifyContent:"center" },
  avatarI:      { fontFamily:FONTS.displayBold, fontSize:FONT_SIZE.lg, color:COLORS.bg },
  pName:        { fontFamily:FONTS.bodySemiBold, fontSize:FONT_SIZE.md, color:COLORS.ink },
  pEmail:       { fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.sm, color:COLORS.inkMuted },

  emptyCats:  { paddingHorizontal:SPACE.lg, paddingVertical:SPACE.md, borderBottomWidth:1, borderBottomColor:COLORS.rule },
  emptyCatsT: { fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.sm, color:COLORS.inkMuted, lineHeight:FONT_SIZE.sm*1.6 },

  // Export row — custom because it has a loading state
  exportRow: {
    flexDirection:     "row",
    alignItems:        "center",
    paddingVertical:   SPACE.md,
    paddingHorizontal: SPACE.lg,
    backgroundColor:   COLORS.bg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.rule,
    gap:               SPACE.md,
    minHeight:         56,
  },
  exportIconWrap: {
    width:           36,
    height:          36,
    borderRadius:    RADIUS.md,
    alignItems:      "center",
    justifyContent:  "center",
    flexShrink:      0,
  },
  exportIcon:    { fontSize:18, color:COLORS.positive },
  exportMeta:    { flex:1 },
  exportTitle:   { fontFamily:FONTS.bodyMedium, fontSize:FONT_SIZE.base, color:COLORS.ink },
  exportSub:     { fontFamily:FONTS.bodyRegular, fontSize:FONT_SIZE.sm, color:COLORS.inkMuted, marginTop:2 },
  exportChevron: { fontFamily:FONTS.bodyBold, fontSize:FONT_SIZE.xl, color:COLORS.rule },

  logoutBlock: { paddingHorizontal:SPACE.lg, paddingVertical:SPACE.xl },
  logoutBtn:   { borderWidth:1.5, borderColor:COLORS.negative, borderRadius:RADIUS.full, paddingVertical:15, alignItems:"center" },
  logoutP:     { backgroundColor:COLORS.negativeBg },
  logoutT:     { fontFamily:FONTS.bodySemiBold, fontSize:FONT_SIZE.base, color:COLORS.negative, letterSpacing:0.3 },
});
