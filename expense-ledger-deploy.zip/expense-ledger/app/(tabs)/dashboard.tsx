// app/(tabs)/dashboard.tsx
// =============================================================================
// Main dashboard screen.
//
// Data:
//   Two parallel React Query queries — accounts summary and recent transactions.
//   They fire concurrently and render independently, so a slow accounts call
//   doesn't block the transaction list from appearing.
//
// Layout (top to bottom):
//   ┌─────────────────────────────────────┐
//   │  Header: greeting + date            │
//   ├─────────────────────────────────────┤
//   │  SummaryCard (full-width, inverted) │
//   ├─────────────────────────────────────┤
//   │  Account pills row (scrollable)     │
//   ├─────────────────────────────────────┤
//   │  "Recent Activity" section header  │
//   │  Transaction rows  (last 5)         │
//   │    — or —                           │
//   │  Empty state                        │
//   └─────────────────────────────────────┘
//   FAB (absolutely positioned, bottom-right)
//
// Typography notes:
//   Section labels use uppercase tracking like print magazine headers.
//   The transaction row amount uses tabular figures for clean alignment.
// =============================================================================

import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useQuery, useQueryClient } from "react-query";
import { router }                   from "expo-router";
import { useFonts }                 from "expo-font";
import {
  PlayfairDisplay_700Bold,
  PlayfairDisplay_900Black,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
  DMSans_700Bold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";
import { SummaryCard }       from "../../src/components/SummaryCard";
import { QuickAddFAB }       from "../../src/components/QuickAddFAB";
import { useAuthStore }      from "../../src/store/auth.store";
import { formatCurrency }    from "../../src/utils/currency";
import { fetchAccountsSummary, type Account } from "../../src/api/accounts.api";
import { fetchRecentTransactions, type Transaction } from "../../src/api/transactions.api";

// ── Transaction row ───────────────────────────────────────────────────────────
function TransactionRow({ txn, currencySymbol }: { txn: Transaction; currencySymbol: string }) {
  const isExpense  = txn.type === "expense";
  const isIncome   = txn.type === "income";
  const amountStr  = formatCurrency(txn.amount_cents, currencySymbol);
  const sign       = isExpense ? "−" : isIncome ? "+" : "⇄";
  const amountColor = isExpense ? COLORS.negative : isIncome ? COLORS.positive : COLORS.neutral;

  const displayDate = new Date(txn.date + "T00:00:00").toLocaleDateString("en-US", {
    month: "short",
    day:   "numeric",
  });

  return (
    <View style={txnStyles.row}>
      {/* Category icon pill */}
      <View style={[txnStyles.iconPill, { backgroundColor: txn.category_color ?? COLORS.bgCard }]}>
        <Text style={txnStyles.iconGlyph}>
          {txn.category_icon ?? "·"}
        </Text>
      </View>

      {/* Description + date */}
      <View style={txnStyles.meta}>
        <Text style={txnStyles.categoryName} numberOfLines={1}>
          {txn.category_name ?? "Uncategorised"}
        </Text>
        <Text style={txnStyles.note} numberOfLines={1}>
          {txn.note ? txn.note : txn.account_name ?? ""}
        </Text>
      </View>

      {/* Amount + date */}
      <View style={txnStyles.right}>
        <Text style={[txnStyles.amount, { color: amountColor }]}>
          {sign}{amountStr}
        </Text>
        <Text style={txnStyles.date}>{displayDate}</Text>
      </View>
    </View>
  );
}

// ── Account pill ──────────────────────────────────────────────────────────────
function AccountPill({ account, currencySymbol }: { account: Account; currencySymbol: string }) {
  return (
    <View style={pillStyles.pill}>
      <View style={[pillStyles.dot, { backgroundColor: account.color ?? COLORS.sand }]} />
      <View>
        <Text style={pillStyles.name} numberOfLines={1}>{account.name}</Text>
        <Text style={pillStyles.balance}>
          {formatCurrency(account.balance_cents, currencySymbol)}
        </Text>
      </View>
    </View>
  );
}

// ── Skeleton row ──────────────────────────────────────────────────────────────
function SkeletonRow() {
  return (
    <View style={[txnStyles.row, { opacity: 0.5 }]}>
      <View style={[txnStyles.iconPill, { backgroundColor: COLORS.bgCard }]} />
      <View style={txnStyles.meta}>
        <View style={{ height: 13, width: 100, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
        <View style={{ height: 11, width: 60,  backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm, marginTop: 5 }} />
      </View>
      <View style={txnStyles.right}>
        <View style={{ height: 13, width: 56,  backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
      </View>
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────
export default function DashboardScreen() {
  const user           = useAuthStore((state) => state.user);
  const queryClient    = useQueryClient();
  const [fabVisible]   = useState(true);
  const currencySymbol = user?.currency_symbol ?? "$";

  // ── Font loading ───────────────────────────────────────────────────────────
  const [fontsLoaded] = useFonts({
    PlayfairDisplay_700Bold,
    PlayfairDisplay_900Black,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_600SemiBold,
    DMSans_700Bold,
  });

  // ── Queries ────────────────────────────────────────────────────────────────
  const accountsQuery = useQuery(
    "accounts-summary",
    fetchAccountsSummary,
    { staleTime: 30_000 }  // Consider fresh for 30s — avoid redundant fetches
  );

  const txnQuery = useQuery(
    "recent-transactions",
    () => fetchRecentTransactions(5),
    { staleTime: 15_000 }
  );

  // ── Pull-to-refresh ────────────────────────────────────────────────────────
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries("accounts-summary"),
      queryClient.invalidateQueries("recent-transactions"),
    ]);
    setRefreshing(false);
  }, [queryClient]);

  if (!fontsLoaded) return null;

  // ── Greeting ───────────────────────────────────────────────────────────────
  const hour         = new Date().getHours();
  const greeting     = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const firstName    = user?.full_name?.split(" ")[0] ?? "there";

  const todayStr = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month:   "long",
    day:     "numeric",
  });

  const transactions = txnQuery.data?.transactions ?? [];
  const hasTransactions = transactions.length > 0;

  return (
    <View style={styles.screen}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={COLORS.inkMid}
          />
        }
      >
        {/* ── Header ──────────────────────────────────────────────────── */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{greeting}, {firstName}.</Text>
            <Text style={styles.todayDate}>{todayStr}</Text>
          </View>
          {/* Notification / avatar placeholder */}
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarInitial}>
              {(user?.full_name?.[0] ?? user?.email?.[0] ?? "?").toUpperCase()}
            </Text>
          </View>
        </View>

        {/* ── Summary card (full-bleed) ────────────────────────────────── */}
        <SummaryCard
          totalBalanceCents={accountsQuery.data?.total_balance_cents}
          currencySymbol={currencySymbol}
          loading={accountsQuery.isLoading}
          error={!!accountsQuery.error}
        />

        {/* ── Account pills ────────────────────────────────────────────── */}
        {accountsQuery.isLoading ? (
          <View style={styles.pillsRow}>
            {[1, 2].map(i => (
              <View key={i} style={[pillStyles.pill, { backgroundColor: COLORS.bgCard, opacity: 0.5 }]}>
                <View style={{ height: 12, width: 80, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm }} />
              </View>
            ))}
          </View>
        ) : (accountsQuery.data?.accounts ?? []).length > 0 ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.pillsRow}
          >
            {(accountsQuery.data?.accounts ?? []).map(acc => (
              <AccountPill key={acc.id} account={acc} currencySymbol={currencySymbol} />
            ))}
          </ScrollView>
        ) : null}

        {/* ── Divider ──────────────────────────────────────────────────── */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>RECENT ACTIVITY</Text>
          {hasTransactions && (
            <Pressable onPress={() => router.push("/(tabs)/ledger")}>
              <Text style={styles.seeAllLink}>See all →</Text>
            </Pressable>
          )}
        </View>
        <View style={styles.rule} />

        {/* ── Transaction list ─────────────────────────────────────────── */}
        {txnQuery.isLoading ? (
          // Skeleton rows while loading
          <View style={styles.txnList}>
            {[1, 2, 3, 4].map(i => <SkeletonRow key={i} />)}
          </View>
        ) : txnQuery.isError ? (
          <View style={styles.errorState}>
            <Text style={styles.errorText}>Couldn't load transactions.</Text>
            <Pressable onPress={() => txnQuery.refetch()}>
              <Text style={styles.retryLink}>Try again</Text>
            </Pressable>
          </View>
        ) : !hasTransactions ? (
          // ── Empty state ──────────────────────────────────────────────
          <View style={styles.emptyState}>
            <Text style={styles.emptyGlyph}>◌</Text>
            <Text style={styles.emptyHeading}>Your ledger is empty.</Text>
            <Text style={styles.emptyBody}>
              No transactions yet. Time to log that new{"\n"}
              oversized jacket or fragrance purchase?
            </Text>
            <Pressable
              style={styles.emptyBtn}
              onPress={() => { /* will open QuickAdd modal */ }}
            >
              <Text style={styles.emptyBtnText}>Add First Transaction</Text>
            </Pressable>
          </View>
        ) : (
          // ── Transaction rows ─────────────────────────────────────────
          <View style={styles.txnList}>
            {transactions.map((txn, i) => (
              <React.Fragment key={txn.id}>
                <TransactionRow txn={txn} currencySymbol={currencySymbol} />
                {i < transactions.length - 1 && <View style={styles.txnDivider} />}
              </React.Fragment>
            ))}
          </View>
        )}

        {/* Bottom padding so last item clears the FAB */}
        <View style={{ height: 100 }} />
      </ScrollView>

      {/* ── FAB ─────────────────────────────────────────────────────────── */}
      <QuickAddFAB
        visible={fabVisible}
        onPress={() => {
          // Will trigger QuickAdd modal in next sprint
          console.log("QuickAdd pressed");
        }}
      />
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: {
    flex:            1,
    backgroundColor: COLORS.bg,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: SPACE.xxl,
  },

  // Header
  header: {
    flexDirection:     "row",
    justifyContent:    "space-between",
    alignItems:        "flex-start",
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.xxl,
    paddingBottom:     SPACE.lg,
  },
  greeting: {
    fontFamily: FONTS.displayBold,
    fontSize:   FONT_SIZE.xl,
    color:      COLORS.ink,
    lineHeight: FONT_SIZE.xl * 1.2,
  },
  todayDate: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.inkMuted,
    marginTop:  4,
    letterSpacing: 0.2,
  },
  avatarCircle: {
    width:           40,
    height:          40,
    borderRadius:    20,
    backgroundColor: COLORS.sand,
    alignItems:      "center",
    justifyContent:  "center",
  },
  avatarInitial: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.bg,
  },

  // Accounts pills
  pillsRow: {
    flexDirection:  "row",
    paddingHorizontal: SPACE.lg,
    paddingVertical:   SPACE.md,
    gap:            SPACE.sm,
  },

  // Section header
  sectionHeader: {
    flexDirection:     "row",
    justifyContent:    "space-between",
    alignItems:        "center",
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.md,
    paddingBottom:     SPACE.sm,
  },
  sectionTitle: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 2,
    textTransform: "uppercase",
  },
  seeAllLink: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.sand,
  },
  rule: {
    height:          1,
    backgroundColor: COLORS.rule,
    marginHorizontal: SPACE.lg,
  },

  // Transactions
  txnList: {
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.sm,
  },
  txnDivider: {
    height:          1,
    backgroundColor: COLORS.rule,
    opacity:         0.6,
  },

  // Error state
  errorState: {
    alignItems: "center",
    padding:    SPACE.xl,
    gap:        SPACE.sm,
  },
  errorText: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.inkMuted,
  },
  retryLink: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.sand,
  },

  // Empty state
  emptyState: {
    alignItems:        "center",
    paddingHorizontal: SPACE.xl,
    paddingTop:        SPACE.xxxl,
    paddingBottom:     SPACE.xxl,
  },
  emptyGlyph: {
    fontSize:     64,
    color:        COLORS.rule,
    marginBottom: SPACE.lg,
    lineHeight:   72,
  },
  emptyHeading: {
    fontFamily:   FONTS.displayBold,
    fontSize:     FONT_SIZE.xl,
    color:        COLORS.ink,
    marginBottom: SPACE.sm,
    textAlign:    "center",
  },
  emptyBody: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.base,
    color:        COLORS.inkMid,
    textAlign:    "center",
    lineHeight:   FONT_SIZE.base * 1.65,
    marginBottom: SPACE.xl,
  },
  emptyBtn: {
    backgroundColor: COLORS.ink,
    paddingVertical:   14,
    paddingHorizontal: SPACE.xl,
    borderRadius:      RADIUS.full,
  },
  emptyBtnText: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.inkInvert,
    letterSpacing: 0.3,
  },
});

// ── Transaction row styles ────────────────────────────────────────────────────
const txnStyles = StyleSheet.create({
  row: {
    flexDirection:  "row",
    alignItems:     "center",
    paddingVertical: SPACE.md,
    gap:             SPACE.md,
  },
  iconPill: {
    width:          38,
    height:         38,
    borderRadius:   RADIUS.md,
    alignItems:     "center",
    justifyContent: "center",
    flexShrink:     0,
  },
  iconGlyph: {
    fontSize: 18,
  },
  meta: {
    flex: 1,
    gap:  3,
  },
  categoryName: {
    fontFamily: FONTS.bodyMedium,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.ink,
  },
  note: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.inkMuted,
  },
  right: {
    alignItems: "flex-end",
    gap:        3,
  },
  amount: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.base,
    letterSpacing: 0.2,
  },
  date: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.xs,
    color:      COLORS.inkMuted,
    letterSpacing: 0.3,
  },
});

// ── Account pill styles ───────────────────────────────────────────────────────
const pillStyles = StyleSheet.create({
  pill: {
    flexDirection:     "row",
    alignItems:        "center",
    backgroundColor:   COLORS.bgCard,
    paddingVertical:   SPACE.sm,
    paddingHorizontal: SPACE.md,
    borderRadius:      RADIUS.lg,
    gap:               SPACE.sm,
    borderWidth:       1,
    borderColor:       COLORS.rule,
  },
  dot: {
    width:        8,
    height:       8,
    borderRadius: 4,
  },
  name: {
    fontFamily: FONTS.bodyMedium,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.inkMid,
    maxWidth:   100,
  },
  balance: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.ink,
  },
});
