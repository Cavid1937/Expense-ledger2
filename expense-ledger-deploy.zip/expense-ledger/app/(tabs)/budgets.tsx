// app/(tabs)/budgets.tsx
// =============================================================================
// Budgets screen — monthly spending limits and live progress.
//
// Data:
//   fetchBudgetProgress() hits the backend's calculateBudgetProgress endpoint
//   which returns enriched budget objects: limit, spent, remaining, percent,
//   is_exceeded, alert_triggered. We render one BudgetProgress card per budget.
//
// Layout:
//   Header ("Budgets" + month selector) →
//   Overall summary strip →
//   Overall budget(s) section →
//   Category budgets section →
//   Empty state if no budgets exist
// =============================================================================

import React, { useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useQuery, useQueryClient } from "react-query";
import { router }                   from "expo-router";
import { useFonts }                 from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS, TAB_BAR_HEIGHT } from "../../src/constants/theme";
import { BudgetProgress }   from "../../src/components/BudgetProgress";
import { useAuthStore }     from "../../src/store/auth.store";
import { fetchBudgetProgress } from "../../src/api/budgets.api";
import { formatCurrency }   from "../../src/utils/currency";

// ── Month selector helpers ────────────────────────────────────────────────────
function getMonthLabel(iso: string): string {
  return new Date(iso + "-02").toLocaleDateString("en-US", {
    month: "long",
    year:  "numeric",
  });
}

function shiftMonth(iso: string, delta: number): string {
  const [y, m] = iso.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

const currentMonth = () => new Date().toISOString().slice(0, 7);

// ── Summary strip ─────────────────────────────────────────────────────────────
function SummaryStrip({
  totalBudget,
  totalSpent,
  totalRemaining,
  totalPct,
  currencySymbol,
}: {
  totalBudget:    number;
  totalSpent:     number;
  totalRemaining: number;
  totalPct:       number;
  currencySymbol: string;
}) {
  const isOver = totalRemaining < 0;
  return (
    <View style={stripStyles.strip}>
      <View style={stripStyles.cell}>
        <Text style={stripStyles.value}>{formatCurrency(totalBudget, currencySymbol)}</Text>
        <Text style={stripStyles.label}>ALLOCATED</Text>
      </View>
      <View style={stripStyles.divider} />
      <View style={stripStyles.cell}>
        <Text style={stripStyles.value}>{formatCurrency(totalSpent, currencySymbol)}</Text>
        <Text style={stripStyles.label}>SPENT</Text>
      </View>
      <View style={stripStyles.divider} />
      <View style={stripStyles.cell}>
        <Text style={[stripStyles.value, isOver && { color: "#A0352A" }]}>
          {isOver ? "−" : ""}{formatCurrency(Math.abs(totalRemaining), currencySymbol)}
        </Text>
        <Text style={stripStyles.label}>{isOver ? "OVER" : "LEFT"}</Text>
      </View>
    </View>
  );
}

const stripStyles = StyleSheet.create({
  strip: {
    flexDirection:     "row",
    backgroundColor:   COLORS.bgInvert,
    paddingVertical:   SPACE.lg,
  },
  cell: {
    flex:        1,
    alignItems:  "center",
    gap:         4,
  },
  value: {
    fontFamily:    FONTS.displayBold,
    fontSize:      FONT_SIZE.lg,
    color:         COLORS.inkInvert,
    letterSpacing: -0.3,
  },
  label: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         "#6B6860",
    letterSpacing: 2,
  },
  divider: {
    width:           1,
    backgroundColor: "#2A2924",
    marginVertical:  SPACE.xs,
  },
});

// ── Section header ────────────────────────────────────────────────────────────
function SectionHeader({ title }: { title: string }) {
  return (
    <View style={secStyles.container}>
      <Text style={secStyles.label}>{title.toUpperCase()}</Text>
      <View style={secStyles.rule} />
    </View>
  );
}

const secStyles = StyleSheet.create({
  container: {
    paddingTop:        SPACE.lg,
    paddingHorizontal: SPACE.lg,
    paddingBottom:     SPACE.sm,
  },
  label: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 2,
    marginBottom:  SPACE.sm,
  },
  rule: {
    height:          1,
    backgroundColor: COLORS.rule,
  },
});

// ── Empty state ───────────────────────────────────────────────────────────────
function EmptyState() {
  return (
    <View style={emptyStyles.container}>
      <Text style={emptyStyles.glyph}>◌</Text>
      <Text style={emptyStyles.heading}>No active budgets.</Text>
      <Text style={emptyStyles.body}>
        Time to allocate funds for scholarship{"\n"}
        application fees or your high-protein{"\n"}
        bulking supplies?
      </Text>
      <Pressable
        style={emptyStyles.btn}
        onPress={() => console.log("TODO: open create budget modal")}
      >
        <Text style={emptyStyles.btnText}>Create First Budget</Text>
      </Pressable>
    </View>
  );
}

const emptyStyles = StyleSheet.create({
  container: {
    alignItems:        "center",
    paddingTop:        SPACE.xxxl,
    paddingHorizontal: SPACE.xl,
  },
  glyph: {
    fontSize:     52,
    color:        COLORS.rule,
    marginBottom: SPACE.lg,
    lineHeight:   60,
  },
  heading: {
    fontFamily:   FONTS.displayBold,
    fontSize:     FONT_SIZE.xl,
    color:        COLORS.ink,
    marginBottom: SPACE.sm,
    textAlign:    "center",
  },
  body: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.base,
    color:        COLORS.inkMid,
    textAlign:    "center",
    lineHeight:   FONT_SIZE.base * 1.65,
    marginBottom: SPACE.xl,
  },
  btn: {
    borderWidth:       1,
    borderColor:       COLORS.ink,
    paddingVertical:   12,
    paddingHorizontal: SPACE.xl,
    borderRadius:      RADIUS.full,
  },
  btnText: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.ink,
    letterSpacing: 0.3,
  },
});

// ── Skeleton loader ───────────────────────────────────────────────────────────
function SkeletonCard() {
  return (
    <View style={skelStyles.card}>
      <View style={skelStyles.headerRow}>
        <View style={skelStyles.icon} />
        <View style={{ flex: 1, gap: 6 }}>
          <View style={[skelStyles.line, { width: 120 }]} />
          <View style={[skelStyles.line, { width: 60 }]} />
        </View>
        <View style={[skelStyles.line, { width: 36, height: 22 }]} />
      </View>
      <View style={skelStyles.track} />
      <View style={skelStyles.amtsRow}>
        <View style={[skelStyles.line, { width: 100 }]} />
        <View style={[skelStyles.line, { width: 70 }]} />
      </View>
    </View>
  );
}

const skelStyles = StyleSheet.create({
  card:      { paddingVertical: SPACE.md, paddingHorizontal: SPACE.lg, borderBottomWidth: 1, borderBottomColor: COLORS.rule },
  headerRow: { flexDirection: "row", alignItems: "center", gap: SPACE.sm, marginBottom: SPACE.md },
  icon:      { width: 34, height: 34, borderRadius: RADIUS.md, backgroundColor: COLORS.bgSkeletonA },
  line:      { height: 13, backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.sm },
  track:     { height: 6,  backgroundColor: COLORS.bgSkeletonA, borderRadius: RADIUS.full, marginBottom: SPACE.sm },
  amtsRow:   { flexDirection: "row", justifyContent: "space-between" },
});

// ── Main screen ───────────────────────────────────────────────────────────────
export default function BudgetsScreen() {
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const today = currentMonth();

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black,
    PlayfairDisplay_700Bold,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_600SemiBold,
  });

  const { data, isLoading, isError, refetch, isRefetching } = useQuery(
    ["budget-progress", selectedMonth],
    () => fetchBudgetProgress(selectedMonth),
    { staleTime: 30_000 }
  );

  const hasOverall  = (data?.overall_budgets?.length  ?? 0) > 0;
  const hasCategory = (data?.category_budgets?.length ?? 0) > 0;
  const isEmpty     = !isLoading && !isError && !hasOverall && !hasCategory;

  if (!fontsLoaded) return null;

  return (
    <View style={styles.screen}>
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Budgets</Text>
        </View>
        <Pressable
          style={styles.addBtn}
          onPress={() => console.log("TODO: create budget")}
          accessibilityRole="button"
          accessibilityLabel="Create budget"
        >
          <Text style={styles.addBtnText}>+ New</Text>
        </Pressable>
      </View>

      {/* ── Month navigator ──────────────────────────────────────────────── */}
      <View style={styles.monthNav}>
        <Pressable
          onPress={() => setSelectedMonth((m) => shiftMonth(m, -1))}
          hitSlop={12}
          style={styles.monthArrow}
        >
          <Text style={styles.monthArrowGlyph}>‹</Text>
        </Pressable>
        <Text style={styles.monthLabel}>{getMonthLabel(selectedMonth)}</Text>
        <Pressable
          onPress={() => setSelectedMonth((m) => shiftMonth(m, 1))}
          hitSlop={12}
          disabled={selectedMonth >= today}
          style={[styles.monthArrow, selectedMonth >= today && { opacity: 0.3 }]}
        >
          <Text style={styles.monthArrowGlyph}>›</Text>
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={refetch}
            tintColor={COLORS.inkMuted}
          />
        }
      >
        {/* ── Summary strip ────────────────────────────────────────────── */}
        {data && !isEmpty && (
          <SummaryStrip
            totalBudget={data.total_budget_cents}
            totalSpent={data.total_spent_cents}
            totalRemaining={data.total_remaining_cents}
            totalPct={data.total_percent_used}
            currencySymbol={currencySymbol}
          />
        )}

        {/* ── Loading skeleton ─────────────────────────────────────────── */}
        {isLoading && (
          <>
            <View style={{ height: 88, backgroundColor: COLORS.bgInvert }} />
            <SectionHeader title="Category Budgets" />
            {[1, 2, 3].map(i => <SkeletonCard key={i} />)}
          </>
        )}

        {/* ── Error state ──────────────────────────────────────────────── */}
        {isError && (
          <View style={styles.errorState}>
            <Text style={styles.errorText}>Couldn't load budgets.</Text>
            <Pressable onPress={() => refetch()}>
              <Text style={styles.retryLink}>Try again</Text>
            </Pressable>
          </View>
        )}

        {/* ── Empty state ──────────────────────────────────────────────── */}
        {isEmpty && <EmptyState />}

        {/* ── Overall budgets ──────────────────────────────────────────── */}
        {hasOverall && (
          <>
            <SectionHeader title="Overall" />
            {data!.overall_budgets.map(b => (
              <BudgetProgress
                key={b.id}
                budget={b}
                currencySymbol={currencySymbol}
              />
            ))}
          </>
        )}

        {/* ── Category budgets ─────────────────────────────────────────── */}
        {hasCategory && (
          <>
            <SectionHeader title="By Category" />
            {data!.category_budgets.map(b => (
              <BudgetProgress
                key={b.id}
                budget={b}
                currencySymbol={currencySymbol}
              />
            ))}
          </>
        )}

        {/* ── Alerts summary ───────────────────────────────────────────── */}
        {data && data.alerts_triggered > 0 && (
          <View style={styles.alertBanner}>
            <Text style={styles.alertText}>
              ⚠ {data.alerts_triggered} budget{data.alerts_triggered > 1 ? "s" : ""}{" "}
              {data.alerts_triggered > 1 ? "are" : "is"} approaching the limit.
            </Text>
          </View>
        )}

        <View style={{ height: TAB_BAR_HEIGHT + SPACE.xl }} />
      </ScrollView>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },

  header: {
    flexDirection:     "row",
    justifyContent:    "space-between",
    alignItems:        "flex-end",
    paddingHorizontal: SPACE.lg,
    paddingTop:        SPACE.xxl,
    paddingBottom:     SPACE.sm,
  },
  title: {
    fontFamily:    "PlayfairDisplay_900Black",
    fontSize:      FONT_SIZE.xxxl,
    color:         COLORS.ink,
    lineHeight:    FONT_SIZE.xxxl * 1.1,
    letterSpacing: -0.5,
  },
  addBtn: {
    borderWidth:       1,
    borderColor:       COLORS.ink,
    paddingVertical:   7,
    paddingHorizontal: SPACE.md,
    borderRadius:      RADIUS.full,
  },
  addBtnText: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.ink,
    letterSpacing: 0.3,
  },

  monthNav: {
    flexDirection:  "row",
    alignItems:     "center",
    justifyContent: "center",
    paddingVertical: SPACE.sm,
    gap:            SPACE.lg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.rule,
  },
  monthArrow: {
    padding: SPACE.xs,
  },
  monthArrowGlyph: {
    fontFamily: FONTS.displayBold,
    fontSize:   FONT_SIZE.xl,
    color:      COLORS.inkMid,
    lineHeight: FONT_SIZE.xl * 1.2,
  },
  monthLabel: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.base,
    color:         COLORS.ink,
    letterSpacing: 0.3,
    minWidth:      160,
    textAlign:     "center",
  },

  scrollContent: {
    flexGrow: 1,
  },

  alertBanner: {
    marginHorizontal: SPACE.lg,
    marginTop:        SPACE.lg,
    paddingVertical:  SPACE.md,
    paddingHorizontal: SPACE.md,
    borderWidth:      1,
    borderColor:      "#C0613A55",
    backgroundColor:  "#C0613A0C",
    borderRadius:     RADIUS.md,
  },
  alertText: {
    fontFamily: FONTS.bodyMedium,
    fontSize:   FONT_SIZE.sm,
    color:      "#C0613A",
    lineHeight: FONT_SIZE.sm * 1.5,
  },

  errorState: {
    alignItems: "center",
    padding:    SPACE.xl,
    gap:        SPACE.sm,
  },
  errorText: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.inkMuted,
  },
  retryLink: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.sand,
  },
});
