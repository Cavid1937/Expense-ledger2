// app/(tabs)/_layout.tsx
// =============================================================================
// Tab navigation layout — final version.
//
// Tabs (visible in bar): Dashboard · Ledger · Settings
// Hidden screens (modal): add-transaction · budgets
//
// budgets is accessible via router.push("/(tabs)/budgets") from the Settings
// screen. It slides in as a regular stack push (not a modal) so the user
// can tap Back to return to Settings.
// =============================================================================

import { Tabs }        from "expo-router";
import { Platform, StyleSheet, Text, View } from "react-native";
import { useFonts, DMSans_500Medium, DMSans_600SemiBold } from "@expo-google-fonts/dm-sans";

import { COLORS, TAB_BAR_HEIGHT, FONTS, FONT_SIZE } from "../../src/constants/theme";

function TabIcon({ glyph, label, focused }: { glyph: string; label: string; focused: boolean }) {
  return (
    <View style={[styles.tabIconContainer]}>
      {focused && <View style={styles.activeBar} />}
      <Text style={[styles.tabGlyph,  focused && styles.tabGlyphFocused]}>{glyph}</Text>
      <Text style={[styles.tabLabel,  focused && styles.tabLabelFocused]}>{label}</Text>
    </View>
  );
}

export default function TabsLayout() {
  const [fontsLoaded] = useFonts({ DMSans_500Medium, DMSans_600SemiBold });
  if (!fontsLoaded) return null;

  return (
    <Tabs screenOptions={{ headerShown: false, tabBarStyle: styles.tabBar, tabBarShowLabel: false }}>
      <Tabs.Screen name="dashboard"
        options={{ title: "Dashboard", tabBarIcon: ({ focused }) => <TabIcon glyph="◈" label="Overview" focused={focused} /> }} />
      <Tabs.Screen name="ledger"
        options={{ title: "Ledger",    tabBarIcon: ({ focused }) => <TabIcon glyph="≡" label="Ledger"   focused={focused} /> }} />
      <Tabs.Screen name="settings"
        options={{ title: "Settings",  tabBarIcon: ({ focused }) => <TabIcon glyph="⊙" label="Settings" focused={focused} /> }} />

      {/* Hidden screens — not in tab bar */}
      <Tabs.Screen name="add-transaction" options={{ href: null, presentation: "modal", animation: "slide_from_bottom" }} />
      <Tabs.Screen name="budgets"         options={{ href: null }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: COLORS.bg, borderTopWidth: 1, borderTopColor: COLORS.rule,
    height: TAB_BAR_HEIGHT, paddingBottom: Platform.OS === "ios" ? 16 : 8,
    paddingTop: 0, elevation: 0, shadowOpacity: 0,
  },
  tabIconContainer: { alignItems: "center", justifyContent: "center", paddingTop: 8, width: 72, position: "relative" },
  activeBar:        { position: "absolute", top: -TAB_BAR_HEIGHT / 2 + 1, left: 0, right: 0, height: 2, backgroundColor: COLORS.ink },
  tabGlyph:         { fontSize: 18, color: COLORS.inkMuted, marginBottom: 2 },
  tabGlyphFocused:  { color: COLORS.ink },
  tabLabel:         { fontFamily: "DMSans_500Medium", fontSize: FONT_SIZE.xs, color: COLORS.inkMuted, letterSpacing: 0.5, textTransform: "uppercase" },
  tabLabelFocused:  { color: COLORS.ink, fontFamily: "DMSans_600SemiBold" },
});
