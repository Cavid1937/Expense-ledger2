// app/(tabs)/add-transaction.tsx
// =============================================================================
// Quick Add Transaction screen — presented as a modal.
//
// Screen layout (top to bottom):
//   ┌─────────────────────────────────────────────┐
//   │  Drag handle + "×" dismiss                  │
//   ├─────────────────────────────────────────────┤
//   │  Type toggle: [EXPENSE]  [INCOME]           │
//   ├─────────────────────────────────────────────┤
//   │                                             │
//   │       $  0.00                               │  ← HERO AMOUNT INPUT
//   │       (Playfair Display Black, 72pt)        │
//   │                                             │
//   ├─────────────────────────────────────────────┤
//   │  Category selector row  ▸                   │
//   ├─────────────────────────────────────────────┤
//   │  Date selector row  ▸                       │
//   ├─────────────────────────────────────────────┤
//   │  Notes (borderless, placeholder italic)     │
//   ├─────────────────────────────────────────────┤
//   │  [   Save Transaction   ]                   │
//   └─────────────────────────────────────────────┘
//
// Amount input design:
//   The TextInput itself is invisible — just a cursor. The value is rendered
//   as a styled Text element so we have full typographic control.
//   This pattern (invisible input + styled display) is common in fintech apps
//   because native TextInput cannot be styled with display-grade fonts.
//   We position the TextInput absolutely at full opacity 0, then
//   render the formatted value as a <Text> below the input.
//   Actually, for simplicity and reliability we use a transparent TextInput
//   directly with the Playfair font — React Native supports custom fonts on inputs.
//
// Cents conversion:
//   amountInput is kept as a string through the entire form.
//   At submit: amount_cents = toCents(parseFloat(amountInput))
//   This is the ONLY place the conversion happens.
//
// After success:
//   1. Invalidate "recent-transactions" and "accounts-summary" React Query caches
//   2. Run a brief success animation
//   3. Dismiss the modal — the dashboard updates automatically in the background
// =============================================================================

import React, { useRef, useState, useCallback } from "react";
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  ActivityIndicator,
  Easing,
} from "react-native";
import { router }                from "expo-router";
import { useForm, Controller }   from "react-hook-form";
import { zodResolver }           from "@hookform/resolvers/zod";
import { useQueryClient }        from "react-query";
import { useFonts }              from "expo-font";
import {
  PlayfairDisplay_900Black,
  PlayfairDisplay_700Bold,
} from "@expo-google-fonts/playfair-display";
import {
  DMSans_400Regular,
  DMSans_500Medium,
  DMSans_600SemiBold,
} from "@expo-google-fonts/dm-sans";

import { transactionSchema, TransactionFormValues } from "../../src/validations/transaction.schema";
import { CategoryPicker, DEFAULT_CATEGORIES, type Category } from "../../src/components/CategoryPicker";
import { useAuthStore }   from "../../src/store/auth.store";
import apiClient          from "../../src/api/client";
import { toCents }        from "../../src/utils/currency";
import { COLORS, FONTS, FONT_SIZE, SPACE, RADIUS } from "../../src/constants/theme";

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Today's date as YYYY-MM-DD */
const todayISO = () => new Date().toISOString().slice(0, 10);

/** Formats a YYYY-MM-DD string for display: "Wednesday, 14 January" */
function formatDateDisplay(iso: string): string {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-US", {
    weekday: "long",
    day:     "numeric",
    month:   "long",
  });
}

/** Restricts TextInput to digits and a single decimal point */
function sanitiseAmountInput(raw: string): string {
  // Allow only digits and one decimal point, max 2 decimal places
  let cleaned = raw.replace(/[^\d.]/g, "");
  const parts  = cleaned.split(".");
  if (parts.length > 2) {
    cleaned = parts[0] + "." + parts.slice(1).join("");
  }
  if (parts[1]?.length > 2) {
    cleaned = parts[0] + "." + parts[1].slice(0, 2);
  }
  return cleaned;
}

// ── Type toggle ───────────────────────────────────────────────────────────────
function TypeToggle({
  value,
  onChange,
}: {
  value:    "expense" | "income";
  onChange: (v: "expense" | "income") => void;
}) {
  return (
    <View style={toggleStyles.container}>
      {(["expense", "income"] as const).map((type) => {
        const active = value === type;
        return (
          <Pressable
            key={type}
            onPress={() => onChange(type)}
            style={[toggleStyles.pill, active && toggleStyles.pillActive]}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
          >
            <Text style={[toggleStyles.label, active && toggleStyles.labelActive]}>
              {type === "expense" ? "Expense" : "Income"}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const toggleStyles = StyleSheet.create({
  container: {
    flexDirection:     "row",
    backgroundColor:   COLORS.bgCard,
    borderRadius:      RADIUS.full,
    padding:           3,
    alignSelf:         "center",
    marginBottom:      SPACE.lg,
    borderWidth:       1,
    borderColor:       COLORS.rule,
  },
  pill: {
    paddingVertical:   SPACE.sm,
    paddingHorizontal: SPACE.lg,
    borderRadius:      RADIUS.full,
  },
  pillActive: {
    backgroundColor: COLORS.ink,
  },
  label: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.sm,
    color:         COLORS.inkMuted,
    letterSpacing: 0.4,
  },
  labelActive: {
    color:      COLORS.inkInvert,
    fontFamily: FONTS.bodySemiBold,
  },
});

// ── Detail row (category, date) ───────────────────────────────────────────────
function DetailRow({
  icon,
  label,
  value,
  placeholder,
  onPress,
  error,
}: {
  icon:        string;
  label:       string;
  value?:      string;
  placeholder: string;
  onPress:     () => void;
  error?:      string;
}) {
  return (
    <>
      <Pressable
        onPress={onPress}
        style={({ pressed }) => [rowStyles.row, pressed && rowStyles.rowPressed]}
        accessibilityRole="button"
        accessibilityLabel={label}
      >
        <View style={rowStyles.iconWrap}>
          <Text style={rowStyles.icon}>{icon}</Text>
        </View>
        <View style={rowStyles.textWrap}>
          <Text style={rowStyles.rowLabel}>{label}</Text>
          <Text style={[rowStyles.rowValue, !value && rowStyles.rowPlaceholder]}>
            {value ?? placeholder}
          </Text>
        </View>
        <Text style={rowStyles.chevron}>›</Text>
      </Pressable>
      {error && <Text style={rowStyles.error}>{error}</Text>}
    </>
  );
}

const rowStyles = StyleSheet.create({
  row: {
    flexDirection:  "row",
    alignItems:     "center",
    paddingVertical: SPACE.md,
    gap:             SPACE.md,
  },
  rowPressed: { opacity: 0.65 },
  iconWrap: {
    width:           38,
    height:          38,
    borderRadius:    RADIUS.md,
    backgroundColor: COLORS.bgCard,
    alignItems:      "center",
    justifyContent:  "center",
    borderWidth:     1,
    borderColor:     COLORS.rule,
  },
  icon: { fontSize: 17 },
  textWrap: { flex: 1 },
  rowLabel: {
    fontFamily:    FONTS.bodyMedium,
    fontSize:      FONT_SIZE.xs,
    color:         COLORS.inkMuted,
    letterSpacing: 1,
    textTransform: "uppercase",
    marginBottom:  2,
  },
  rowValue: {
    fontFamily: FONTS.bodySemiBold,
    fontSize:   FONT_SIZE.base,
    color:      COLORS.ink,
  },
  rowPlaceholder: {
    fontFamily: FONTS.bodyRegular,
    color:      COLORS.inkMuted,
  },
  chevron: {
    fontFamily: FONTS.bodyBold,
    fontSize:   FONT_SIZE.xl,
    color:      COLORS.rule,
  },
  error: {
    fontFamily:   FONTS.bodyRegular,
    fontSize:     FONT_SIZE.xs,
    color:        COLORS.negative,
    paddingLeft:  54,
    marginBottom: SPACE.xs,
  },
});

// ── Main screen ───────────────────────────────────────────────────────────────
export default function AddTransactionScreen() {
  const queryClient    = useQueryClient();
  const currencySymbol = useAuthStore((s) => s.user?.currency_symbol ?? "$");

  // UI state
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [selectedCategory,   setSelectedCategory]   = useState<Category | null>(null);
  const [serverError,        setServerError]         = useState<string | null>(null);

  // Success animation
  const successScale   = useRef(new Animated.Value(0)).current;
  const successOpacity = useRef(new Animated.Value(0)).current;
  const [showSuccess,  setShowSuccess] = useState(false);

  // Font loading
  const [fontsLoaded] = useFonts({
    PlayfairDisplay_900Black,
    PlayfairDisplay_700Bold,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_600SemiBold,
  });

  // ── Form ───────────────────────────────────────────────────────────────────
  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<TransactionFormValues>({
    resolver:      zodResolver(transactionSchema),
    defaultValues: {
      type:        "expense",
      amountInput: "",
      category_id: "",
      account_id:  "acc-default",   // TODO: replace with real account picker
      date:        todayISO(),
      notes:       "",
    },
    mode: "onSubmit",              // Only validate on submit — not on every keystroke
  });

  const watchType        = watch("type");
  const watchAmountInput = watch("amountInput");
  const watchDate        = watch("date");

  // ── Category selection ────────────────────────────────────────────────────
  const handleCategorySelect = useCallback((cat: Category) => {
    setSelectedCategory(cat);
    setValue("category_id", cat.id, { shouldValidate: false });
  }, [setValue]);

  // When type changes, clear the category if it doesn't match the new type
  const handleTypeChange = useCallback((newType: "expense" | "income") => {
    if (
      selectedCategory &&
      selectedCategory.type !== newType &&
      selectedCategory.type !== "both"
    ) {
      setSelectedCategory(null);
      setValue("category_id", "");
    }
  }, [selectedCategory, setValue]);

  // ── Success animation ─────────────────────────────────────────────────────
  const runSuccessAnimation = useCallback(() => {
    setShowSuccess(true);
    Animated.sequence([
      Animated.parallel([
        Animated.spring(successScale, {
          toValue:         1,
          useNativeDriver: true,
          damping:         14,
          stiffness:       200,
        }),
        Animated.timing(successOpacity, {
          toValue:         1,
          duration:        180,
          useNativeDriver: true,
        }),
      ]),
      Animated.delay(700),
      Animated.timing(successOpacity, {
        toValue:         0,
        duration:        200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setShowSuccess(false);
      successScale.setValue(0);
      router.back();
    });
  }, [successScale, successOpacity]);

  // ── Submit ────────────────────────────────────────────────────────────────
  const onSubmit = async (values: TransactionFormValues) => {
    setServerError(null);

    // ── THE CRITICAL CONVERSION ────────────────────────────────────────────
    // amountInput is a string like "52.50" → toCents → 5250 (safe integer cents)
    // This is the ONLY place this conversion happens in the entire form flow.
    const amount_cents = toCents(parseFloat(values.amountInput));

    const payload = {
      account_id:  values.account_id,
      category_id: values.category_id || null,
      amount_cents,                          // Positive integer, always
      type:        values.type,
      date:        values.date,
      note:        values.notes?.trim() || null,
    };

    try {
      await apiClient.post("/transactions", payload);

      // ── Invalidate React Query caches ─────────────────────────────────────
      // Both queries are invalidated simultaneously so the dashboard
      // refreshes the balance card and the transaction list together.
      await Promise.all([
        queryClient.invalidateQueries("recent-transactions"),
        queryClient.invalidateQueries("accounts-summary"),
      ]);

      // Run success animation then auto-dismiss
      runSuccessAnimation();

    } catch (error: any) {
      const message =
        error?.response?.data?.message || "Could not save transaction. Please try again.";
      setServerError(message);
    }
  };

  if (!fontsLoaded) return null;

  // Formatted display amount — shows "0.00" when empty
  const displayAmount = watchAmountInput
    ? watchAmountInput
    : "0.00";

  const amountColor = watchType === "expense" ? COLORS.negative : COLORS.positive;

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Header ────────────────────────────────────────────────────── */}
        <View style={styles.header}>
          <View style={styles.dragHandle} />
          <Pressable
            onPress={() => router.back()}
            hitSlop={12}
            style={styles.closeBtn}
            accessibilityRole="button"
            accessibilityLabel="Close"
          >
            <Text style={styles.closeBtnText}>✕</Text>
          </Pressable>
        </View>

        {/* ── Type toggle ───────────────────────────────────────────────── */}
        <Controller
          control={control}
          name="type"
          render={({ field: { value, onChange } }) => (
            <TypeToggle
              value={value}
              onChange={(v) => {
                onChange(v);
                handleTypeChange(v);
              }}
            />
          )}
        />

        {/* ── Hero amount input ─────────────────────────────────────────── */}
        <View style={styles.amountBlock}>
          {/* Currency symbol — large, muted, optically aligned */}
          <Text style={[styles.currencySymbol, { color: amountColor + "99" }]}>
            {currencySymbol}
          </Text>

          {/* The amount display — Playfair Black at display scale */}
          <Controller
            control={control}
            name="amountInput"
            render={({ field: { onChange, value } }) => (
              <TextInput
                style={[styles.amountInput, { color: amountColor }]}
                value={value}
                onChangeText={(raw) => onChange(sanitiseAmountInput(raw))}
                placeholder="0.00"
                placeholderTextColor={COLORS.rule}
                keyboardType="decimal-pad"
                returnKeyType="done"
                selectTextOnFocus
                autoFocus
                maxLength={12}
                accessibilityLabel="Transaction amount"
              />
            )}
          />
        </View>

        {/* Amount validation error */}
        {errors.amountInput && (
          <Text style={styles.amountError}>{errors.amountInput.message}</Text>
        )}

        {/* Server error */}
        {serverError && (
          <Pressable
            style={styles.serverErrorBanner}
            onPress={() => setServerError(null)}
          >
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </Pressable>
        )}

        {/* ── Divider ───────────────────────────────────────────────────── */}
        <View style={styles.rule} />

        {/* ── Detail rows ───────────────────────────────────────────────── */}
        <View style={styles.detailRows}>
          {/* Category */}
          <DetailRow
            icon={selectedCategory?.icon ?? "🏷️"}
            label="Category"
            value={selectedCategory?.name}
            placeholder="Select a category"
            onPress={() => setShowCategoryPicker(true)}
            error={errors.category_id?.message}
          />
          <View style={styles.rowDivider} />

          {/* Date — tapping would open a date picker (stub for now) */}
          <DetailRow
            icon="📅"
            label="Date"
            value={formatDateDisplay(watchDate)}
            placeholder="Select a date"
            onPress={() => {
              // TODO: implement DateTimePicker in next sprint
            }}
          />
          <View style={styles.rowDivider} />
        </View>

        {/* ── Notes input — borderless, editorial ──────────────────────── */}
        <Controller
          control={control}
          name="notes"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextInput
              style={styles.notesInput}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              multiline
              numberOfLines={3}
              placeholder={
                "e.g., Roja Elysium 100ml, oversized leather jacket, " +
                "or monthly salicylic acid restock."
              }
              placeholderTextColor={COLORS.inkMuted}
              returnKeyType="default"
              blurOnSubmit={false}
              textAlignVertical="top"
            />
          )}
        />
        {errors.notes && (
          <Text style={styles.fieldError}>{errors.notes.message}</Text>
        )}

        <View style={styles.rule} />

        {/* ── Submit button ─────────────────────────────────────────────── */}
        <Pressable
          style={({ pressed }) => [
            styles.submitBtn,
            pressed      && styles.submitBtnPressed,
            isSubmitting && styles.submitBtnDisabled,
          ]}
          onPress={handleSubmit(onSubmit)}
          disabled={isSubmitting}
          accessibilityRole="button"
          accessibilityLabel="Save transaction"
        >
          {isSubmitting ? (
            <ActivityIndicator size="small" color={COLORS.inkInvert} />
          ) : (
            <Text style={styles.submitBtnText}>
              Save {watchType === "expense" ? "Expense" : "Income"}
            </Text>
          )}
        </Pressable>

        <View style={{ height: SPACE.xl }} />
      </ScrollView>

      {/* ── Category picker bottom sheet ──────────────────────────────────── */}
      <CategoryPicker
        visible={showCategoryPicker}
        selectedId={selectedCategory?.id ?? null}
        transactionType={watchType}
        onSelect={handleCategorySelect}
        onClose={() => setShowCategoryPicker(false)}
      />

      {/* ── Success overlay ───────────────────────────────────────────────── */}
      {showSuccess && (
        <Animated.View
          style={[styles.successOverlay, { opacity: successOpacity }]}
          pointerEvents="none"
        >
          <Animated.View
            style={[
              styles.successBadge,
              { transform: [{ scale: successScale }] },
            ]}
          >
            <Text style={styles.successGlyph}>✓</Text>
            <Text style={styles.successLabel}>Saved</Text>
          </Animated.View>
        </Animated.View>
      )}
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  screen: {
    flex:            1,
    backgroundColor: COLORS.bg,
  },
  scroll: {
    paddingHorizontal: SPACE.lg,
    paddingBottom:     SPACE.xxl,
  },

  // Header
  header: {
    flexDirection:  "row",
    justifyContent: "flex-end",
    alignItems:     "center",
    paddingTop:     SPACE.md,
    marginBottom:   SPACE.lg,
  },
  dragHandle: {
    position:        "absolute",
    left:            0,
    right:           0,
    top:             SPACE.sm,
    height:          3,
    width:           40,
    alignSelf:       "center",
    backgroundColor: COLORS.rule,
    borderRadius:    RADIUS.full,
  },
  closeBtn: {
    width:           36,
    height:          36,
    borderRadius:    18,
    backgroundColor: COLORS.bgCard,
    borderWidth:     1,
    borderColor:     COLORS.rule,
    alignItems:      "center",
    justifyContent:  "center",
  },
  closeBtnText: {
    fontFamily: FONTS.bodyMedium,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.inkMid,
  },

  // Amount block
  amountBlock: {
    flexDirection:  "row",
    alignItems:     "flex-end",
    justifyContent: "center",
    paddingVertical: SPACE.xl,
    gap:             SPACE.xs,
  },
  currencySymbol: {
    fontFamily:  FONTS.displayBold,
    fontSize:    FONT_SIZE.xxxl,
    lineHeight:  FONT_SIZE.xxxl * 1.1,
    paddingBottom: 4,
  },
  amountInput: {
    fontFamily:  "PlayfairDisplay_900Black",
    fontSize:    72,
    lineHeight:  72,
    letterSpacing: -2,
    minWidth:    60,
    maxWidth:    260,
    textAlign:   "center",
    // Remove default TextInput padding on Android
    padding:     0,
    margin:      0,
    includeFontPadding: false,
  },
  amountError: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.negative,
    textAlign:  "center",
    marginTop:  -SPACE.md,
    marginBottom: SPACE.sm,
  },

  // Server error
  serverErrorBanner: {
    backgroundColor: "rgba(193,18,31,0.08)",
    borderWidth:     1,
    borderColor:     COLORS.negative,
    borderRadius:    RADIUS.md,
    padding:         SPACE.md,
    marginBottom:    SPACE.md,
  },
  serverErrorText: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.sm,
    color:      COLORS.negative,
    lineHeight: 18,
  },

  // Dividers / rules
  rule: {
    height:     1,
    backgroundColor: COLORS.rule,
    marginVertical: SPACE.md,
  },
  detailRows: {
    // Wraps the category and date rows
  },
  rowDivider: {
    height:          1,
    backgroundColor: COLORS.rule,
    opacity:         0.5,
  },

  // Notes
  notesInput: {
    fontFamily:  FONTS.bodyRegular,
    fontSize:    FONT_SIZE.base,
    color:       COLORS.inkMid,
    lineHeight:  FONT_SIZE.base * 1.7,
    minHeight:   80,
    paddingTop:  SPACE.sm,
    paddingBottom: SPACE.sm,
    // No border — clean, editorial
  },
  fieldError: {
    fontFamily: FONTS.bodyRegular,
    fontSize:   FONT_SIZE.xs,
    color:      COLORS.negative,
    marginBottom: SPACE.xs,
  },

  // Submit
  submitBtn: {
    backgroundColor: COLORS.ink,
    borderRadius:    RADIUS.full,
    paddingVertical: 17,
    alignItems:      "center",
    justifyContent:  "center",
    marginTop:       SPACE.md,
    minHeight:       56,
    // Warm shadow matches editorial palette
    shadowColor:     "#8A7A5A",
    shadowOffset:    { width: 0, height: 5 },
    shadowOpacity:   0.2,
    shadowRadius:    12,
    elevation:       6,
  },
  submitBtnPressed: {
    opacity:   0.82,
    transform: [{ scale: 0.985 }],
  },
  submitBtnDisabled: {
    opacity: 0.55,
  },
  submitBtnText: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.md,
    color:         COLORS.inkInvert,
    letterSpacing: 0.4,
  },

  // Success overlay
  successOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(247,244,238,0.85)",
    alignItems:      "center",
    justifyContent:  "center",
  },
  successBadge: {
    alignItems:      "center",
    justifyContent:  "center",
    gap:             SPACE.sm,
  },
  successGlyph: {
    fontFamily: FONTS.displayBold,
    fontSize:   72,
    color:      COLORS.positive,
    lineHeight: 80,
  },
  successLabel: {
    fontFamily:    FONTS.bodySemiBold,
    fontSize:      FONT_SIZE.lg,
    color:         COLORS.ink,
    letterSpacing: 2,
    textTransform: "uppercase",
  },
});
