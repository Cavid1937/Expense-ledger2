// app/(auth)/_layout.tsx
// =============================================================================
// Auth group layout.
//
// Two responsibilities:
//   1. Renders a clean Stack navigator for the auth screens (no header chrome)
//   2. Reverse auth guard: if the user IS already authenticated and somehow
//      lands on an auth screen (e.g. via a deep link), redirect them to the
//      dashboard immediately — no need to log in twice.
// =============================================================================

import { useEffect } from "react";
import { Stack }     from "expo-router";
import { Redirect }  from "expo-router";
import { useAuthStore } from "../../src/store/auth.store";

export default function AuthLayout() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const isHydrated      = useAuthStore((state) => state.isHydrated);

  // If hydration is still pending, let the root layout handle it
  if (!isHydrated) return null;

  // Reverse guard: already authenticated → skip auth screens
  if (isAuthenticated) {
    return <Redirect href="/(tabs)/dashboard" />;
  }

  return (
    <Stack
      screenOptions={{
        headerShown:       false,   // Auth screens manage their own headers
        contentStyle:      { backgroundColor: "#0C0C0F" },
        animation:         "fade",  // Smooth cross-fade between auth screens
        animationDuration: 180,
      }}
    >
      <Stack.Screen name="login"            />
      <Stack.Screen name="register"         />
      <Stack.Screen name="forgot-password"  />
    </Stack>
  );
}
