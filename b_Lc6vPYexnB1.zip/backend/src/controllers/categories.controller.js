import db from '../db.js';

export const getCategories = async (req, res) => {
  const { userId } = req.user;

  try {
    const categories = db.categories.find(userId).sort((a, b) => a.name.localeCompare(b.name));
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const createCategory = async (req, res) => {
  const { userId } = req.user;
  const { name, color, icon, description } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Category name is required' });
  }

  try {
    const category = db.categories.create({
      userId,
      name,
      color: color || '#6366f1',
      icon: icon || 'tag',
      description
    });
    res.status(201).json(category);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const updateCategory = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;
  const { name, color, icon, description } = req.body;

  try {
    const category = db.categories.findOne(parseInt(id));

    if (!category || category.userId !== userId) {
      return res.status(404).json({ error: 'Category not found' });
    }

    const updated = db.categories.findOne(parseInt(id));
    Object.assign(updated, { name, color, icon, description });
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteCategory = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const category = db.categories.findOne(parseInt(id));

    if (!category || category.userId !== userId) {
      return res.status(404).json({ error: 'Category not found' });
    }

    db.categories.delete(parseInt(id));
    res.json({ message: 'Category deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
