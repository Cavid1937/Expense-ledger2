import db from '../db.js';

export const getTransactions = async (req, res) => {
  const { userId } = req.user;
  const { categoryId, startDate, endDate, type, limit = 50, offset = 0 } = req.query;

  try {
    let transactions = db.transactions.find({ userId });

    if (categoryId) transactions = transactions.filter(t => t.categoryId === parseInt(categoryId));
    if (type) transactions = transactions.filter(t => t.type === type);
    if (startDate) transactions = transactions.filter(t => new Date(t.date) >= new Date(startDate));
    if (endDate) transactions = transactions.filter(t => new Date(t.date) <= new Date(endDate));

    const paginated = transactions
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(parseInt(offset), parseInt(offset) + parseInt(limit));

    res.json(paginated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const createTransaction = async (req, res) => {
  const { userId } = req.user;
  const data = { ...req.body, userId, date: req.body.date || new Date().toISOString() };

  try {
    const transaction = db.transactions.create(data);
    res.status(201).json(transaction);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getTransaction = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const transaction = db.transactions.findOne(parseInt(id));

    if (!transaction || transaction.userId !== userId) {
      return res.status(404).json({ error: 'Transaction not found' });
    }
    res.json(transaction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateTransaction = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const transaction = db.transactions.findOne(parseInt(id));

    if (!transaction || transaction.userId !== userId) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const updated = db.transactions.update(parseInt(id), req.body);
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteTransaction = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const transaction = db.transactions.findOne(parseInt(id));

    if (!transaction || transaction.userId !== userId) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    db.transactions.delete(parseInt(id));
    res.json({ message: 'Transaction deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getSummary = async (req, res) => {
  const { userId } = req.user;
  const { startDate, endDate } = req.query;

  try {
    let transactions = db.transactions.find({ userId });

    if (startDate) transactions = transactions.filter(t => new Date(t.date) >= new Date(startDate));
    if (endDate) transactions = transactions.filter(t => new Date(t.date) <= new Date(endDate));

    const totalIncome = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + (t.amount || 0), 0);

    const totalExpense = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + (t.amount || 0), 0);

    res.json({ totalIncome, totalExpense });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
