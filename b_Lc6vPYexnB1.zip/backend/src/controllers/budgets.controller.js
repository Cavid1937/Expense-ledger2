import db from '../db.js';

export const getBudgets = async (req, res) => {
  const { userId } = req.user;

  try {
    const budgets = db.budgets.find(userId);
    res.json(budgets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const createBudget = async (req, res) => {
  const { userId } = req.user;
  const { name, limit, categoryId } = req.body;

  if (!name || !limit) {
    return res.status(400).json({ error: 'Name and limit are required' });
  }

  try {
    const budget = db.budgets.create({
      userId,
      name,
      limit: parseFloat(limit),
      categoryId: categoryId ? parseInt(categoryId) : null,
      spent: 0
    });

    res.status(201).json(budget);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const updateBudget = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const budget = db.budgets.findOne(parseInt(id));

    if (!budget || budget.userId !== userId) {
      return res.status(404).json({ error: 'Budget not found' });
    }

    const updated = db.budgets.update(parseInt(id), req.body);
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const deleteBudget = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.user;

  try {
    const budget = db.budgets.findOne(parseInt(id));

    if (!budget || budget.userId !== userId) {
      return res.status(404).json({ error: 'Budget not found' });
    }

    db.budgets.delete(parseInt(id));
    res.json({ message: 'Budget deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getBudgetProgress = async (req, res) => {
  const { userId } = req.user;

  try {
    const budgets = db.budgets.find(userId);
    const transactions = db.transactions.find({ userId });

    const progress = budgets.map(budget => {
      const categoryTx = transactions.filter(t => 
        t.type === 'expense' && 
        (budget.categoryId === null || t.categoryId === budget.categoryId)
      );
      const spent = categoryTx.reduce((sum, t) => sum + (t.amount || 0), 0);
      const percentage = Math.min((spent / budget.limit) * 100, 100);

      return {
        ...budget,
        spent,
        remaining: Math.max(0, budget.limit - spent),
        percentage
      };
    });

    res.json(progress);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
