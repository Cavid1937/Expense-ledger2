// Placeholder service layer - logic moved to controllers for simplicity
// This can be expanded later if business logic grows complex

export const serviceExample = () => {
  // Services can be added here as the app grows
};
