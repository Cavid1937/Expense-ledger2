import express from 'express';
import * as AccountsController from '../controllers/accounts.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.post('/register', AccountsController.register);
router.post('/login', AccountsController.login);
router.get('/me', requireAuth, AccountsController.getProfile);
router.patch('/me', requireAuth, AccountsController.updateProfile);

export default router;
