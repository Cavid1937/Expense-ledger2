import express from 'express';
import * as BudgetsController from '../controllers/budgets.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.use(requireAuth);

router.get('/', BudgetsController.getBudgets);
router.post('/', BudgetsController.createBudget);
router.get('/progress', BudgetsController.getBudgetProgress);
router.patch('/:id', BudgetsController.updateBudget);
router.delete('/:id', BudgetsController.deleteBudget);

export default router;
