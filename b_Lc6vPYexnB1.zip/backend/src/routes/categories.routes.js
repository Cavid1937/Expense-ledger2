import express from 'express';
import * as CategoriesController from '../controllers/categories.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.use(requireAuth);

router.get('/', CategoriesController.getCategories);
router.post('/', CategoriesController.createCategory);
router.patch('/:id', CategoriesController.updateCategory);
router.delete('/:id', CategoriesController.deleteCategory);

export default router;
