import express from 'express';
import * as TransactionsController from '../controllers/transactions.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.use(requireAuth);

router.get('/', TransactionsController.getTransactions);
router.post('/', TransactionsController.createTransaction);
router.get('/summary', TransactionsController.getSummary);
router.get('/:id', TransactionsController.getTransaction);
router.patch('/:id', TransactionsController.updateTransaction);
router.delete('/:id', TransactionsController.deleteTransaction);

export default router;
