export async function up(knex) {
  return knex.schema.createTable('categories', (table) => {
    table.increments('id').primary();
    table.integer('userId').unsigned().notNullable();
    table.string('name').notNullable();
    table.string('color').defaultTo('#6366f1');
    table.string('icon').defaultTo('tag');
    table.string('description');
    table.timestamps(true, true);
    table.foreign('userId').references('users.id').onDelete('CASCADE');
    table.index(['userId', 'name']);
  });
}

export async function down(knex) {
  return knex.schema.dropTableIfExists('categories');
}
