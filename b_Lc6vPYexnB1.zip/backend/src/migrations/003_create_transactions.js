export async function up(knex) {
  return knex.schema.createTable('transactions', (table) => {
    table.increments('id').primary();
    table.integer('userId').unsigned().notNullable();
    table.integer('categoryId').unsigned().notNullable();
    table.decimal('amount', 12, 2).notNullable();
    table.string('description');
    table.string('type').defaultTo('expense'); // income, expense
    table.timestamp('date').notNullable().defaultTo(knex.fn.now());
    table.string('receiptUrl');
    table.text('metadata').defaultTo('{}');
    table.boolean('isRecurring').defaultTo(false);
    table.string('recurringFrequency'); // daily, weekly, monthly, yearly
    table.timestamps(true, true);
    table.foreign('userId').references('users.id').onDelete('CASCADE');
    table.foreign('categoryId').references('categories.id').onDelete('RESTRICT');
    table.index(['userId', 'date']);
    table.index(['categoryId']);
  });
}

export async function down(knex) {
  return knex.schema.dropTableIfExists('transactions');
}
