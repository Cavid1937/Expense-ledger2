export async function up(knex) {
  return knex.schema.createTable('budgets', (table) => {
    table.increments('id').primary();
    table.integer('userId').unsigned().notNullable();
    table.integer('categoryId').unsigned().nullable();
    table.string('name').notNullable();
    table.decimal('limit', 12, 2).notNullable();
    table.string('period').defaultTo('monthly'); // monthly, weekly, yearly
    table.timestamp('startDate').notNullable().defaultTo(knex.fn.now());
    table.timestamp('endDate').nullable();
    table.boolean('isActive').defaultTo(true);
    table.text('settings').defaultTo('{}');
    table.timestamps(true, true);
    table.foreign('userId').references('users.id').onDelete('CASCADE');
    table.foreign('categoryId').references('categories.id').onDelete('SET NULL');
    table.index(['userId', 'isActive']);
  });
}

export async function down(knex) {
  return knex.schema.dropTableIfExists('budgets');
}
