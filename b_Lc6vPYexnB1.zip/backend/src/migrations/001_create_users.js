export async function up(knex) {
  return knex.schema.createTable('users', (table) => {
    table.increments('id').primary();
    table.string('email').unique().notNullable();
    table.string('password').notNullable();
    table.string('firstName');
    table.string('lastName');
    table.string('phone');
    table.string('currency').defaultTo('USD');
    table.text('preferences').defaultTo('{}');
    table.timestamps(true, true);
    table.index('email');
  });
}

export async function down(knex) {
  return knex.schema.dropTableIfExists('users');
}
