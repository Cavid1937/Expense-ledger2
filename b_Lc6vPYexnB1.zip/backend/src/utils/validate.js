// src/middleware/validate.js
// =============================================================================
// A reusable Express middleware factory that validates request bodies (or
// query params, headers) against a Zod schema BEFORE the request reaches
// the controller. If validation fails, the error is forwarded to the global
// errorHandler via next(err), which formats it into a clean 422 response.
//
// Usage in a route file:
//   const { validate } = require("../../middleware/validate");
//   const { registerSchema } = require("./auth.schema");
//
//   router.post("/register", validate(registerSchema), authController.register);
// =============================================================================

/**
 * Creates an Express middleware that parses req.body against the given
 * Zod schema. On success, req.body is replaced with the parsed (and
 * potentially transformed/coerced) value. On failure, next(zodError)
 * is called, which the global errorHandler converts to a 422 response.
 *
 * @param   {import("zod").ZodTypeAny} schema - A Zod schema to validate against.
 * @returns {import("express").RequestHandler}
 */
function validate(schema) {
  return (req, res, next) => {
    // schema.parse() throws a ZodError on failure.
    // We use safeParse() instead so we can forward the error cleanly.
    const result = schema.safeParse(req.body);

    if (!result.success) {
      // Forward the ZodError to the global error handler
      return next(result.error);
    }

    // Replace req.body with the Zod-parsed value.
    // This gives us type coercion for free (e.g. string → number where defined).
    req.body = result.data;
    next();
  };
}

module.exports = { validate };
