// Simple in-memory database for development
const database = {
  users: [],
  transactions: [],
  categories: [],
  budgets: [],
  accounts: []
};

let userIdCounter = 1;
let transactionIdCounter = 1;
let categoryIdCounter = 1;
let budgetIdCounter = 1;

export const db = {
  users: {
    findOne: (query) => database.users.find(u => {
      if (query.email) return u.email === query.email;
      if (query.id) return u.id === query.id;
      return false;
    }),
    create: (data) => {
      const user = { id: userIdCounter++, ...data, createdAt: new Date() };
      database.users.push(user);
      return user;
    },
    update: (id, data) => {
      const user = database.users.find(u => u.id === id);
      if (user) Object.assign(user, data, { updatedAt: new Date() });
      return user;
    }
  },
  
  transactions: {
    find: (query) => {
      return database.transactions.filter(t => {
        if (query.userId) return t.userId === query.userId;
        return true;
      });
    },
    findOne: (id) => database.transactions.find(t => t.id === id),
    create: (data) => {
      const transaction = { id: transactionIdCounter++, ...data, createdAt: new Date() };
      database.transactions.push(transaction);
      return transaction;
    },
    update: (id, data) => {
      const transaction = database.transactions.find(t => t.id === id);
      if (transaction) Object.assign(transaction, data, { updatedAt: new Date() });
      return transaction;
    },
    delete: (id) => {
      const index = database.transactions.findIndex(t => t.id === id);
      if (index > -1) database.transactions.splice(index, 1);
    }
  },
  
  categories: {
    find: (userId) => database.categories.filter(c => c.userId === userId),
    findOne: (id) => database.categories.find(c => c.id === id),
    create: (data) => {
      const category = { id: categoryIdCounter++, ...data, createdAt: new Date() };
      database.categories.push(category);
      return category;
    },
    delete: (id) => {
      const index = database.categories.findIndex(c => c.id === id);
      if (index > -1) database.categories.splice(index, 1);
    }
  },
  
  budgets: {
    find: (userId) => database.budgets.filter(b => b.userId === userId),
    findOne: (id) => database.budgets.find(b => b.id === id),
    create: (data) => {
      const budget = { id: budgetIdCounter++, ...data, createdAt: new Date() };
      database.budgets.push(budget);
      return budget;
    },
    update: (id, data) => {
      const budget = database.budgets.find(b => b.id === id);
      if (budget) Object.assign(budget, data, { updatedAt: new Date() });
      return budget;
    },
    delete: (id) => {
      const index = database.budgets.findIndex(b => b.id === id);
      if (index > -1) database.budgets.splice(index, 1);
    }
  }
};

export default db;
