import knex from 'knex';

const config = {
  client: 'better-sqlite3',
  connection: {
    filename: './db/ledger.sqlite3'
  },
  migrations: {
    directory: './src/migrations'
  },
  seeds: {
    directory: './src/seeds'
  },
  useNullAsDefault: true
};

export default config;
