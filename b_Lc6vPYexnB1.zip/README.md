# Expense Ledger - Full Stack Mobile App

A complete expense tracking application built with Expo (React Native) frontend and Express.js backend with SQLite database.

## Project Structure

```
├── backend/              # Express.js API server
│   ├── src/
│   │   ├── server.js    # Main server entry point
│   │   ├── db.js        # Database connection
│   │   ├── migrations/  # Database schema migrations
│   │   ├── controllers/ # Business logic
│   │   ├── routes/      # API endpoints
│   │   ├── services/    # Service layer
│   │   ├── middleware/  # Auth, error handling
│   │   └── utils/       # Helpers and validation
│   ├── knexfile.js      # Knex configuration
│   ├── package.json
│   └── .env.local       # Environment variables
│
└── mobile/              # Expo React Native app
    ├── app/
    │   ├── (auth)/      # Auth screens (login, register, forgot-password)
    │   ├── (tabs)/      # Main app screens (dashboard, history, analytics, settings)
    │   ├── components/  # Reusable UI components
    │   ├── lib/
    │   │   └── api/     # API client calls
    │   ├── store/       # Zustand state management
    │   └── constants/   # Theme and config
    ├── app.json         # Expo configuration
    ├── package.json
    └── .env.local       # Environment variables
```

## Quick Start

### Prerequisites
- Node.js 18+ and pnpm
- Expo CLI (`npm install -g expo-cli`)

### 1. Start Backend

```bash
cd backend
pnpm install
pnpm dev
```

The API will run on `http://localhost:4000/api/v1`

**Database**: Automatically initialized with SQLite at `backend/db/ledger.sqlite3`

### 2. Start Mobile App

```bash
cd mobile
pnpm install
pnpm start
```

Then press:
- `w` for web preview
- `i` for iOS simulator
- `a` for Android emulator
- `r` to reload
- `q` to quit

## Environment Variables

### Backend (.env.local)
```
EXPO_PUBLIC_API_URL=http://localhost:4000/api/v1
EXPO_PUBLIC_APP_ENV=development
JWT_SECRET=expense-ledger-secret-key-12345
DATABASE_URL=./db/ledger.sqlite3
PORT=4000
NODE_ENV=development
```

### Mobile (.env.local)
```
EXPO_PUBLIC_API_URL=http://localhost:4000/api/v1
EXPO_PUBLIC_APP_ENV=development
```

## API Endpoints

All endpoints require JWT authentication (except `/auth/login` and `/auth/register`)

### Authentication
- `POST /auth/login` - Login
- `POST /auth/register` - Register new account
- `POST /auth/refresh` - Refresh access token

### Transactions
- `GET /transactions` - List transactions
- `POST /transactions` - Create transaction
- `PATCH /transactions/:id` - Update transaction
- `DELETE /transactions/:id` - Delete transaction
- `GET /transactions/summary` - Get spending summary

### Categories
- `GET /categories` - List categories
- `POST /categories` - Create category
- `PATCH /categories/:id` - Update category
- `DELETE /categories/:id` - Delete category

### Budgets
- `GET /budgets` - List budgets
- `POST /budgets` - Create budget
- `PATCH /budgets/:id` - Update budget
- `DELETE /budgets/:id` - Delete budget
- `GET /budgets/progress` - Get budget progress

## Features

✅ User authentication with JWT
✅ Expense tracking with categories
✅ Budget management and monitoring
✅ Transaction history with filtering
✅ Analytics and spending insights
✅ Receipt upload (camera integration)
✅ Dark mode UI
✅ Secure token storage
✅ Offline support with local caching

## Technology Stack

### Backend
- **Framework**: Express.js
- **Database**: SQLite with Knex.js
- **Auth**: JWT + bcryptjs
- **Validation**: Zod

### Mobile
- **Framework**: Expo / React Native
- **Routing**: Expo Router v3
- **State**: Zustand
- **Data Fetching**: React Query + Axios
- **Forms**: React Hook Form + Zod
- **UI**: React Native with Tailwind-inspired styling

## Development

### Backend Commands
```bash
cd backend
pnpm dev          # Start dev server with hot reload
pnpm start        # Start production server
pnpm migrate      # Run database migrations
```

### Mobile Commands
```bash
cd mobile
pnpm start        # Start Expo dev server
pnpm web          # Run on web
pnpm android      # Run on Android emulator
pnpm ios          # Run on iOS simulator
```

## Database

Database is automatically initialized with migrations when the backend starts. Tables include:
- **users** - User accounts
- **categories** - Expense categories
- **transactions** - Individual expenses/income
- **budgets** - Budget limits and tracking

## Testing

### Test Backend
```bash
# Basic health check
curl http://localhost:4000/health

# Login
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Test Mobile
Use Expo Go or web preview to test the mobile app.

## Deployment

### Backend Deployment (Railway, Heroku, etc.)

1. Set production environment variables
2. Update `EXPO_PUBLIC_API_URL` to production backend URL
3. Set `NODE_ENV=production`
4. Deploy to hosting platform

### Mobile Deployment

#### iOS
```bash
eas build --platform ios
```

#### Android
```bash
eas build --platform android
```

## Troubleshooting

### API Connection Issues
- Ensure backend is running on correct port (4000)
- Check `EXPO_PUBLIC_API_URL` matches backend URL
- On physical device, use LAN IP instead of localhost

### Database Issues
- Delete `backend/db/ledger.sqlite3` and restart to reset database
- Check database migrations ran successfully

### Authentication Issues
- Ensure JWT token is being stored securely
- Check token expiration and refresh logic
- Clear app cache if login persists

## Security Notes

- Change `JWT_SECRET` in production
- Use HTTPS in production
- Implement rate limiting on API
- Validate all user inputs
- Keep dependencies updated

## License

MIT

## Support

For issues or questions, create an issue in the repository.
