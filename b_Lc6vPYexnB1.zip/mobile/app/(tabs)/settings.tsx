import { View, ScrollView, Text, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useAuthStore } from '../store/auth.store';
import { router } from 'expo-router';
import SettingsRow from '../components/SettingsRow';
import { useQuery } from '@tanstack/react-query';
import { getProfile } from '../lib/api/accounts.api';

export default function SettingsScreen() {
  const { logout, token } = useAuthStore();

  const { data: profile, isLoading } = useQuery({
    queryKey: ['userProfile'],
    queryFn: () => getProfile(token)
  });

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', onPress: () => {} },
        {
          text: 'Logout',
          onPress: () => {
            logout();
            router.replace('/(auth)/login');
          },
          style: 'destructive'
        }
      ]
    );
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#111827' }}>
        <ActivityIndicator size="large" color="#fbbf24" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#111827' }}>
      <ScrollView 
        contentContainerStyle={{ paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ padding: 16, marginTop: 32 }}>
          <Text style={{ fontSize: 28, fontWeight: '700', color: '#fff', marginBottom: 8 }}>
            Settings
          </Text>
          <Text style={{ fontSize: 14, color: '#9ca3af' }}>
            Manage your account
          </Text>
        </View>

        <View style={{ marginTop: 24 }}>
          <View style={{ paddingHorizontal: 16, marginBottom: 8 }}>
            <Text style={{ fontSize: 12, color: '#9ca3af', fontWeight: '600' }}>ACCOUNT</Text>
          </View>

          <SettingsRow
            title="Profile"
            subtitle={profile?.email || 'View your profile'}
            onPress={() => router.push('/(tabs)/profile')}
          />
          <SettingsRow
            title="Categories"
            subtitle="Manage expense categories"
            onPress={() => router.push('/(tabs)/categories')}
          />
          <SettingsRow
            title="Budgets"
            subtitle="Set and track budgets"
            onPress={() => router.push('/(tabs)/budgets')}
          />
        </View>

        <View style={{ marginTop: 24 }}>
          <View style={{ paddingHorizontal: 16, marginBottom: 8 }}>
            <Text style={{ fontSize: 12, color: '#9ca3af', fontWeight: '600' }}>APP</Text>
          </View>

          <SettingsRow
            title="About"
            subtitle="Version 1.0.0"
            onPress={() => Alert.alert('About', 'Expense Ledger v1.0.0')}
          />
          <SettingsRow
            title="Privacy Policy"
            subtitle="Read our privacy policy"
            onPress={() => {}}
          />
        </View>

        <View style={{ marginTop: 24 }}>
          <TouchableOpacity
            onPress={handleLogout}
            style={{
              marginHorizontal: 16,
              paddingVertical: 12,
              paddingHorizontal: 16,
              backgroundColor: '#dc2626',
              borderRadius: 8,
              alignItems: 'center'
            }}
          >
            <Text style={{ color: '#fff', fontWeight: '600' }}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}
