import { View, ScrollView, Text, ActivityIndicator } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { getBudgetProgress } from '../lib/api/budgets.api';
import BudgetProgress from '../components/BudgetProgress';
import { useAuthStore } from '../store/auth.store';

export default function AnalyticsScreen() {
  const { token } = useAuthStore();

  const { data: budgets, isLoading } = useQuery({
    queryKey: ['budgetProgress'],
    queryFn: () => getBudgetProgress(token)
  });

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#111827' }}>
        <ActivityIndicator size="large" color="#fbbf24" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#111827' }}>
      <ScrollView 
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginTop: 32, marginBottom: 24 }}>
          <Text style={{ fontSize: 28, fontWeight: '700', color: '#fff', marginBottom: 8 }}>
            Analytics
          </Text>
          <Text style={{ fontSize: 14, color: '#9ca3af' }}>
            Budget tracking and insights
          </Text>
        </View>

        {budgets && budgets.length > 0 ? (
          <View style={{ gap: 12 }}>
            {budgets.map((budget) => (
              <BudgetProgress key={budget.id} budget={budget} />
            ))}
          </View>
        ) : (
          <View style={{ paddingVertical: 32, paddingHorizontal: 16 }}>
            <Text style={{ color: '#6b7280', textAlign: 'center', marginBottom: 8 }}>
              No budgets yet
            </Text>
            <Text style={{ color: '#4b5563', textAlign: 'center', fontSize: 12 }}>
              Create a budget in settings to track your spending
            </Text>
          </View>
        )}

        <View style={{ marginTop: 32, padding: 16, backgroundColor: '#1f2937', borderRadius: 12 }}>
          <Text style={{ color: '#fff', fontWeight: '600', marginBottom: 8 }}>
            💡 Tip
          </Text>
          <Text style={{ color: '#d1d5db', fontSize: 13, lineHeight: 20 }}>
            Set realistic budgets for each category to help you stay on track with your spending goals. Review your analytics regularly to identify spending patterns.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
