import { View, ScrollView, Text, TouchableOpacity, ActivityIndicator, FlatList } from 'react-native';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getTransactions } from '../lib/api/transactions.api';
import { getCategories } from '../lib/api/categories.api';
import LedgerItem from '../components/LedgerItem';
import { useAuthStore } from '../store/auth.store';

export default function HistoryScreen() {
  const { token } = useAuthStore();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [sortBy, setSortBy] = useState('date');

  const { data: transactions, isLoading: transLoading } = useQuery({
    queryKey: ['allTransactions', selectedCategory],
    queryFn: () => getTransactions({
      categoryId: selectedCategory,
      limit: 100
    }, token)
  });

  const { data: categories } = useQuery({
    queryKey: ['categoriesForFilter'],
    queryFn: () => getCategories(token)
  });

  if (transLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#111827' }}>
        <ActivityIndicator size="large" color="#fbbf24" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#111827' }}>
      <ScrollView 
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginTop: 32, marginBottom: 16 }}>
          <Text style={{ fontSize: 28, fontWeight: '700', color: '#fff', marginBottom: 8 }}>
            Transaction History
          </Text>
          <Text style={{ fontSize: 14, color: '#9ca3af' }}>
            {transactions?.length || 0} transactions
          </Text>
        </View>

        <View style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8, fontWeight: '600' }}>
            FILTER BY CATEGORY
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <TouchableOpacity
              onPress={() => setSelectedCategory(null)}
              style={{
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 20,
                backgroundColor: !selectedCategory ? '#fbbf24' : '#374151',
                marginRight: 8
              }}
            >
              <Text style={{ color: !selectedCategory ? '#1f2937' : '#fff' }}>All</Text>
            </TouchableOpacity>
            {categories?.map((cat) => (
              <TouchableOpacity
                key={cat.id}
                onPress={() => setSelectedCategory(cat.id)}
                style={{
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  borderRadius: 20,
                  backgroundColor: selectedCategory === cat.id ? '#fbbf24' : '#374151',
                  marginRight: 8
                }}
              >
                <Text style={{ color: selectedCategory === cat.id ? '#1f2937' : '#fff' }}>
                  {cat.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={{ gap: 8 }}>
          {transactions && transactions.length > 0 ? (
            transactions.map((transaction) => (
              <LedgerItem key={transaction.id} transaction={transaction} />
            ))
          ) : (
            <Text style={{ color: '#6b7280', textAlign: 'center', paddingVertical: 32 }}>
              No transactions found
            </Text>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
