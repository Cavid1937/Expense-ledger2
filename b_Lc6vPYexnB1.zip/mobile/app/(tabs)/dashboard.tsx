import { View, ScrollView, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { getTransactionsSummary, getTransactions } from '../lib/api/transactions.api';
import SummaryCard from '../components/SummaryCard';
import LedgerItem from '../components/LedgerItem';
import QuickAddFAB from '../components/QuickAddFAB';
import { useAuthStore } from '../store/auth.store';

export default function DashboardScreen() {
  const { token } = useAuthStore();

  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ['transactionsSummary'],
    queryFn: () => getTransactionsSummary(token)
  });

  const { data: recentTransactions, isLoading: transLoading } = useQuery({
    queryKey: ['recentTransactions'],
    queryFn: () => getTransactions({ limit: 5 }, token)
  });

  if (summaryLoading || transLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#111827' }}>
        <ActivityIndicator size="large" color="#fbbf24" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#111827' }}>
      <ScrollView 
        contentContainerStyle={{ padding: 16, gap: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ marginTop: 32 }}>
          <Text style={{ fontSize: 28, fontWeight: '700', color: '#fff', marginBottom: 8 }}>
            Dashboard
          </Text>
          <Text style={{ fontSize: 14, color: '#9ca3af' }}>
            Welcome back! Here&apos;s your overview
          </Text>
        </View>

        {summary && <SummaryCard summary={summary} />}

        <View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#fff' }}>Recent Transactions</Text>
            <TouchableOpacity>
              <Text style={{ color: '#fbbf24' }}>See all</Text>
            </TouchableOpacity>
          </View>

          {recentTransactions && recentTransactions.length > 0 ? (
            recentTransactions.map((transaction) => (
              <LedgerItem key={transaction.id} transaction={transaction} />
            ))
          ) : (
            <Text style={{ color: '#6b7280', textAlign: 'center', paddingVertical: 24 }}>
              No transactions yet
            </Text>
          )}
        </View>
      </ScrollView>

      <QuickAddFAB />
    </View>
  );
}
