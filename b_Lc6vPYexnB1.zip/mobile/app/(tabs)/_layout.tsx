import { Tabs } from 'expo-router';
import { View, Text } from 'react-native';

const TabIcon = ({ name, focused }) => (
  <View style={{ justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{
      fontSize: focused ? 24 : 20,
      color: focused ? '#fbbf24' : '#9ca3af'
    }}>
      {name}
    </Text>
  </View>
);

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#1f2937',
          borderTopColor: '#374151'
        },
        tabBarActiveTintColor: '#fbbf24',
        tabBarInactiveTintColor: '#9ca3af',
        headerShown: false
      }}
    >
      <Tabs.Screen
        name="dashboard"
        options={{
          title: 'Dashboard',
          tabBarLabel: 'Home',
          tabBarIcon: ({ focused }) => <TabIcon name="🏠" focused={focused} />
        }}
      />
      <Tabs.Screen
        name="history"
        options={{
          title: 'History',
          tabBarLabel: 'History',
          tabBarIcon: ({ focused }) => <TabIcon name="📋" focused={focused} />
        }}
      />
      <Tabs.Screen
        name="analytics"
        options={{
          title: 'Analytics',
          tabBarLabel: 'Analytics',
          tabBarIcon: ({ focused }) => <TabIcon name="📊" focused={focused} />
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarLabel: 'Settings',
          tabBarIcon: ({ focused }) => <TabIcon name="⚙️" focused={focused} />
        }}
      />
    </Tabs>
  );
}
