// src/store/auth.store.ts
// =============================================================================
// Zustand authentication store — updated with push token deregistration.
//
// DIFF from previous version:
//   logout() now calls deregisterPushToken() before clearing local state,
//   so the backend removes the device's FCM token and stops sending
//   notifications to a signed-out device.
//
//   deregisterPushToken is imported lazily inside logout() to avoid a
//   circular dependency: auth.store → user.api → client → auth.store.
//   The lazy import breaks the cycle cleanly.
// =============================================================================

import { create }       from "zustand";
import * as SecureStore  from "expo-secure-store";

export interface AuthUser {
  id:              string;
  email:           string;
  full_name:       string | null;
  currency_code:   string;
  currency_symbol: string;
  timezone:        string;
  email_verified:  boolean;
  created_at:      string;
}

export interface AuthTokens {
  accessToken:  string;
  refreshToken: string;
  expiresIn:    number;
}

interface AuthState {
  user:            AuthUser | null;
  accessToken:     string | null;
  isHydrated:      boolean;
  isAuthenticated: boolean;

  login:           (user: AuthUser, tokens: AuthTokens) => Promise<void>;
  updateTokens:    (tokens: AuthTokens) => Promise<void>;
  logout:          () => Promise<void>;
  hydrate:         () => Promise<void>;
  getRefreshToken: () => Promise<string | null>;
}

const REFRESH_TOKEN_KEY = "expense_ledger_refresh_token";

export const useAuthStore = create<AuthState>((set, get) => ({
  user:            null,
  accessToken:     null,
  isHydrated:      false,
  isAuthenticated: false,

  login: async (user, tokens) => {
    await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, tokens.refreshToken);
    set({ user, accessToken: tokens.accessToken, isAuthenticated: true });
  },

  updateTokens: async (tokens) => {
    await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, tokens.refreshToken);
    set({ accessToken: tokens.accessToken });
  },

  logout: async () => {
    // ── Deregister push token so the server stops sending notifications ──────
    // Lazy import breaks the store → api → client → store circular dependency
    try {
      const { deregisterPushToken } = await import("../api/user.api");
      await deregisterPushToken();
    } catch {
      // Non-fatal — if the API call fails (e.g. already expired session),
      // we still clear local state. The token will be overwritten on next login.
      console.warn("[auth.store] deregisterPushToken failed — continuing logout");
    }

    // ── Clear SecureStore and Zustand state ───────────────────────────────────
    await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
    set({ user: null, accessToken: null, isAuthenticated: false });
  },

  hydrate: async () => {
    try {
      const refreshToken = await SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
      if (refreshToken) {
        set({ isAuthenticated: true });
      }
    } catch (error) {
      console.warn("[auth.store] SecureStore hydration failed:", error);
      set({ isAuthenticated: false });
    } finally {
      set({ isHydrated: true });
    }
  },

  getRefreshToken: async () => {
    try {
      return await SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
    } catch {
      return null;
    }
  },
}));
