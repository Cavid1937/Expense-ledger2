// app/(auth)/login.tsx
// =============================================================================
// Login screen.
//
// Architecture:
//   react-hook-form + zodResolver handles all form state and validation locally.
//   On submit, apiClient.post('/auth/login') hits the backend.
//   On success, authStore.login() saves user + tokens → the root layout's
//   auth guard detects isAuthenticated=true and automatically redirects
//   to /(tabs)/dashboard. No manual router.push() needed.
//
// UX decisions:
//   - KeyboardAvoidingView shifts content up when the keyboard appears so
//     the submit button is never hidden on small phones.
//   - Submit button is disabled while a request is in-flight, preventing
//     duplicate submissions.
//   - Server-side errors (wrong credentials, network failure) are displayed
//     in a dismissible inline banner above the submit button, not as alerts.
//   - Password field has a show/hide toggle to reduce entry frustration.
//   - "Return" on the email field focuses the password field. "Done" on
//     the password field submits the form — full keyboard navigation.
// =============================================================================

import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Animated,
} from "react-native";
import { Link }             from "expo-router";
import { useForm, Controller } from "react-hook-form";
import { zodResolver }      from "@hookform/resolvers/zod";
import { useFonts, Syne_700Bold, Syne_800ExtraBold } from "@expo-google-fonts/syne";
import { Outfit_400Regular, Outfit_500Medium, Outfit_600SemiBold } from "@expo-google-fonts/outfit";

import { loginSchema, LoginFormValues } from "../../src/validations/auth.schema";
import { useAuthStore }                 from "../../src/store/auth.store";
import apiClient                        from "../../src/api/client";

// ── Design tokens ──────────────────────────────────────────────────────────────
const C = {
  bg:           "#0C0C0F",
  surface:      "#13131A",
  border:       "#2A2A35",
  borderFocus:  "#7C6BFF",
  text:         "#F0EEF8",
  textMuted:    "#555566",
  textSubtle:   "#888899",
  accent:       "#7C6BFF",
  accentLight:  "#A78BFA",
  error:        "#FF6B6B",
  errorBg:      "rgba(255,107,107,0.1)",
  success:      "#95E1D3",
} as const;

export default function LoginScreen() {
  const login = useAuthStore((state) => state.login);

  const [serverError, setServerError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const passwordRef = useRef<TextInput>(null);

  // ── Font loading ─────────────────────────────────────────────────────────
  const [fontsLoaded] = useFonts({
    Syne_700Bold,
    Syne_800ExtraBold,
    Outfit_400Regular,
    Outfit_500Medium,
    Outfit_600SemiBold,
  });

  // ── Form setup ────────────────────────────────────────────────────────────
  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({
    resolver:      zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
    mode:          "onBlur",  // Validate on field blur, not on every keystroke
  });

  // ── Submit handler ────────────────────────────────────────────────────────
  const onSubmit = async (values: LoginFormValues) => {
    setServerError(null);

    try {
      const { data } = await apiClient.post("/auth/login", {
        email:    values.email,
        password: values.password,
      });

      // Update Zustand store → the root layout auth guard detects
      // isAuthenticated = true and redirects to /(tabs)/dashboard
      await login(data.data.user, data.data.tokens);

    } catch (error: any) {
      const message =
        error?.response?.data?.message ||
        "Something went wrong. Please try again.";

      // Map common backend messages to friendlier text
      if (message.toLowerCase().includes("invalid email or password")) {
        setServerError("Incorrect email or password. Please try again.");
      } else {
        setServerError(message);
      }
    }
  };

  if (!fontsLoaded) return null;

  return (
    <KeyboardAvoidingView
      style={styles.kav}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 24}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Brand mark ─────────────────────────────────────────────────── */}
        <View style={styles.brandContainer}>
          <View style={styles.logoMark}>
            <Text style={styles.logoGlyph}>₿</Text>
          </View>
          <Text style={styles.appName}>Expense Ledger</Text>
          <Text style={styles.tagline}>Your money, clearly.</Text>
        </View>

        {/* ── Form card ──────────────────────────────────────────────────── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Welcome back</Text>
          <Text style={styles.cardSubtitle}>Sign in to your account</Text>

          {/* ── Server error banner ────────────────────────────────────── */}
          {serverError && (
            <Pressable
              style={styles.errorBanner}
              onPress={() => setServerError(null)}
            >
              <Text style={styles.errorBannerIcon}>⚠</Text>
              <Text style={styles.errorBannerText}>{serverError}</Text>
              <Text style={styles.errorBannerDismiss}>✕</Text>
            </Pressable>
          )}

          {/* ── Email field ─────────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>EMAIL</Text>
            <Controller
              control={control}
              name="email"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextInput
                  style={[
                    styles.input,
                    errors.email && styles.inputError,
                  ]}
                  placeholder="you@example.com"
                  placeholderTextColor={C.textMuted}
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="email-address"
                  textContentType="emailAddress"
                  autoComplete="email"
                  returnKeyType="next"
                  onSubmitEditing={() => passwordRef.current?.focus()}
                  blurOnSubmit={false}
                />
              )}
            />
            {errors.email && (
              <Text style={styles.fieldError}>{errors.email.message}</Text>
            )}
          </View>

          {/* ── Password field ──────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <View style={styles.labelRow}>
              <Text style={styles.label}>PASSWORD</Text>
              <Link href="/(auth)/forgot-password" asChild>
                <Pressable>
                  <Text style={styles.forgotLink}>Forgot password?</Text>
                </Pressable>
              </Link>
            </View>
            <Controller
              control={control}
              name="password"
              render={({ field: { onChange, onBlur, value } }) => (
                <View style={styles.passwordWrapper}>
                  <TextInput
                    ref={passwordRef}
                    style={[
                      styles.input,
                      styles.passwordInput,
                      errors.password && styles.inputError,
                    ]}
                    placeholder="••••••••"
                    placeholderTextColor={C.textMuted}
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    secureTextEntry={!showPassword}
                    textContentType="password"
                    autoComplete="current-password"
                    returnKeyType="done"
                    onSubmitEditing={handleSubmit(onSubmit)}
                  />
                  <Pressable
                    style={styles.eyeBtn}
                    onPress={() => setShowPassword((p) => !p)}
                    hitSlop={8}
                  >
                    <Text style={styles.eyeIcon}>
                      {showPassword ? "🙈" : "👁️"}
                    </Text>
                  </Pressable>
                </View>
              )}
            />
            {errors.password && (
              <Text style={styles.fieldError}>{errors.password.message}</Text>
            )}
          </View>

          {/* ── Submit button ────────────────────────────────────────────── */}
          <Pressable
            style={({ pressed }) => [
              styles.submitBtn,
              pressed     && styles.submitBtnPressed,
              isSubmitting && styles.submitBtnDisabled,
            ]}
            onPress={handleSubmit(onSubmit)}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.submitBtnText}>Sign In</Text>
            )}
          </Pressable>
        </View>

        {/* ── Register link ───────────────────────────────────────────────── */}
        <View style={styles.switchRow}>
          <Text style={styles.switchText}>Don't have an account? </Text>
          <Link href="/(auth)/register" asChild>
            <Pressable>
              <Text style={styles.switchLink}>Create one</Text>
            </Pressable>
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  kav: {
    flex:            1,
    backgroundColor: C.bg,
  },
  scroll: {
    flexGrow:        1,
    justifyContent:  "center",
    paddingHorizontal: 24,
    paddingVertical:   48,
  },

  // Brand
  brandContainer: {
    alignItems:   "center",
    marginBottom: 40,
  },
  logoMark: {
    width:           56,
    height:          56,
    borderRadius:    16,
    backgroundColor: C.accent,
    alignItems:      "center",
    justifyContent:  "center",
    marginBottom:    14,
    shadowColor:     C.accent,
    shadowOffset:    { width: 0, height: 8 },
    shadowOpacity:   0.4,
    shadowRadius:    16,
    elevation:       12,
  },
  logoGlyph: {
    fontSize:   26,
    color:      "#fff",
    fontFamily: "Syne_800ExtraBold",
  },
  appName: {
    fontFamily: "Syne_800ExtraBold",
    fontSize:   26,
    color:      C.text,
    letterSpacing: 0.5,
  },
  tagline: {
    fontFamily: "Outfit_400Regular",
    fontSize:   14,
    color:      C.textMuted,
    marginTop:  4,
    letterSpacing: 0.3,
  },

  // Card
  card: {
    backgroundColor: C.surface,
    borderRadius:    20,
    borderWidth:     1,
    borderColor:     C.border,
    padding:         24,
    marginBottom:    20,
  },
  cardTitle: {
    fontFamily:   "Syne_700Bold",
    fontSize:     22,
    color:        C.text,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontFamily:   "Outfit_400Regular",
    fontSize:     14,
    color:        C.textSubtle,
    marginBottom: 24,
  },

  // Error banner
  errorBanner: {
    flexDirection:  "row",
    alignItems:     "center",
    backgroundColor: C.errorBg,
    borderWidth:    1,
    borderColor:    C.error,
    borderRadius:   10,
    padding:        12,
    marginBottom:   16,
    gap:            8,
  },
  errorBannerIcon: {
    fontSize: 14,
    color:    C.error,
  },
  errorBannerText: {
    flex:       1,
    fontFamily: "Outfit_400Regular",
    fontSize:   13,
    color:      C.error,
    lineHeight: 18,
  },
  errorBannerDismiss: {
    fontSize: 12,
    color:    C.error,
    opacity:  0.6,
  },

  // Fields
  fieldGroup: {
    marginBottom: 16,
  },
  label: {
    fontFamily:   "Outfit_600SemiBold",
    fontSize:     10,
    letterSpacing: 0.2,
    color:        C.textMuted,
    textTransform: "uppercase",
    marginBottom:  6,
  },
  labelRow: {
    flexDirection:  "row",
    justifyContent: "space-between",
    alignItems:     "center",
    marginBottom:   6,
  },
  forgotLink: {
    fontFamily: "Outfit_500Medium",
    fontSize:   12,
    color:      C.accentLight,
  },
  input: {
    backgroundColor: C.bg,
    borderWidth:     1,
    borderColor:     C.border,
    borderRadius:    10,
    paddingHorizontal: 14,
    paddingVertical:   13,
    fontFamily:      "Outfit_400Regular",
    fontSize:        15,
    color:           C.text,
  },
  inputError: {
    borderColor: C.error,
  },
  passwordWrapper: {
    position: "relative",
  },
  passwordInput: {
    paddingRight: 48,
  },
  eyeBtn: {
    position: "absolute",
    right:    14,
    top:      0,
    bottom:   0,
    justifyContent: "center",
  },
  eyeIcon: {
    fontSize: 16,
  },
  fieldError: {
    fontFamily: "Outfit_400Regular",
    fontSize:   12,
    color:      C.error,
    marginTop:  4,
  },

  // Submit
  submitBtn: {
    backgroundColor: C.accent,
    borderRadius:    12,
    paddingVertical: 15,
    alignItems:      "center",
    justifyContent:  "center",
    marginTop:       8,
    shadowColor:     C.accent,
    shadowOffset:    { width: 0, height: 6 },
    shadowOpacity:   0.35,
    shadowRadius:    14,
    elevation:       8,
    minHeight:       52,
  },
  submitBtnPressed: {
    opacity:   0.85,
    transform: [{ scale: 0.985 }],
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    fontFamily:    "Outfit_600SemiBold",
    fontSize:      16,
    color:         "#fff",
    letterSpacing: 0.3,
  },

  // Switch
  switchRow: {
    flexDirection:  "row",
    justifyContent: "center",
    alignItems:     "center",
  },
  switchText: {
    fontFamily: "Outfit_400Regular",
    fontSize:   14,
    color:      C.textMuted,
  },
  switchLink: {
    fontFamily: "Outfit_600SemiBold",
    fontSize:   14,
    color:      C.accentLight,
  },
});
