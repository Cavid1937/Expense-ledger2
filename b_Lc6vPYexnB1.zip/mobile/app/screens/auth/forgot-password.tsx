// app/(auth)/forgot-password.tsx
// =============================================================================
// Forgot Password screen.
//
// Intentionally simple — collects an email and shows a confirmation state.
// The confirmation state is shown regardless of whether the email exists
// (anti-enumeration: we never reveal if an account exists for a given email).
// =============================================================================

import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Link, router }          from "expo-router";
import { useForm, Controller }   from "react-hook-form";
import { zodResolver }           from "@hookform/resolvers/zod";
import { useFonts, Syne_700Bold } from "@expo-google-fonts/syne";
import { Outfit_400Regular, Outfit_600SemiBold } from "@expo-google-fonts/outfit";

import { forgotPasswordSchema, ForgotPasswordFormValues } from "../../src/validations/auth.schema";
import apiClient from "../../src/api/client";

const C = {
  bg:          "#0C0C0F",
  surface:     "#13131A",
  border:      "#2A2A35",
  text:        "#F0EEF8",
  textMuted:   "#555566",
  textSubtle:  "#888899",
  accent:      "#7C6BFF",
  accentLight: "#A78BFA",
  error:       "#FF6B6B",
  errorBg:     "rgba(255,107,107,0.1)",
  success:     "#95E1D3",
  successBg:   "rgba(149,225,211,0.1)",
} as const;

export default function ForgotPasswordScreen() {
  const [submitted, setSubmitted] = useState(false);

  const [fontsLoaded] = useFonts({
    Syne_700Bold,
    Outfit_400Regular,
    Outfit_600SemiBold,
  });

  const {
    control,
    handleSubmit,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<ForgotPasswordFormValues>({
    resolver:      zodResolver(forgotPasswordSchema),
    defaultValues: { email: "" },
    mode:          "onBlur",
  });

  const onSubmit = async (values: ForgotPasswordFormValues) => {
    try {
      await apiClient.post("/auth/forgot-password", { email: values.email });
    } catch {
      // Intentionally swallow errors — we always show the success state
      // to prevent email enumeration attacks.
    } finally {
      setSubmitted(true);
    }
  };

  if (!fontsLoaded) return null;

  return (
    <KeyboardAvoidingView
      style={styles.kav}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={styles.container}>
        {/* Back button */}
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>← Back</Text>
        </Pressable>

        <View style={styles.card}>
          {!submitted ? (
            <>
              <Text style={styles.cardTitle}>Reset password</Text>
              <Text style={styles.cardSubtitle}>
                Enter your email and we'll send you a reset link.
              </Text>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>EMAIL</Text>
                <Controller
                  control={control}
                  name="email"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <TextInput
                      style={[styles.input, errors.email && styles.inputError]}
                      placeholder="you@example.com"
                      placeholderTextColor={C.textMuted}
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      autoCapitalize="none"
                      keyboardType="email-address"
                      textContentType="emailAddress"
                      returnKeyType="done"
                      onSubmitEditing={handleSubmit(onSubmit)}
                    />
                  )}
                />
                {errors.email && (
                  <Text style={styles.fieldError}>{errors.email.message}</Text>
                )}
              </View>

              <Pressable
                style={({ pressed }) => [
                  styles.submitBtn,
                  pressed      && styles.submitBtnPressed,
                  isSubmitting && styles.submitBtnDisabled,
                ]}
                onPress={handleSubmit(onSubmit)}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.submitBtnText}>Send Reset Link</Text>
                )}
              </Pressable>
            </>
          ) : (
            // ── Success state ──────────────────────────────────────────────
            <View style={styles.successContainer}>
              <Text style={styles.successIcon}>✉️</Text>
              <Text style={styles.cardTitle}>Check your inbox</Text>
              <Text style={styles.cardSubtitle}>
                If an account exists for{" "}
                <Text style={{ color: C.accentLight }}>{getValues("email")}</Text>,
                you'll receive a password reset link shortly.
              </Text>
              <Link href="/(auth)/login" asChild>
                <Pressable style={styles.submitBtn}>
                  <Text style={styles.submitBtnText}>Back to Sign In</Text>
                </Pressable>
              </Link>
            </View>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  kav: { flex: 1, backgroundColor: C.bg },
  container: {
    flex:              1,
    paddingHorizontal: 24,
    paddingVertical:   64,
    justifyContent:    "center",
  },
  backBtn: { marginBottom: 24, alignSelf: "flex-start" },
  backBtnText: {
    fontFamily: "Outfit_600SemiBold",
    fontSize:   14,
    color:      C.accentLight,
  },
  card: {
    backgroundColor: C.surface,
    borderRadius:    20,
    borderWidth:     1,
    borderColor:     C.border,
    padding:         24,
  },
  cardTitle: {
    fontFamily:   "Syne_700Bold",
    fontSize:     22,
    color:        C.text,
    marginBottom: 6,
  },
  cardSubtitle: {
    fontFamily:   "Outfit_400Regular",
    fontSize:     14,
    color:        C.textSubtle,
    marginBottom: 24,
    lineHeight:   20,
  },
  fieldGroup:   { marginBottom: 16 },
  label: {
    fontFamily:    "Outfit_600SemiBold",
    fontSize:      10,
    letterSpacing: 0.2,
    color:         C.textMuted,
    textTransform: "uppercase",
    marginBottom:  6,
  },
  input: {
    backgroundColor:   C.bg,
    borderWidth:       1,
    borderColor:       C.border,
    borderRadius:      10,
    paddingHorizontal: 14,
    paddingVertical:   13,
    fontFamily:        "Outfit_400Regular",
    fontSize:          15,
    color:             C.text,
  },
  inputError: { borderColor: C.error },
  fieldError: {
    fontFamily: "Outfit_400Regular",
    fontSize:   12,
    color:      C.error,
    marginTop:  4,
  },
  submitBtn: {
    backgroundColor: C.accent,
    borderRadius:    12,
    paddingVertical: 15,
    alignItems:      "center",
    justifyContent:  "center",
    shadowColor:     C.accent,
    shadowOffset:    { width: 0, height: 6 },
    shadowOpacity:   0.35,
    shadowRadius:    14,
    elevation:       8,
    minHeight:       52,
  },
  submitBtnPressed:  { opacity: 0.85, transform: [{ scale: 0.985 }] },
  submitBtnDisabled: { opacity: 0.6 },
  submitBtnText: {
    fontFamily:    "Outfit_600SemiBold",
    fontSize:      16,
    color:         "#fff",
    letterSpacing: 0.3,
  },
  successContainer: { alignItems: "center" },
  successIcon: { fontSize: 40, marginBottom: 16 },
});
