// app/(auth)/register.tsx
// =============================================================================
// Register screen.
//
// Mirrors the Login screen's architecture exactly:
//   react-hook-form + zodResolver → apiClient.post('/auth/register')
//   → authStore.login() → root layout redirects to /(tabs)/dashboard
//
// Additional fields vs login:
//   - full_name (optional — genuinely optional, not just empty string)
//   - confirm_password (client-side only, stripped before API call)
//
// The confirm_password field is validated at the schema level via
// .refine() — the error appears on the confirm field, not on password.
// =============================================================================

import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Link }                  from "expo-router";
import { useForm, Controller }   from "react-hook-form";
import { zodResolver }           from "@hookform/resolvers/zod";
import { useFonts, Syne_700Bold, Syne_800ExtraBold } from "@expo-google-fonts/syne";
import { Outfit_400Regular, Outfit_500Medium, Outfit_600SemiBold } from "@expo-google-fonts/outfit";

import { registerSchema, RegisterFormValues } from "../../src/validations/auth.schema";
import { useAuthStore }                        from "../../src/store/auth.store";
import apiClient                               from "../../src/api/client";

// ── Design tokens (identical to login.tsx for visual consistency) ──────────
const C = {
  bg:          "#0C0C0F",
  surface:     "#13131A",
  border:      "#2A2A35",
  borderFocus: "#7C6BFF",
  text:        "#F0EEF8",
  textMuted:   "#555566",
  textSubtle:  "#888899",
  accent:      "#7C6BFF",
  accentLight: "#A78BFA",
  error:       "#FF6B6B",
  errorBg:     "rgba(255,107,107,0.1)",
} as const;

export default function RegisterScreen() {
  const login = useAuthStore((state) => state.login);

  const [serverError,    setServerError]    = useState<string | null>(null);
  const [showPassword,   setShowPassword]   = useState(false);
  const [showConfirm,    setShowConfirm]    = useState(false);

  const emailRef           = useRef<TextInput>(null);
  const passwordRef        = useRef<TextInput>(null);
  const confirmPasswordRef = useRef<TextInput>(null);

  const [fontsLoaded] = useFonts({
    Syne_700Bold,
    Syne_800ExtraBold,
    Outfit_400Regular,
    Outfit_500Medium,
    Outfit_600SemiBold,
  });

  // ── Form setup ─────────────────────────────────────────────────────────────
  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterFormValues>({
    resolver:      zodResolver(registerSchema),
    defaultValues: {
      full_name:        "",
      email:            "",
      password:         "",
      confirm_password: "",
    },
    mode: "onBlur",
  });

  // ── Submit handler ─────────────────────────────────────────────────────────
  const onSubmit = async (values: RegisterFormValues) => {
    setServerError(null);

    try {
      // Strip confirm_password — the backend doesn't know or care about it
      const { confirm_password, ...payload } = values;

      // Omit empty full_name entirely so it's stored as null, not ""
      const body = {
        ...payload,
        ...(payload.full_name?.trim() ? {} : { full_name: undefined }),
      };

      const { data } = await apiClient.post("/auth/register", body);

      // Same as login — store the tokens and user, guard handles navigation
      await login(data.data.user, data.data.tokens);

    } catch (error: any) {
      const message =
        error?.response?.data?.message ||
        "Something went wrong. Please try again.";

      // Map common backend errors to user-friendly copy
      if (message.toLowerCase().includes("already exists")) {
        setServerError(
          "An account with that email already exists. Try logging in instead."
        );
      } else {
        setServerError(message);
      }
    }
  };

  if (!fontsLoaded) return null;

  return (
    <KeyboardAvoidingView
      style={styles.kav}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 24}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Brand mark ───────────────────────────────────────────────── */}
        <View style={styles.brandContainer}>
          <View style={styles.logoMark}>
            <Text style={styles.logoGlyph}>₿</Text>
          </View>
          <Text style={styles.appName}>Expense Ledger</Text>
          <Text style={styles.tagline}>Start tracking in seconds.</Text>
        </View>

        {/* ── Form card ────────────────────────────────────────────────── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Create account</Text>
          <Text style={styles.cardSubtitle}>
            It's free and takes under a minute.
          </Text>

          {/* ── Server error banner ────────────────────────────────────── */}
          {serverError && (
            <Pressable
              style={styles.errorBanner}
              onPress={() => setServerError(null)}
            >
              <Text style={styles.errorBannerIcon}>⚠</Text>
              <Text style={styles.errorBannerText}>{serverError}</Text>
              <Text style={styles.errorBannerDismiss}>✕</Text>
            </Pressable>
          )}

          {/* ── Name (optional) ─────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <View style={styles.labelRow}>
              <Text style={styles.label}>YOUR NAME</Text>
              <Text style={styles.optionalBadge}>Optional</Text>
            </View>
            <Controller
              control={control}
              name="full_name"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextInput
                  style={[styles.input, errors.full_name && styles.inputError]}
                  placeholder="Alex Johnson"
                  placeholderTextColor={C.textMuted}
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  autoCapitalize="words"
                  autoCorrect={false}
                  textContentType="name"
                  returnKeyType="next"
                  onSubmitEditing={() => emailRef.current?.focus()}
                  blurOnSubmit={false}
                />
              )}
            />
            {errors.full_name && (
              <Text style={styles.fieldError}>{errors.full_name.message}</Text>
            )}
          </View>

          {/* ── Email ───────────────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>EMAIL</Text>
            <Controller
              control={control}
              name="email"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextInput
                  ref={emailRef}
                  style={[styles.input, errors.email && styles.inputError]}
                  placeholder="you@example.com"
                  placeholderTextColor={C.textMuted}
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="email-address"
                  textContentType="emailAddress"
                  autoComplete="email"
                  returnKeyType="next"
                  onSubmitEditing={() => passwordRef.current?.focus()}
                  blurOnSubmit={false}
                />
              )}
            />
            {errors.email && (
              <Text style={styles.fieldError}>{errors.email.message}</Text>
            )}
          </View>

          {/* ── Password ────────────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>PASSWORD</Text>
            <Controller
              control={control}
              name="password"
              render={({ field: { onChange, onBlur, value } }) => (
                <View style={styles.passwordWrapper}>
                  <TextInput
                    ref={passwordRef}
                    style={[
                      styles.input,
                      styles.passwordInput,
                      errors.password && styles.inputError,
                    ]}
                    placeholder="Min. 8 characters"
                    placeholderTextColor={C.textMuted}
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    secureTextEntry={!showPassword}
                    textContentType="newPassword"
                    autoComplete="new-password"
                    returnKeyType="next"
                    onSubmitEditing={() => confirmPasswordRef.current?.focus()}
                    blurOnSubmit={false}
                  />
                  <Pressable
                    style={styles.eyeBtn}
                    onPress={() => setShowPassword((p) => !p)}
                    hitSlop={8}
                  >
                    <Text style={styles.eyeIcon}>
                      {showPassword ? "🙈" : "👁️"}
                    </Text>
                  </Pressable>
                </View>
              )}
            />
            {errors.password && (
              <Text style={styles.fieldError}>{errors.password.message}</Text>
            )}
          </View>

          {/* ── Confirm password ─────────────────────────────────────────── */}
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>CONFIRM PASSWORD</Text>
            <Controller
              control={control}
              name="confirm_password"
              render={({ field: { onChange, onBlur, value } }) => (
                <View style={styles.passwordWrapper}>
                  <TextInput
                    ref={confirmPasswordRef}
                    style={[
                      styles.input,
                      styles.passwordInput,
                      errors.confirm_password && styles.inputError,
                    ]}
                    placeholder="Repeat your password"
                    placeholderTextColor={C.textMuted}
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    secureTextEntry={!showConfirm}
                    textContentType="newPassword"
                    returnKeyType="done"
                    onSubmitEditing={handleSubmit(onSubmit)}
                  />
                  <Pressable
                    style={styles.eyeBtn}
                    onPress={() => setShowConfirm((p) => !p)}
                    hitSlop={8}
                  >
                    <Text style={styles.eyeIcon}>
                      {showConfirm ? "🙈" : "👁️"}
                    </Text>
                  </Pressable>
                </View>
              )}
            />
            {errors.confirm_password && (
              <Text style={styles.fieldError}>
                {errors.confirm_password.message}
              </Text>
            )}
          </View>

          {/* ── Password strength hint ───────────────────────────────────── */}
          <Text style={styles.hint}>
            At least 8 characters with one letter and one number.
          </Text>

          {/* ── Submit button ─────────────────────────────────────────────── */}
          <Pressable
            style={({ pressed }) => [
              styles.submitBtn,
              pressed      && styles.submitBtnPressed,
              isSubmitting && styles.submitBtnDisabled,
            ]}
            onPress={handleSubmit(onSubmit)}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.submitBtnText}>Create Account</Text>
            )}
          </Pressable>
        </View>

        {/* ── Login link ───────────────────────────────────────────────────── */}
        <View style={styles.switchRow}>
          <Text style={styles.switchText}>Already have an account? </Text>
          <Link href="/(auth)/login" asChild>
            <Pressable>
              <Text style={styles.switchLink}>Sign in</Text>
            </Pressable>
          </Link>
        </View>

        {/* ── Fine print ──────────────────────────────────────────────────── */}
        <Text style={styles.finePrint}>
          Your data is stored locally and on your personal backend.{"\n"}
          We never sell or share your financial information.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  kav: {
    flex:            1,
    backgroundColor: C.bg,
  },
  scroll: {
    flexGrow:          1,
    justifyContent:    "center",
    paddingHorizontal: 24,
    paddingVertical:   48,
  },

  // Brand
  brandContainer: {
    alignItems:   "center",
    marginBottom: 36,
  },
  logoMark: {
    width:           56,
    height:          56,
    borderRadius:    16,
    backgroundColor: C.accent,
    alignItems:      "center",
    justifyContent:  "center",
    marginBottom:    14,
    shadowColor:     C.accent,
    shadowOffset:    { width: 0, height: 8 },
    shadowOpacity:   0.4,
    shadowRadius:    16,
    elevation:       12,
  },
  logoGlyph: {
    fontSize:   26,
    color:      "#fff",
    fontFamily: "Syne_800ExtraBold",
  },
  appName: {
    fontFamily:    "Syne_800ExtraBold",
    fontSize:      26,
    color:         C.text,
    letterSpacing: 0.5,
  },
  tagline: {
    fontFamily:    "Outfit_400Regular",
    fontSize:      14,
    color:         C.textMuted,
    marginTop:     4,
    letterSpacing: 0.3,
  },

  // Card
  card: {
    backgroundColor: C.surface,
    borderRadius:    20,
    borderWidth:     1,
    borderColor:     C.border,
    padding:         24,
    marginBottom:    20,
  },
  cardTitle: {
    fontFamily:   "Syne_700Bold",
    fontSize:     22,
    color:        C.text,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontFamily:   "Outfit_400Regular",
    fontSize:     14,
    color:        C.textSubtle,
    marginBottom: 24,
  },

  // Error banner
  errorBanner: {
    flexDirection:   "row",
    alignItems:      "center",
    backgroundColor: C.errorBg,
    borderWidth:     1,
    borderColor:     C.error,
    borderRadius:    10,
    padding:         12,
    marginBottom:    16,
    gap:             8,
  },
  errorBannerIcon: {
    fontSize: 14,
    color:    C.error,
  },
  errorBannerText: {
    flex:       1,
    fontFamily: "Outfit_400Regular",
    fontSize:   13,
    color:      C.error,
    lineHeight: 18,
  },
  errorBannerDismiss: {
    fontSize: 12,
    color:    C.error,
    opacity:  0.6,
  },

  // Fields
  fieldGroup: {
    marginBottom: 14,
  },
  label: {
    fontFamily:    "Outfit_600SemiBold",
    fontSize:      10,
    letterSpacing: 0.2,
    color:         C.textMuted,
    textTransform: "uppercase",
  },
  labelRow: {
    flexDirection:  "row",
    justifyContent: "space-between",
    alignItems:     "center",
    marginBottom:   6,
  },
  optionalBadge: {
    fontFamily:      "Outfit_400Regular",
    fontSize:        11,
    color:           C.textMuted,
    backgroundColor: "#1E1E28",
    paddingHorizontal: 8,
    paddingVertical:   2,
    borderRadius:    4,
  },
  input: {
    backgroundColor:   C.bg,
    borderWidth:       1,
    borderColor:       C.border,
    borderRadius:      10,
    paddingHorizontal: 14,
    paddingVertical:   13,
    fontFamily:        "Outfit_400Regular",
    fontSize:          15,
    color:             C.text,
    marginTop:         6,
  },
  inputError: {
    borderColor: C.error,
  },
  passwordWrapper: {
    position: "relative",
    marginTop: 6,
  },
  passwordInput: {
    paddingRight: 48,
    marginTop:    0,
  },
  eyeBtn: {
    position:       "absolute",
    right:          14,
    top:            0,
    bottom:         0,
    justifyContent: "center",
  },
  eyeIcon: {
    fontSize: 16,
  },
  fieldError: {
    fontFamily: "Outfit_400Regular",
    fontSize:   12,
    color:      C.error,
    marginTop:  4,
  },

  // Hint
  hint: {
    fontFamily: "Outfit_400Regular",
    fontSize:   12,
    color:      C.textMuted,
    marginBottom: 16,
    lineHeight: 17,
  },

  // Submit
  submitBtn: {
    backgroundColor: C.accent,
    borderRadius:    12,
    paddingVertical: 15,
    alignItems:      "center",
    justifyContent:  "center",
    shadowColor:     C.accent,
    shadowOffset:    { width: 0, height: 6 },
    shadowOpacity:   0.35,
    shadowRadius:    14,
    elevation:       8,
    minHeight:       52,
  },
  submitBtnPressed: {
    opacity:   0.85,
    transform: [{ scale: 0.985 }],
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    fontFamily:    "Outfit_600SemiBold",
    fontSize:      16,
    color:         "#fff",
    letterSpacing: 0.3,
  },

  // Switch row
  switchRow: {
    flexDirection:  "row",
    justifyContent: "center",
    alignItems:     "center",
    marginBottom:   16,
  },
  switchText: {
    fontFamily: "Outfit_400Regular",
    fontSize:   14,
    color:      C.textMuted,
  },
  switchLink: {
    fontFamily: "Outfit_600SemiBold",
    fontSize:   14,
    color:      C.accentLight,
  },

  // Fine print
  finePrint: {
    fontFamily: "Outfit_400Regular",
    fontSize:   11,
    color:      C.textMuted,
    textAlign:  "center",
    lineHeight: 16,
    opacity:    0.6,
  },
});
