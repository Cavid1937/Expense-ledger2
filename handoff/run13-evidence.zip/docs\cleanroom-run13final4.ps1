﻿$ErrorActionPreference = "Continue"
$env:Path = "C:\Program Files\nodejs;$env:Path"
$wt = "C:\Users\cavid\OneDrive\Documents\GitHub\Expense-ledger2-fixes"
$ev = "$wt\tests\evidence"
$CR = Join-Path $env:TEMP ("ledger-cleanroom-run13final4-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory $CR | Out-Null
"== clean room: $CR"; "== node $(node -v), npm $(npm -v)"; "== chrome $((Get-Item 'C:\Program Files\Google\Chrome\Application\chrome.exe').VersionInfo.ProductVersion)"; "== started $(Get-Date -Format o)"
"== 1. copy candidate (tracked + untracked, no node_modules/dist/.git/page/.out/evidence)"
robocopy $wt "$CR\repo" /E /XD node_modules dist .git .out page evidence snapshots /NFL /NDL /NJH /NJS /NP | Out-Null
foreach ($f in "App.jsx","i18n.js","package.json","package-lock.json","tests\expected-counts.json") { "{0}  {1}" -f (Get-FileHash "$CR\repo\$f").Hash, $f }
"worktree/copy App.jsx identical: " + ((Get-FileHash "$wt\App.jsx").Hash -eq (Get-FileHash "$CR\repo\App.jsx").Hash)
Set-Location "$CR\repo"
"== 2. npm ci (lockfile)"
npm ci --no-audit --no-fund 2>&1 | Select-Object -Last 3; "npm ci exit=$LASTEXITCODE"
"== 3. pinned TEST-ONLY dependencies (not in package.json/lock: reproducibility gap recorded)"
npm install --no-save --no-audit --no-fund puppeteer-core@25.16.0 @fontsource/playfair-display@5.3.0 @fontsource/dm-sans@5.3.0 2>&1 | Select-Object -Last 3; "npm test-deps exit=$LASTEXITCODE"
"== 4. logic"
node tests/run-logic.mjs > "$CR\logic.txt" 2>&1; "logic exit=$LASTEXITCODE"
Select-String "$CR\logic.txt" -Pattern '^\[run-logic\]' | ForEach-Object { $_.Line } | Select-Object -Last 3
"== 5. build"
npx vite build > "$CR\build.txt" 2>&1; "build exit=$LASTEXITCODE"
Select-String "$CR\build.txt" -Pattern 'index-.*\.js|built in|error' | ForEach-Object { $_.Line }
"== 6. az audit"
node tests/az-audit.mjs i18n.js App.jsx handoff > "$CR\azaudit.txt" 2>&1; "az audit exit=$LASTEXITCODE"; Get-Content "$CR\azaudit.txt" -Tail 4
"== 7. browser run 1 (uninterrupted, full)"
$env:PAGE_OUT = "$CR\page1"
node tests/run-browser.mjs > "$CR\browser1.txt" 2>&1; "browser1 exit=$LASTEXITCODE"
Select-String "$CR\browser1.txt" -Pattern '^\[run-browser\]' | ForEach-Object { $_.Line }
"== 8. browser run 2 (stability, full)"
$env:PAGE_OUT = "$CR\page2"
node tests/run-browser.mjs > "$CR\browser2.txt" 2>&1; "browser2 exit=$LASTEXITCODE"
Select-String "$CR\browser2.txt" -Pattern '^\[run-browser\]' | ForEach-Object { $_.Line }
Copy-Item "$CR\logic.txt" "$ev\295-run13-final-cleanroom-logic.txt"; Copy-Item "$CR\build.txt" "$ev\296-run13-final-cleanroom-build.txt"; Copy-Item "$CR\azaudit.txt" "$ev\297-run13-final-cleanroom-azaudit.txt"
Copy-Item "$CR\browser1.txt" "$ev\298-run13-final-cleanroom-browser-run1.txt"; Copy-Item "$CR\browser2.txt" "$ev\299-run13-final-cleanroom-browser-run2.txt"
"== finished $(Get-Date -Format o)"




