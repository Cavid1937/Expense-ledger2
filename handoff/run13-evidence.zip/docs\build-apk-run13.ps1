﻿$ErrorActionPreference="Continue"
$env:Path="C:\Program Files\nodejs;$env:Path"
$env:JAVA_HOME="C:\Program Files\Android\Android Studio\jbr"; $env:ANDROID_HOME="$env:LOCALAPPDATA\Android\Sdk"; $env:ANDROID_SDK_ROOT=$env:ANDROID_HOME
$env:Path="$env:JAVA_HOME\bin;$env:Path"
$snap="C:\Users\cavid\OneDrive\Documents\GitHub\Expense-ledger2-fixes\handoff\snapshots\20261028-run13-final"
$c="C:\Users\cavid\OneDrive\Documents\GitHub\Expense-ledger2-capacitor"; Set-Location $c
$log="$snap\..\..\..\tests\evidence"
"== started $(Get-Date -Format o)"; "java: $(& java -version 2>&1 | Select -First 1)"
"== 1. copy frozen candidate into the Android copy (App, i18n, index.html, public, native share files)"
Copy-Item "$snap\App.jsx","$snap\i18n.js","$snap\index.html" $c -Force
robocopy "$snap\public" "$c\public" /E /NFL /NDL /NJH /NJS /NP | Out-Null
Copy-Item "$snap\native\native-share-core.js","$snap\native\native-share.js" $c -Force
foreach($f in "App.jsx","i18n.js","main.jsx","native-share-core.js","native-share.js","package.json","package-lock.json","capacitor.config.json"){ "{0}  {1}" -f (Get-FileHash "$c\$f").Hash,$f }
"App/i18n identical to frozen candidate: $((Get-FileHash $c\App.jsx).Hash -eq (Get-FileHash $snap\App.jsx).Hash) / $((Get-FileHash $c\i18n.js).Hash -eq (Get-FileHash $snap\i18n.js).Hash)"
"== 2. npm ci (lockfile of the Android copy)"
npm ci --no-audit --no-fund 2>&1 | Select-Object -Last 2; "npm ci exit=$LASTEXITCODE"
"== 3. vite build"
npm run build 2>&1 | Select-Object -Last 6; "build exit=$LASTEXITCODE"
"== 4. cap sync android"
npx cap sync android 2>&1 | Select-Object -Last 12; "sync exit=$LASTEXITCODE"
"== 5. gradle assembleDebug"
& "$c\android\gradlew.bat" -p "$c\android" assembleDebug --no-daemon --console=plain 2>&1 | Select-Object -Last 15; "gradle exit=$LASTEXITCODE"
"== finished $(Get-Date -Format o)"
