// Screenshot tour of the real bundled app (synthetic data). Usage: node shots.mjs <outDir> <label>
import fs from "fs"; import path from "path";
const lib = await import(process.env.LIB_URL);
const { launch, openPage, tab, openAdd, openSafe, openSettings, openData, openGoals, wait, tx, baseSeed, settle } = lib;
const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
const d = new Date(), pad = (n) => String(n).padStart(2, "0");
const ym = (o) => { const x = new Date(d.getFullYear(), d.getMonth() + o, 1); return `${x.getFullYear()}-${pad(x.getMonth() + 1)}`; };
const DAY = pad(Math.min(d.getDate() - 1, 27) || 1);
let n = 1790000300000; const T = (o) => tx({ id: ++n, ...o });
const txns = [
  T({ type: "income", category: "salary", amount: 2450, merchant: "Employer", date: `${ym(0)}-01` }),
  T({ type: "income", category: "salary", amount: 2450, merchant: "Employer", date: `${ym(-1)}-01` }),
  T({ category: "food", amount: 18.4, merchant: "Bravo", subcategory: "Groceries", date: `${ym(0)}-${DAY}` }),
  T({ category: "food", amount: 7.5, merchant: "Coffee House", subcategory: "Cafe", date: `${ym(0)}-02` }),
  T({ category: "transport", amount: 0.6, merchant: "BakıKart", subcategory: "Bus", date: `${ym(0)}-02` }),
  T({ category: "transport", amount: 22, merchant: "Bolt", date: `${ym(-1)}-14` }),
  T({ category: "housing", amount: 450, merchant: "Rent", recurring: true, recurFreq: "monthly", date: `${ym(0)}-03`, billId: "bR" }),
  T({ category: "housing", amount: 450, merchant: "Rent", recurring: true, recurFreq: "monthly", date: `${ym(-1)}-03`, billId: "bR" }),
  T({ category: "health", amount: 35, merchant: "Pharmacy", date: `${ym(-1)}-20` }),
  T({ category: "entertainment", amount: 12, merchant: "Cinema", date: `${ym(0)}-04` }),
  T({ category: "food", amount: 64.2, merchant: "Bazar", subcategory: "Groceries", date: `${ym(-1)}-09` }),
];
const bills = [{ id: "bR", name: "Rent", type: "expense", category: "housing", subcategory: "", amount: 450, freq: "monthly", anchorDate: `${ym(-1)}-03`, active: true, createdAt: "2026-09-01T00:00:00Z" },
  { id: "bI", name: "Internet", type: "expense", category: "housing", subcategory: "Utilities", amount: 25, freq: "monthly", anchorDate: `${ym(-1)}-${DAY}`, active: true, createdAt: "2026-09-01T00:00:00Z" }];
const seed = (language) => baseSeed({ transactions: txns, bills, language, budgets: { food: 300, transport: 80 }, goals: [{ id: "g1", name: "Laptop", target: 2400, saved: 600, monthlyTarget: 200, targetDate: null }], safeToSpend: { enabled: true, savingsTarget: 200 }, lastBackup: new Date().toISOString() });
const browser = await launch();
const shot = async (page, name) => { await settle(page).catch(() => {}); await wait(250); await page.screenshot({ path: path.join(out, name + ".png") }); };
for (const lang of ["en", "az", "ru"]) {
  let page = await openPage(browser, { seed: seed(lang), width: 390, height: 844 });
  await shot(page, `${lang}-01-home`);
  await openSafe(page); await shot(page, `${lang}-02-home-safe-open`);
  await tab(page, "Ledger"); await shot(page, `${lang}-03-transactions`);
  await tab(page, "Monthly"); await shot(page, `${lang}-04-analytics`);
  await openGoals(page, "budgets"); await shot(page, `${lang}-05-budgets`);
  await tab(page, "More"); await shot(page, `${lang}-06-more`);
  await tab(page, "Recurring"); await shot(page, `${lang}-07-bills`);
  await openData(page); await shot(page, `${lang}-08-importexport`);
  await tab(page, "Home"); await openAdd(page); await shot(page, `${lang}-09-add-form`);
  await page.close();
}
// wide screen, first-launch chooser, privacy mode
let page = await openPage(browser, { seed: seed("en"), width: 1100, height: 800 });
await shot(page, "wide-en-01-home"); await tab(page, "Ledger"); await shot(page, "wide-en-02-transactions"); await page.close();
page = await openPage(browser, { fresh: true, seed: null, chooseLang: false, width: 390, height: 844 }); await shot(page, "first-launch-chooser"); await page.close();
page = await openPage(browser, { seed: seed("en"), width: 390, height: 844 });
await page.evaluate(() => { const b = document.querySelector('[aria-label*="rivacy"], .privacy-toggle'); b && b.click(); }); await shot(page, "en-10-privacy-home"); await page.close();
await browser.close(); console.log("done", fs.readdirSync(out).length, "screenshots");
