﻿const { launch, openPage, openAdd, wait, baseSeed } = await import(process.env.LIB_URL);
const b = await launch(); const p = await openPage(b, { seed: baseSeed({ language: "en" }) }); await openAdd(p);
const r = await p.evaluate(() => {
  const lum = (c) => { const [r,g,b] = c.match(/[\d.]+/g).slice(0,3).map(Number).map((v)=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)}); return 0.2126*r+0.7152*g+0.0722*b; };
  const ratio = (a, b) => { const l1 = lum(a), l2 = lum(b); return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05); };
  const bgOf = (el) => { while (el) { const c = getComputedStyle(el).backgroundColor; if (c && !/rgba\(0, 0, 0, 0\)|transparent/.test(c)) return c; el = el.parentElement; } return "rgb(7,21,26)"; };
  const out = {}; const el = document.querySelector(".amount-input");
  const ph = getComputedStyle(el, "::placeholder"); out.amountPlaceholder = { color: ph.color, opacity: ph.opacity, bg: bgOf(el), ratio: +ratio(ph.color, bgOf(el)).toFixed(2) };
  out.amountValueColor = getComputedStyle(el).color;
  for (const s of [".list-sub", ".txn-sub", ".m-lbl", ".field-hint", "label"]) { const e = document.querySelector(s); if (e) { const c = getComputedStyle(e).color; out[s] = { color: c, ratio: +ratio(c, bgOf(e)).toFixed(2), size: getComputedStyle(e).fontSize }; } }
  return out; });
console.log(JSON.stringify(r, null, 1)); await b.close();
